package com.pocketai.app.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pocketai.app.ai.GenSettings
import com.pocketai.app.data.AppSettings
import com.pocketai.app.data.ChatMessage
import com.pocketai.app.data.CollabMode
import com.pocketai.app.data.Conversation
import com.pocketai.app.data.ConversationStore
import com.pocketai.app.data.DEFAULT_SYSTEM_PROMPT
import com.pocketai.app.data.MessageMeta
import com.pocketai.app.data.MsgState
import com.pocketai.app.data.Role
import com.pocketai.app.data.SearchMode
import com.pocketai.app.data.SearchProviderType
import com.pocketai.app.data.SettingsStore
import com.pocketai.app.data.ThemeMode
import com.pocketai.app.feedback.AppLog
import com.pocketai.app.llm.ModelManager
import com.pocketai.app.safety.Compatibility
import com.pocketai.app.safety.CompatibilityReport
import com.pocketai.app.safety.RiskLevel
import com.pocketai.app.safety.ThermalMonitor
import com.pocketai.app.search.SearchService
import com.pocketai.app.team.CollabContext
import com.pocketai.app.team.CollabEngine
import com.pocketai.app.team.ExecutionManager
import com.pocketai.app.team.MeetingCallbacks
import com.pocketai.app.team.MeetingEngine
import com.pocketai.app.team.MeetingTurn
import com.pocketai.app.team.ModelRole
import com.pocketai.app.team.ModelSlot
import com.pocketai.app.team.RunFailedException
import com.pocketai.app.team.RunTracker
import com.pocketai.app.team.TeamConfig
import com.pocketai.app.team.TeamProfile
import com.pocketai.app.team.TeamStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicLong

/** Streaming state of the reply being produced right now (shown instead of the stored message). */
data class LiveRun(val convId: Long, val msgId: Long, val meta: MessageMeta, val text: String)

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val store = ConversationStore(app)
    private val settingsStore = SettingsStore(app)
    private val teamStore = TeamStore(app)
    val models = ModelManager(app, viewModelScope)
    val thermal = ThermalMonitor(app)
    private val searchService = SearchService(app) { settings }
    private val exec = ExecutionManager(models, thermal) { settings }
    private val collab = CollabEngine(exec, searchService, models)
    private val meetingEngine = MeetingEngine(exec, models)
    private val ids = AtomicLong(System.currentTimeMillis())

    var conversations by mutableStateOf<List<Conversation>>(emptyList())
        private set
    var currentId by mutableLongStateOf(0L)
        private set
    var settings by mutableStateOf(settingsStore.load())
        private set
    var generating by mutableStateOf(false)
        private set
    var live by mutableStateOf<LiveRun?>(null)
        private set

    var team by mutableStateOf(teamStore.loadConfig())
        private set
    var teamProfile by mutableStateOf(teamStore.loadProfile())
        private set
    var compat by mutableStateOf<CompatibilityReport?>(null)
        private set
    var compatBusy by mutableStateOf(false)
        private set

    var meetingRunning by mutableStateOf(false)
        private set
    var meetingStatus by mutableStateOf("")
        private set
    var meetingTurns by mutableStateOf<List<MeetingTurn>>(emptyList())
        private set
    var meetingNotices by mutableStateOf<List<String>>(emptyList())
        private set
    var meetingError by mutableStateOf<String?>(null)
        private set

    private var job: Job? = null
    private var meetingJob: Job? = null

    val current: Conversation
        get() = conversations.firstOrNull { it.id == currentId } ?: conversations.first()

    init {
        val loaded = store.load()
        if (loaded.isEmpty()) {
            val c = emptyConversation()
            conversations = listOf(c)
            currentId = c.id
        } else {
            conversations = loaded
            currentId = loaded.first().id
        }
        syncTeam()
    }

    override fun onCleared() {
        thermal.close()
    }

    private fun emptyConversation() = Conversation(ids.incrementAndGet(), "New chat", emptyList())


    fun newChat() {
        stop()
        if (current.messages.isEmpty()) return
        val c = emptyConversation()
        conversations = listOf(c) + conversations
        currentId = c.id
        persist()
    }

    fun select(id: Long) {
        if (id == currentId) return
        stop()
        currentId = id
    }

    fun delete(id: Long) {
        if (id == currentId) stop()
        var rest = conversations.filter { it.id != id }
        if (rest.isEmpty()) rest = listOf(emptyConversation())
        conversations = rest
        if (rest.none { it.id == currentId }) currentId = rest.first().id
        persist()
    }

    // ---- team ----

    private fun fixMain(slots: List<ModelSlot>): List<ModelSlot> = slots.mapIndexed { i, s ->
        when {
            i == 0 -> s.copy(role = ModelRole.MAIN, enabled = true)
            s.role == ModelRole.MAIN -> s.copy(role = ModelRole.REVIEWER)
            else -> s
        }
    }

    private fun applyTeam(c: TeamConfig) {
        team = c
        teamStore.saveConfig(c)
    }

    /** Drops models that no longer exist; makes the first imported model Main when the team is empty. */
    fun syncTeam() {
        val existing = models.files.map { it.name }.toSet()
        var slots = team.slots.filter { it.file in existing }
        if (slots.isEmpty() && models.files.isNotEmpty()) slots = listOf(ModelSlot(models.files.first().name, ModelRole.MAIN))
        val fixed = fixMain(slots)
        val synth = team.synthesizerFile?.takeIf { it in existing }
        if (fixed != team.slots || synth != team.synthesizerFile) applyTeam(TeamConfig(fixed, synth))
    }

    fun addToTeam(file: String) {
        if (team.slots.any { it.file == file }) return
        val role = if (team.slots.isEmpty()) ModelRole.MAIN else ModelRole.REVIEWER
        applyTeam(team.copy(slots = fixMain(team.slots + ModelSlot(file, role))))
    }

    fun removeFromTeam(file: String) {
        applyTeam(team.copy(slots = fixMain(team.slots.filter { it.file != file }), synthesizerFile = team.synthesizerFile.takeIf { it != file }))
    }

    fun moveSlot(file: String, delta: Int) {
        val l = team.slots.toMutableList()
        val i = l.indexOfFirst { it.file == file }
        val j = i + delta
        if (i < 0 || j < 0 || j >= l.size) return
        val tmp = l[i]
        l[i] = l[j]
        l[j] = tmp
        applyTeam(team.copy(slots = fixMain(l)))
    }

    fun makeMain(file: String) {
        val l = team.slots.toMutableList()
        val i = l.indexOfFirst { it.file == file }
        if (i <= 0) return
        l.add(0, l.removeAt(i))
        applyTeam(team.copy(slots = fixMain(l)))
    }

    fun setSlotRole(file: String, role: ModelRole) {
        if (role == ModelRole.MAIN) return
        applyTeam(team.copy(slots = fixMain(team.slots.map { if (it.file == file) it.copy(role = role) else it })))
    }

    fun setSlotEnabled(file: String, on: Boolean) {
        applyTeam(team.copy(slots = fixMain(team.slots.map { if (it.file == file) it.copy(enabled = on) else it })))
    }

    fun setSynthesizer(file: String?) = applyTeam(team.copy(synthesizerFile = file))

    fun refreshCompat() {
        if (compatBusy) return
        compatBusy = true
        viewModelScope.launch {
            try {
                syncTeam()
                compat = Compatibility.assess(getApplication<Application>(), models, thermal, team, settings.collabMode, settings)
            } finally {
                compatBusy = false
            }
        }
    }

    // ---- model meeting ----

    fun startMeeting() {
        if (meetingRunning || generating) return
        meetingJob = viewModelScope.launch {
            meetingRunning = true
            meetingTurns = emptyList()
            meetingNotices = emptyList()
            meetingError = null
            meetingStatus = "Checking the device..."
            try {
                syncTeam()
                val report = Compatibility.assess(getApplication<Application>(), models, thermal, team, CollabMode.SEQUENTIAL, settings)
                compat = report
                if (report.level == RiskLevel.HIGH) {
                    throw RunFailedException("Blocked for safety: " + report.reasons.joinToString(" ") + " " + report.recommendations.joinToString(" "))
                }
                val gen = GenSettings(settings.maxTokens, settings.temperature, settings.topP, settings.topK)
                val profile = meetingEngine.run(
                    team, settings, gen,
                    MeetingCallbacks(
                        status = { meetingStatus = it },
                        turn = { meetingTurns = meetingTurns + it },
                        notice = { meetingNotices = meetingNotices + it },
                    ),
                )
                teamProfile = profile
                teamStore.saveProfile(profile)
                meetingStatus = "Meeting finished."
            } catch (e: CancellationException) {
                meetingStatus = "Cancelled. The previous profile was kept."
                throw e
            } catch (e: Exception) {
                meetingError = e.message ?: e.javaClass.simpleName
                meetingStatus = "Meeting stopped."
                AppLog.error("meeting", meetingError.orEmpty())
            } finally {
                meetingRunning = false
            }
        }
    }

    fun cancelMeeting() {
        meetingJob?.cancel()
    }

    /** Applies the roles the Main model suggested. Only on the user's tap. */
    fun applySuggestedRoles() {
        val p = teamProfile ?: return
        var slots = team.slots
        p.suggestions.forEach { sg -> slots = slots.map { if (it.file == sg.file) it.copy(role = sg.role) else it } }
        applyTeam(team.copy(slots = fixMain(slots)))
        val updated = p.copy(fingerprint = team.fingerprint())
        teamProfile = updated
        teamStore.saveProfile(updated)
    }

    // ---- chat ----

    fun send(text: String) {
        val clean = text.trim()
        if (clean.isEmpty() || generating || meetingRunning) return
        val convId = currentId
        val userMsg = ChatMessage(ids.incrementAndGet(), Role.USER, clean)
        updateConv(convId) { c ->
            c.copy(
                title = if (c.messages.isEmpty()) clean.take(32) else c.title,
                messages = c.messages + userMsg,
            )
        }
        startGeneration(convId)
    }

    fun stop() {
        job?.cancel()
    }

    // ---- model control ----

    fun loadModel(file: ModelManager.ModelFile) {
        if (generating) return
        models.load(file, settings.contextLength)
    }

    fun unloadModel(name: String) {
        stop()
        models.unload(name)
    }

    fun deleteModel(file: ModelManager.ModelFile) {
        stop()
        removeFromTeam(file.name)
        models.delete(file)
    }

    /** Retry after a stopped or failed reply: drop that reply and generate again. */
    fun retry() {
        if (generating) return
        val convId = currentId
        val last = current.messages.lastOrNull() ?: return
        if (last.role != Role.ASSISTANT || (last.state != MsgState.STOPPED && last.state != MsgState.ERROR)) return
        updateConv(convId) { c -> c.copy(messages = c.messages.filter { it.id != last.id }) }
        startGeneration(convId)
    }

    private fun startGeneration(convId: Long) {
        val assistantId = ids.incrementAndGet()
        val history = conversations.first { it.id == convId }.messages
        updateConv(convId) { c ->
            c.copy(messages = c.messages + ChatMessage(assistantId, Role.ASSISTANT, "", MsgState.STREAMING))
        }
        val s = settings
        generating = true
        job = viewModelScope.launch {
            val self = coroutineContext[Job]
            val tracker = RunTracker { meta, text -> live = LiveRun(convId, assistantId, meta, text) }
            var state = MsgState.DONE
            var err: String? = null
            try {
                syncTeam()
                if (team.main == null) {
                    throw RunFailedException(
                        if (models.files.isEmpty()) "No model is installed. Import a .gguf model in Models first."
                        else "No Main model is selected. Open Team and add one."
                    )
                }
                val report = Compatibility.assess(getApplication<Application>(), models, thermal, team, s.collabMode, s)
                compat = report
                if (report.level == RiskLevel.HIGH) {
                    throw RunFailedException(
                        "Blocked for safety. " + report.reasons.joinToString(" ") +
                            (if (report.recommendations.isEmpty()) "" else " Suggested: " + report.recommendations.joinToString(" "))
                    )
                }
                val ctx = CollabContext(
                    history, s.systemPrompt, s.collabMode, s.searchMode, team, teamProfile,
                    GenSettings(s.maxTokens, s.temperature, s.topP, s.topK), s,
                )
                collab.run(ctx, tracker)
                if (tracker.finalText().isBlank()) throw RunFailedException("The model returned an empty answer.")
            } catch (e: CancellationException) {
                state = MsgState.STOPPED
                throw e
            } catch (e: Exception) {
                state = MsgState.ERROR
                err = e.message ?: e.javaClass.simpleName
                AppLog.error("run", err.orEmpty())
            } finally {
                val snap = tracker.snapshot()
                live = null
                updateMsg(convId, assistantId) { it.copy(text = snap.second, meta = snap.first, state = state, error = err) }
                if (job === self) {
                    generating = false
                    job = null
                }
                persist()
            }
        }
    }

    private fun updateConv(id: Long, f: (Conversation) -> Conversation) {
        conversations = conversations.map { if (it.id == id) f(it) else it }
    }

    private fun updateMsg(convId: Long, msgId: Long, f: (ChatMessage) -> ChatMessage) {
        updateConv(convId) { c -> c.copy(messages = c.messages.map { if (it.id == msgId) f(it) else it }) }
    }

    private fun persist() = store.save(conversations)

    // ---- settings ----

    private fun updateSettings(f: (AppSettings) -> AppSettings) {
        settings = f(settings)
        settingsStore.save(settings)
    }

    fun setTheme(mode: ThemeMode) = updateSettings { it.copy(themeMode = mode) }
    fun setReduceMotion(on: Boolean) = updateSettings { it.copy(reduceMotion = on) }
    fun setSystemPrompt(text: String) = updateSettings { it.copy(systemPrompt = text) }
    fun resetSystemPrompt() = updateSettings { it.copy(systemPrompt = DEFAULT_SYSTEM_PROMPT) }
    fun setContextLength(n: Int) = updateSettings { it.copy(contextLength = n) }
    fun setMaxTokens(n: Int) = updateSettings { it.copy(maxTokens = n) }
    fun setTemperature(t: Float) = updateSettings { it.copy(temperature = t) }
    fun setTopP(p: Float) = updateSettings { it.copy(topP = p) }
    fun setTopK(k: Int) = updateSettings { it.copy(topK = k) }
    fun setSearchMode(m: SearchMode) = updateSettings { it.copy(searchMode = m) }
    fun setCollabMode(m: CollabMode) = updateSettings { it.copy(collabMode = m) }
    fun setSearchProvider(p: SearchProviderType) = updateSettings { it.copy(searchProvider = p) }
    fun setBraveKey(k: String) = updateSettings { it.copy(braveKey = k) }
    fun setSearxUrl(u: String) = updateSettings { it.copy(searxUrl = u) }
    fun setReviewRounds(n: Int) = updateSettings { it.copy(reviewRounds = n) }
    fun setMeetingRounds(n: Int) = updateSettings { it.copy(meetingRounds = n) }
    fun setStepTimeout(sec: Int) = updateSettings { it.copy(stepTimeoutSec = sec) }
    fun setAllowFallback(on: Boolean) = updateSettings { it.copy(allowSequentialFallback = on) }
    fun setKeepMain(on: Boolean) = updateSettings { it.copy(keepMainLoaded = on) }
    fun acceptNotice() = updateSettings { it.copy(noticeAccepted = true) }
}
