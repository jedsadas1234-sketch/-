cmake_minimum_required(VERSION 3.22.1)
project("pocketai_llm")

# Always optimise native code, even in debug APKs (debug llama.cpp is unusably slow).
# Do NOT force CMAKE_BUILD_TYPE in the cache: it fights Gradle's -DCMAKE_BUILD_TYPE=Debug
# and makes ninja re-run CMake forever ("build.ninja still dirty after 100 tries").
set(CMAKE_C_FLAGS_DEBUG "-O3 -DNDEBUG")
set(CMAKE_CXX_FLAGS_DEBUG "-O3 -DNDEBUG")

set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_COMMON OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TOOLS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_SERVER OFF CACHE BOOL "" FORCE)
set(LLAMA_CURL OFF CACHE BOOL "" FORCE)
set(GGML_NATIVE OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP OFF CACHE BOOL "" FORCE)

# Preferred: llama.cpp pre-cloned next to this file (the GitHub workflow does this).
# Fallback: FetchContent. Updates must be disconnected, otherwise every CMake re-run
# touches the sources via git, build.ninja is always "dirty", and ninja gives up after 100 tries.
if(EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/llama.cpp/CMakeLists.txt")
    add_subdirectory("${CMAKE_CURRENT_SOURCE_DIR}/llama.cpp" "${CMAKE_BINARY_DIR}/llama-build")
else()
    include(FetchContent)
    set(FETCHCONTENT_UPDATES_DISCONNECTED ON)
    FetchContent_Declare(
        llama
        GIT_REPOSITORY https://github.com/ggml-org/llama.cpp.git
        GIT_TAG        v1.0.0
        GIT_SHALLOW    TRUE
    )
    FetchContent_MakeAvailable(llama)
endif()

add_library(pocketai_llm SHARED llama_jni.cpp)
target_link_libraries(pocketai_llm llama android log)
# Android 15+ devices may use 16 KB pages.
target_link_options(pocketai_llm PRIVATE -Wl,-z,max-page-size=16384)
