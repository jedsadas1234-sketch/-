package com.pocketai.app.ai

import com.pocketai.app.data.ChatMessage
import com.pocketai.app.data.Role
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

data class GenSettings(val maxTokens: Int, val temperature: Float)

/**
 * Engine abstraction: MockAIProvider (fallback, no model) and LocalAIProvider (llama.cpp).
 * Cancel the collecting coroutine to stop generation.
 */
interface AIProvider {
    val name: String
    fun generate(messages: List<ChatMessage>, systemPrompt: String, gen: GenSettings): Flow<String>
}

/** Fake engine used only while no model is loaded. Not a real model. */
class MockAIProvider : AIProvider {
    override val name = "Mock engine (no model loaded)"

    override fun generate(messages: List<ChatMessage>, systemPrompt: String, gen: GenSettings): Flow<String> = flow {
        delay(500)
        val last = messages.lastOrNull { it.role == Role.USER }?.text.orEmpty()
        val reply = buildReply(last)
        for (word in reply.split(" ")) {
            emit("$word ")
            delay(30)
        }
    }

    private fun buildReply(userText: String): String {
        val sb = StringBuilder()
        sb.append("**No model is loaded**, so this is canned text. ")
        sb.append("Open the Models screen (chip icon, top right), import a `.gguf` file, then tap Load. ")
        sb.append("You wrote: `${userText.take(80)}`.")
        if (userText.contains("code", ignoreCase = true)) {
            sb.append("\n\nSample code block:\n\n```kotlin\nfun greet(name: String) = \"Hello, \$name!\"\n```\n")
        }
        return sb.toString()
    }
}
