package com.pocketai.app.llm

import com.pocketai.app.ai.AIProvider
import com.pocketai.app.ai.GenSettings
import com.pocketai.app.data.ChatMessage
import com.pocketai.app.data.Role
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.job
import kotlinx.coroutines.withContext

/** Runs the loaded GGUF model on-device. Cancel the collector to stop generation. */
class LocalAIProvider(private val models: ModelManager) : AIProvider {

    override val name: String
        get() = (models.status as? ModelManager.Status.Loaded)?.let { "Local: ${it.file.name}" }
            ?: "Local (no model loaded)"

    override fun generate(
        messages: List<ChatMessage>,
        systemPrompt: String,
        gen: GenSettings,
    ): Flow<String> = channelFlow {
        val handle = models.handle
        val loaded = models.status as? ModelManager.Status.Loaded
        if (handle == 0L || loaded == null) throw IllegalStateException("No model loaded.")

        // Rough history trimming (about 3 chars per token). The native side checks exactly.
        val budgetChars = (loaded.nCtx - gen.maxTokens).coerceAtLeast(256) * 3
        val sys = systemPrompt.trim()
        var used = sys.length
        val kept = ArrayDeque<ChatMessage>()
        for (m in messages.filter { it.text.isNotBlank() }.asReversed()) {
            if (kept.isNotEmpty() && used + m.text.length > budgetChars) break
            kept.addFirst(m)
            used += m.text.length
        }

        val roles = ArrayList<String>()
        val contents = ArrayList<ByteArray>()
        if (sys.isNotEmpty()) {
            roles.add("system")
            contents.add(sys.toByteArray(Charsets.UTF_8))
        }
        for (m in kept) {
            roles.add(if (m.role == Role.USER) "user" else "assistant")
            contents.add(m.text.toByteArray(Charsets.UTF_8))
        }

        withContext(Dispatchers.Default) {
            val job = coroutineContext.job
            NativeLlama.generate(
                handle,
                roles.toTypedArray(),
                contents.toTypedArray(),
                gen.maxTokens,
                gen.temperature,
                0.9f,
                object : NativeLlama.TokenSink {
                    override fun onToken(bytes: ByteArray): Boolean {
                        if (bytes.isNotEmpty()) trySend(String(bytes, Charsets.UTF_8))
                        return job.isActive
                    }
                },
            )
        }
    }.buffer(Channel.UNLIMITED)
}
