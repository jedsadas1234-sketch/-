package com.pocketai.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Saves conversations as JSON in app-private storage. Nothing leaves the device. */
class ConversationStore(context: Context) {
    private val file = File(context.filesDir, "conversations.json")

    @Synchronized
    fun load(): List<Conversation> {
        if (!file.exists()) return emptyList()
        return try {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Conversation(
                    id = o.getLong("id"),
                    title = o.getString("title"),
                    messages = parseMessages(o.getJSONArray("messages")),
                )
            }
        } catch (e: Exception) {
            // keep the unreadable file so history is not lost on next save
            try {
                file.copyTo(File(file.parentFile, "conversations.corrupt.json"), overwrite = true)
            } catch (_: Exception) {
            }
            emptyList()
        }
    }

    @Synchronized
    fun save(list: List<Conversation>) {
        try {
            val arr = JSONArray()
            list.forEach { c ->
                val msgs = JSONArray()
                c.messages.forEach { m ->
                    msgs.put(
                        JSONObject()
                            .put("id", m.id)
                            .put("role", m.role.name)
                            .put("text", m.text)
                            .put("state", m.state.name)
                            .put("error", m.error ?: JSONObject.NULL)
                    )
                }
                arr.put(
                    JSONObject()
                        .put("id", c.id)
                        .put("title", c.title)
                        .put("messages", msgs)
                )
            }
            val tmp = File(file.parentFile, "conversations.json.tmp")
            tmp.writeText(arr.toString())
            if (!tmp.renameTo(file)) {
                file.writeText(arr.toString())
                tmp.delete()
            }
        } catch (_: Exception) {
            // persistence is best-effort; chat keeps working in memory
        }
    }

    private fun parseMessages(arr: JSONArray): List<ChatMessage> =
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val state = MsgState.valueOf(o.getString("state"))
            ChatMessage(
                id = o.getLong("id"),
                role = Role.valueOf(o.getString("role")),
                text = o.getString("text"),
                // a message still "streaming" on load means the process died mid-generation
                state = if (state == MsgState.STREAMING) MsgState.STOPPED else state,
                error = if (o.isNull("error")) null else o.getString("error"),
            )
        }
}

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("pocketai_settings", Context.MODE_PRIVATE)

    fun load(): AppSettings = AppSettings(
        themeMode = try {
            ThemeMode.valueOf(prefs.getString("theme", ThemeMode.SYSTEM.name) ?: ThemeMode.SYSTEM.name)
        } catch (_: Exception) {
            ThemeMode.SYSTEM
        },
        systemPrompt = prefs.getString("system_prompt", DEFAULT_SYSTEM_PROMPT) ?: DEFAULT_SYSTEM_PROMPT,
        reduceMotion = prefs.getBoolean("reduce_motion", false),
        contextLength = prefs.getInt("context_length", 0),
        maxTokens = prefs.getInt("max_tokens", 512),
        temperature = prefs.getFloat("temperature", 0.7f),
    )

    fun save(s: AppSettings) {
        prefs.edit()
            .putString("theme", s.themeMode.name)
            .putString("system_prompt", s.systemPrompt)
            .putBoolean("reduce_motion", s.reduceMotion)
            .putInt("context_length", s.contextLength)
            .putInt("max_tokens", s.maxTokens)
            .putFloat("temperature", s.temperature)
            .apply()
    }
}
