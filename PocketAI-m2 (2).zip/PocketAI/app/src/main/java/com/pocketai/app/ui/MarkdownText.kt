package com.pocketai.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class Block(val code: Boolean, val text: String)

/** Small markdown subset: fenced code blocks, **bold**, `inline code`. */
@Composable
fun MarkdownText(text: String, modifier: Modifier = Modifier) {
    val blocks = remember(text) { splitBlocks(text) }
    Column(modifier) {
        blocks.forEach { b ->
            if (b.code) {
                Text(
                    text = b.text,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    softWrap = false,
                    modifier = Modifier
                        .padding(vertical = 4.dp)
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceContainerHighest, RoundedCornerShape(12.dp))
                        .horizontalScroll(rememberScrollState())
                        .padding(10.dp),
                )
            } else if (b.text.isNotBlank()) {
                Text(inline(b.text, MaterialTheme.colorScheme.surfaceContainerHighest))
            }
        }
    }
}

private fun splitBlocks(text: String): List<Block> {
    val out = mutableListOf<Block>()
    val buf = StringBuilder()
    var inCode = false
    fun flush() {
        val t = if (inCode) buf.toString().trimEnd('\n') else buf.toString().trim('\n')
        if (t.isNotEmpty()) out.add(Block(inCode, t))
        buf.clear()
    }
    text.split("\n").forEach { line ->
        if (line.trimStart().startsWith("```")) {
            flush()
            inCode = !inCode
        } else {
            buf.append(line).append('\n')
        }
    }
    flush() // an unclosed fence (still streaming) renders as code
    return out
}

private fun inline(s: String, codeBg: Color): AnnotatedString = buildAnnotatedString {
    var i = 0
    while (i < s.length) {
        if (s.startsWith("**", i)) {
            val end = s.indexOf("**", i + 2)
            if (end > 0) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(s.substring(i + 2, end)) }
                i = end + 2
                continue
            }
        }
        if (s[i] == '`') {
            val end = s.indexOf('`', i + 1)
            if (end > 0) {
                withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg)) {
                    append(s.substring(i + 1, end))
                }
                i = end + 1
                continue
            }
        }
        append(s[i])
        i++
    }
}
