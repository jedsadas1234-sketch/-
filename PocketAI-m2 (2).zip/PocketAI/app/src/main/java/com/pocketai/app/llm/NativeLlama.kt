package com.pocketai.app.llm

/** Thin JNI wrapper. All functions throw RuntimeException with a readable message on failure. */
object NativeLlama {
    /** Receives UTF-8 bytes of generated text. Return false to stop generation. Empty array = cancellation poll. */
    interface TokenSink {
        fun onToken(bytes: ByteArray): Boolean
    }

    var loadError: String? = null
        private set

    val available: Boolean = try {
        System.loadLibrary("pocketai_llm")
        true
    } catch (t: Throwable) {
        loadError = t.message ?: t.javaClass.simpleName
        false
    }

    external fun load(path: String, nCtx: Int, nThreads: Int): Long
    external fun unload(handle: Long)
    external fun describe(handle: Long): String
    external fun generate(
        handle: Long,
        roles: Array<String>,
        contents: Array<ByteArray>,
        maxTokens: Int,
        temperature: Float,
        topP: Float,
        sink: TokenSink,
    )
}
