package com.pocketai.app.llm

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

/** Imports GGUF files into app storage and loads/unloads them. Nothing is uploaded anywhere. */
class ModelManager(private val app: Application, private val scope: CoroutineScope) {

    data class ModelFile(val name: String, val sizeBytes: Long)

    sealed interface Status {
        data object Idle : Status
        data class Importing(val name: String, val copied: Long, val total: Long) : Status
        data class Loading(val name: String) : Status
        data class Loaded(val file: ModelFile, val info: String, val nCtx: Int) : Status
        data class Failed(val message: String) : Status
    }

    private val dir = File(app.filesDir, "models").apply { mkdirs() }

    var status by mutableStateOf<Status>(Status.Idle)
        private set
    var files by mutableStateOf(scan())
        private set

    @Volatile
    var handle: Long = 0L
        private set

    private var importJob: Job? = null

    val busy: Boolean get() = status is Status.Importing || status is Status.Loading

    val totalRamBytes: Long
        get() {
            val am = app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            return mi.totalMem
        }

    /** Safe default context length for this device's RAM. */
    fun defaultContext(): Int {
        val gb = totalRamBytes / 1e9
        return when {
            gb < 3.5 -> 1024
            gb < 6.5 -> 2048
            else -> 4096
        }
    }

    private fun scan(): List<ModelFile> =
        dir.listFiles { f -> f.isFile && f.name.endsWith(".gguf", ignoreCase = true) }
            ?.map { ModelFile(it.name, it.length()) }
            ?.sortedBy { it.name.lowercase() }
            ?: emptyList()

    fun import(uri: Uri) {
        if (busy) return
        importJob = scope.launch(Dispatchers.IO) {
            var part: File? = null
            try {
                var display = "model.gguf"
                var size = -1L
                app.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (ni >= 0) display = c.getString(ni) ?: display
                        val si = c.getColumnIndex(OpenableColumns.SIZE)
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                    }
                }
                val name = display.replace(Regex("[^A-Za-z0-9._-]"), "_")
                if (!name.endsWith(".gguf", ignoreCase = true)) {
                    status = Status.Failed("Not a .gguf file: $display")
                    return@launch
                }
                if ((status as? Status.Loaded)?.file?.name == name) {
                    status = Status.Failed("$name is loaded. Unload it before importing a file with the same name.")
                    return@launch
                }
                if (size > 0 && dir.usableSpace < size + 200L * 1024 * 1024) {
                    status = Status.Failed("Not enough free storage for ${formatBytes(size)}.")
                    return@launch
                }
                status = Status.Importing(name, 0, size)

                val input = app.contentResolver.openInputStream(uri)
                if (input == null) {
                    status = Status.Failed("Cannot open the selected file.")
                    return@launch
                }
                input.use { ins ->
                    val head = ByteArray(4)
                    var got = 0
                    while (got < 4) {
                        val r = ins.read(head, got, 4 - got)
                        if (r < 0) break
                        got += r
                    }
                    if (got < 4 || String(head, Charsets.ISO_8859_1) != "GGUF") {
                        status = Status.Failed("Not a valid GGUF file (missing GGUF header).")
                        return@launch
                    }
                    val partFile = File(dir, "$name.part")
                    part = partFile
                    FileOutputStream(partFile).use { out ->
                        out.write(head)
                        var copied = 4L
                        var lastReport = 0L
                        val buf = ByteArray(1 shl 20)
                        while (true) {
                            ensureActive()
                            val r = ins.read(buf)
                            if (r < 0) break
                            out.write(buf, 0, r)
                            copied += r
                            if (copied - lastReport > (8L shl 20)) {
                                status = Status.Importing(name, copied, size)
                                lastReport = copied
                            }
                        }
                    }
                }
                val target = File(dir, name)
                if (target.exists()) target.delete()
                if (!part!!.renameTo(target)) throw java.io.IOException("Could not move imported file into place.")
                part = null
                files = scan()
                status = Status.Idle
            } catch (e: CancellationException) {
                part?.delete()
                status = Status.Idle
                throw e
            } catch (e: Exception) {
                part?.delete()
                status = Status.Failed(e.message ?: e.javaClass.simpleName)
            }
        }
    }

    fun cancelImport() {
        importJob?.cancel()
    }

    fun load(file: ModelFile, requestedCtx: Int) {
        if (busy) return
        if (!NativeLlama.available) {
            status = Status.Failed("Native engine failed to load: ${NativeLlama.loadError}")
            return
        }
        if (file.sizeBytes > totalRamBytes * 0.75) {
            status = Status.Failed(
                "${file.name} (${formatBytes(file.sizeBytes)}) is too large for this device " +
                    "(${formatBytes(totalRamBytes)} RAM). Use a smaller or more quantized model."
            )
            return
        }
        val nCtx = if (requestedCtx > 0) requestedCtx else defaultContext()
        status = Status.Loading(file.name)
        scope.launch(Dispatchers.Default) {
            val old = handle
            handle = 0L
            if (old != 0L) NativeLlama.unload(old)
            try {
                val threads = maxOf(2, Runtime.getRuntime().availableProcessors() / 2)
                val h = NativeLlama.load(File(dir, file.name).absolutePath, nCtx, threads)
                handle = h
                status = Status.Loaded(file, NativeLlama.describe(h), nCtx)
            } catch (t: Throwable) {
                status = Status.Failed(t.message ?: t.javaClass.simpleName)
            }
        }
    }

    fun unload() {
        if (busy) return
        scope.launch(Dispatchers.Default) {
            val h = handle
            handle = 0L
            if (h != 0L) NativeLlama.unload(h)
            status = Status.Idle
        }
    }

    fun delete(file: ModelFile) {
        if (status is Status.Importing || status is Status.Loading) return
        scope.launch(Dispatchers.IO) {
            if ((status as? Status.Loaded)?.file?.name == file.name) {
                val h = handle
                handle = 0L
                if (h != 0L) NativeLlama.unload(h)
                status = Status.Idle
            }
            File(dir, file.name).delete()
            files = scan()
        }
    }
}

fun formatBytes(b: Long): String = when {
    b >= 1L shl 30 -> "%.2f GB".format(b / (1024.0 * 1024.0 * 1024.0))
    b >= 1L shl 20 -> "%.1f MB".format(b / (1024.0 * 1024.0))
    else -> "$b B"
}
