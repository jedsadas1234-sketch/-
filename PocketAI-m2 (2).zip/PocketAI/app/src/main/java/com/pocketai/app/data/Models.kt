package com.pocketai.app.data

enum class Role { USER, ASSISTANT }

enum class MsgState { DONE, STREAMING, STOPPED, ERROR }

data class ChatMessage(
    val id: Long,
    val role: Role,
    val text: String,
    val state: MsgState = MsgState.DONE,
    val error: String? = null,
)

data class Conversation(
    val id: Long,
    val title: String,
    val messages: List<ChatMessage>,
)

enum class ThemeMode { SYSTEM, LIGHT, DARK }

const val DEFAULT_SYSTEM_PROMPT =
    "You are Pocket AI, a friendly and concise companion. Answer clearly and honestly."

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val systemPrompt: String = DEFAULT_SYSTEM_PROMPT,
    val reduceMotion: Boolean = false,
    /** 0 = automatic, chosen from device RAM at load time. */
    val contextLength: Int = 0,
    val maxTokens: Int = 512,
    val temperature: Float = 0.7f,
)
