# Pocket AI — Milestone 2 (local model)

Kotlin + Jetpack Compose + llama.cpp (JNI). minSdk 26, targetSdk 34, arm64-v8a only.

## Build APK on GitHub
1. Unzip, push the contents to a GitHub repo (`.github` folder in the repo root).
2. Actions tab, run "Build APK" (also runs on every push). First build is slow
   (compiles llama.cpp; CMake downloads tag v1.0.0 from GitHub).
3. Download artifact `PocketAI-debug-apk`, unzip, install `app-debug.apk`.

## Use
1. Models icon (chip, top right) -> Import GGUF file -> Load.
2. Chat. Stop button works during generation.
3. No model loaded = mock engine with canned replies (labelled as such).

Tips: small instruct models (1B-3B, Q4_K_M) first. Phones with 4 GB RAM: 1B models.
Not every model/quantization runs. Loading too large a model can kill the app.

## What works (untested on a device by the author)
- Everything from Milestone 1 (chats, theme, system prompt)
- SAF import of .gguf (copied to app storage, header checked), load/unload/delete
- Chat template from the model (falls back to ChatML), streaming, stop
- Context length (auto from RAM), max tokens, temperature
- Prompt rebuilt each turn (no KV cache reuse yet); CPU only, no GPU

## Not built yet
Web search, VRM avatar, voice, floating overlay, summon shortcut (Milestones 3-7).

## Note
Not compiled by the author. JNI code targets llama.cpp v1.0.0 C API from memory plus
docs; if the Actions build fails, send the error log from the failing step.
