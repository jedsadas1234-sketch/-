// JNI bridge between Kotlin (NativeLlama) and llama.cpp.
// Not compiled by the author. Pinned to llama.cpp v1.0.0 (stable C API).
#include <jni.h>
#include <android/log.h>

#include <algorithm>
#include <cstdio>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include "llama.h"

#define TAG "PocketAI-llm"

namespace {

struct Engine {
    llama_model *model = nullptr;
    llama_context *ctx = nullptr;
    const llama_vocab *vocab = nullptr;
    int n_ctx = 0;
    std::mutex mu;  // held while generating or freeing
    bool alive = true;
};

std::mutex g_mu;
std::map<jlong, std::shared_ptr<Engine>> g_engines;
jlong g_next = 1;
bool g_backend_ready = false;

void log_cb(ggml_log_level level, const char *text, void *) {
    int prio = ANDROID_LOG_INFO;
    if (level == GGML_LOG_LEVEL_ERROR) prio = ANDROID_LOG_ERROR;
    else if (level == GGML_LOG_LEVEL_WARN) prio = ANDROID_LOG_WARN;
    __android_log_write(prio, TAG, text);
}

void throw_rt(JNIEnv *env, const std::string &msg) {
    jclass c = env->FindClass("java/lang/RuntimeException");
    if (c) env->ThrowNew(c, msg.c_str());
}

std::shared_ptr<Engine> find_engine(jlong h) {
    std::lock_guard<std::mutex> lk(g_mu);
    auto it = g_engines.find(h);
    return it == g_engines.end() ? nullptr : it->second;
}

std::string bytes_to_string(JNIEnv *env, jbyteArray arr) {
    jsize n = env->GetArrayLength(arr);
    std::string s((size_t) n, '\0');
    if (n > 0) env->GetByteArrayRegion(arr, 0, n, reinterpret_cast<jbyte *>(&s[0]));
    return s;
}

// Length of the longest prefix that does not end in the middle of a UTF-8 character.
size_t valid_prefix(const std::string &s) {
    size_t len = s.size();
    if (len == 0) return 0;
    size_t i = len;
    int back = 0;
    while (i > 0 && back < 4) {
        i--;
        back++;
        unsigned char c = (unsigned char) s[i];
        if ((c & 0xC0) != 0x80) break;
    }
    unsigned char lead = (unsigned char) s[i];
    if ((lead & 0xC0) == 0x80) return len;  // stray continuation bytes: let the Java decoder replace them
    size_t need = lead >= 0xF0 ? 4 : lead >= 0xE0 ? 3 : lead >= 0xC0 ? 2 : 1;
    return (len - i) >= need ? len : i;
}

struct SamplerGuard {
    llama_sampler *s;
    ~SamplerGuard() { if (s) llama_sampler_free(s); }
};

}  // namespace

extern "C" JNIEXPORT jlong JNICALL
Java_com_pocketai_app_llm_NativeLlama_load(JNIEnv *env, jobject, jstring jpath, jint n_ctx, jint n_threads) {
    const char *p = env->GetStringUTFChars(jpath, nullptr);
    std::string path(p);
    env->ReleaseStringUTFChars(jpath, p);

    {
        std::lock_guard<std::mutex> lk(g_mu);
        if (!g_backend_ready) {
            llama_log_set(log_cb, nullptr);
            llama_backend_init();
            g_backend_ready = true;
        }
    }

    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    mp.use_mmap = true;
    llama_model *model = llama_model_load_from_file(path.c_str(), mp);
    if (!model) {
        throw_rt(env, "Could not load model. The file may be corrupt, use an unsupported architecture, or be too large for this device.");
        return 0;
    }

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = (uint32_t) n_ctx;
    cp.n_batch = 512;
    cp.n_threads = n_threads;
    cp.n_threads_batch = n_threads;
    llama_context *ctx = llama_init_from_model(model, cp);
    if (!ctx) {
        llama_model_free(model);
        throw_rt(env, "Could not create context (out of memory?). Try a smaller context length.");
        return 0;
    }

    auto e = std::make_shared<Engine>();
    e->model = model;
    e->ctx = ctx;
    e->vocab = llama_model_get_vocab(model);
    e->n_ctx = (int) llama_n_ctx(ctx);

    std::lock_guard<std::mutex> lk(g_mu);
    jlong h = g_next++;
    g_engines[h] = e;
    return h;
}

extern "C" JNIEXPORT void JNICALL
Java_com_pocketai_app_llm_NativeLlama_unload(JNIEnv *, jobject, jlong h) {
    std::shared_ptr<Engine> e;
    {
        std::lock_guard<std::mutex> lk(g_mu);
        auto it = g_engines.find(h);
        if (it == g_engines.end()) return;
        e = it->second;
        g_engines.erase(it);
    }
    std::lock_guard<std::mutex> lk(e->mu);  // waits for a running generate() to finish
    if (e->ctx) llama_free(e->ctx);
    if (e->model) llama_model_free(e->model);
    e->ctx = nullptr;
    e->model = nullptr;
    e->alive = false;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_pocketai_app_llm_NativeLlama_describe(JNIEnv *env, jobject, jlong h) {
    auto e = find_engine(h);
    if (!e) return env->NewStringUTF("");
    std::lock_guard<std::mutex> lk(e->mu);
    if (!e->alive) return env->NewStringUTF("");
    char desc[256] = {0};
    llama_model_desc(e->model, desc, sizeof(desc));
    char out[512];
    snprintf(out, sizeof(out), "%.2fB params, %s", (double) llama_model_n_params(e->model) / 1e9, desc);
    // keep ASCII only so NewStringUTF is always valid
    for (char *c = out; *c; ++c) if ((unsigned char) *c > 127) *c = '?';
    return env->NewStringUTF(out);
}

extern "C" JNIEXPORT void JNICALL
Java_com_pocketai_app_llm_NativeLlama_generate(JNIEnv *env, jobject, jlong h,
                                               jobjectArray roles, jobjectArray contents,
                                               jint max_tokens, jfloat temp, jfloat top_p,
                                               jobject sink) {
    auto e = find_engine(h);
    if (!e) { throw_rt(env, "Model is not loaded."); return; }
    std::lock_guard<std::mutex> lk(e->mu);
    if (!e->alive) { throw_rt(env, "Model was unloaded."); return; }

    // ---- read messages ----
    jsize n = env->GetArrayLength(roles);
    std::vector<std::string> role_s((size_t) n), content_s((size_t) n);
    for (jsize i = 0; i < n; i++) {
        jstring r = (jstring) env->GetObjectArrayElement(roles, i);
        const char *rc = env->GetStringUTFChars(r, nullptr);
        role_s[i] = rc;
        env->ReleaseStringUTFChars(r, rc);
        env->DeleteLocalRef(r);
        jbyteArray c = (jbyteArray) env->GetObjectArrayElement(contents, i);
        content_s[i] = bytes_to_string(env, c);
        env->DeleteLocalRef(c);
    }

    // ---- chat template ----
    std::vector<llama_chat_message> msgs((size_t) n);
    size_t total = 0;
    for (jsize i = 0; i < n; i++) {
        msgs[i] = {role_s[i].c_str(), content_s[i].c_str()};
        total += content_s[i].size() + role_s[i].size();
    }
    const char *tmpl = llama_model_chat_template(e->model, nullptr);
    std::vector<char> buf(total * 2 + 2048);
    auto apply = [&](const char *t) -> int32_t {
        int32_t len = llama_chat_apply_template(t, msgs.data(), msgs.size(), true, buf.data(), (int32_t) buf.size());
        if (len > (int32_t) buf.size()) {
            buf.resize((size_t) len);
            len = llama_chat_apply_template(t, msgs.data(), msgs.size(), true, buf.data(), (int32_t) buf.size());
        }
        return len;
    };
    int32_t plen = tmpl ? apply(tmpl) : -1;
    if (plen < 0) plen = apply("chatml");  // model template unknown to llama.cpp: fall back to ChatML
    if (plen < 0) { throw_rt(env, "Chat template could not be applied."); return; }
    std::string prompt(buf.data(), (size_t) plen);

    // ---- tokenize ----
    const llama_vocab *vocab = e->vocab;
    int n_tok = -llama_tokenize(vocab, prompt.c_str(), (int32_t) prompt.size(), nullptr, 0, true, true);
    if (n_tok <= 0) { throw_rt(env, "Tokenization failed."); return; }
    std::vector<llama_token> toks((size_t) n_tok);
    if (llama_tokenize(vocab, prompt.c_str(), (int32_t) prompt.size(), toks.data(), n_tok, true, true) < 0) {
        throw_rt(env, "Tokenization failed.");
        return;
    }
    if (n_tok >= e->n_ctx - 8) {
        throw_rt(env, "Prompt too long (" + std::to_string(n_tok) + " tokens, context " +
                      std::to_string(e->n_ctx) + "). Start a new chat or raise the context length.");
        return;
    }
    int budget = std::min((int) max_tokens, e->n_ctx - n_tok);

    // ---- sink callback ----
    jclass sink_cls = env->GetObjectClass(sink);
    jmethodID mid = env->GetMethodID(sink_cls, "onToken", "([B)Z");
    if (!mid) return;  // NoSuchMethodError already pending
    auto emit = [&](const std::string &bytes) -> bool {
        jbyteArray arr = env->NewByteArray((jsize) bytes.size());
        if (!bytes.empty()) env->SetByteArrayRegion(arr, 0, (jsize) bytes.size(), reinterpret_cast<const jbyte *>(bytes.data()));
        jboolean keep = env->CallBooleanMethod(sink, mid, arr);
        env->DeleteLocalRef(arr);
        if (env->ExceptionCheck()) return false;
        return keep == JNI_TRUE;
    };

    // ---- prompt (KV cache is rebuilt every turn) ----
    llama_memory_clear(llama_get_memory(e->ctx), true);
    const int chunk = 512;
    for (int i = 0; i < n_tok; i += chunk) {
        int cnt = std::min(chunk, n_tok - i);
        llama_batch b = llama_batch_get_one(toks.data() + i, cnt);
        if (llama_decode(e->ctx, b) != 0) { throw_rt(env, "Decoding the prompt failed."); return; }
        if (!emit("")) return;  // empty chunk = cancellation poll
    }

    // ---- sampler ----
    SamplerGuard smpl{llama_sampler_chain_init(llama_sampler_chain_default_params())};
    if (temp <= 0.01f) {
        llama_sampler_chain_add(smpl.s, llama_sampler_init_greedy());
    } else {
        llama_sampler_chain_add(smpl.s, llama_sampler_init_top_k(40));
        llama_sampler_chain_add(smpl.s, llama_sampler_init_top_p(top_p, 1));
        llama_sampler_chain_add(smpl.s, llama_sampler_init_temp(temp));
        llama_sampler_chain_add(smpl.s, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    }

    // ---- generate ----
    std::string pending;
    bool stopped = false;
    for (int i = 0; i < budget; i++) {
        llama_token next = llama_sampler_sample(smpl.s, e->ctx, -1);
        if (llama_vocab_is_eog(vocab, next)) break;

        char piece[256];
        int32_t pl = llama_token_to_piece(vocab, next, piece, sizeof(piece), 0, true);
        if (pl < 0) {
            std::vector<char> big((size_t) -pl);
            pl = llama_token_to_piece(vocab, next, big.data(), (int32_t) big.size(), 0, true);
            if (pl > 0) pending.append(big.data(), (size_t) pl);
        } else {
            pending.append(piece, (size_t) pl);
        }

        size_t ok = valid_prefix(pending);
        if (ok > 0) {
            if (!emit(pending.substr(0, ok))) { stopped = true; break; }
            pending.erase(0, ok);
        }

        llama_batch b = llama_batch_get_one(&next, 1);
        if (llama_decode(e->ctx, b) != 0) { throw_rt(env, "Decoding failed."); return; }
    }
    if (env->ExceptionCheck()) return;
    if (!stopped && !pending.empty()) emit(pending);
}
