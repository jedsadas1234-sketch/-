package com.pocketai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pocketai.app.ui.ChatScreen
import com.pocketai.app.ui.ChatViewModel
import com.pocketai.app.ui.SettingsScreen
import com.pocketai.app.ui.theme.PocketTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val vm: ChatViewModel = viewModel()
            PocketTheme(vm.settings.themeMode) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    var showSettings by rememberSaveable { mutableStateOf(false) }
                    BackHandler(enabled = showSettings) { showSettings = false }
                    val reduce = vm.settings.reduceMotion
                    AnimatedContent(
                        targetState = showSettings,
                        transitionSpec = {
                            if (reduce) {
                                EnterTransition.None togetherWith ExitTransition.None
                            } else if (targetState) {
                                slideInHorizontally(tween(300)) { it } togetherWith
                                    slideOutHorizontally(tween(300)) { -it / 3 }
                            } else {
                                slideInHorizontally(tween(300)) { -it / 3 } togetherWith
                                    slideOutHorizontally(tween(300)) { it }
                            }
                        },
                        label = "screen",
                    ) { settingsOpen ->
                        if (settingsOpen) {
                            SettingsScreen(vm, onBack = { showSettings = false })
                        } else {
                            ChatScreen(vm, onOpenSettings = { showSettings = true })
                        }
                    }
                }
            }
        }
    }
}
