package com.pocketai.app.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pocketai.app.ai.AIProvider
import com.pocketai.app.ai.MockAIProvider
import com.pocketai.app.data.AppSettings
import com.pocketai.app.data.ChatMessage
import com.pocketai.app.data.Conversation
import com.pocketai.app.data.ConversationStore
import com.pocketai.app.data.DEFAULT_SYSTEM_PROMPT
import com.pocketai.app.data.MsgState
import com.pocketai.app.data.Role
import com.pocketai.app.data.SettingsStore
import com.pocketai.app.data.ThemeMode
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicLong

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val store = ConversationStore(app)
    private val settingsStore = SettingsStore(app)
    private val provider: AIProvider = MockAIProvider()
    private val ids = AtomicLong(System.currentTimeMillis())

    var conversations by mutableStateOf<List<Conversation>>(emptyList())
        private set
    var currentId by mutableLongStateOf(0L)
        private set
    var settings by mutableStateOf(settingsStore.load())
        private set
    var generating by mutableStateOf(false)
        private set

    private var job: Job? = null

    val engineName: String get() = provider.name

    val current: Conversation
        get() = conversations.firstOrNull { it.id == currentId } ?: conversations.first()

    init {
        val loaded = store.load()
        if (loaded.isEmpty()) {
            val c = emptyConversation()
            conversations = listOf(c)
            currentId = c.id
        } else {
            conversations = loaded
            currentId = loaded.first().id
        }
    }

    private fun emptyConversation() = Conversation(ids.incrementAndGet(), "New chat", emptyList())

    // ---- conversations ----

    fun newChat() {
        stop()
        if (current.messages.isEmpty()) return
        val c = emptyConversation()
        conversations = listOf(c) + conversations
        currentId = c.id
        persist()
    }

    fun select(id: Long) {
        if (id == currentId) return
        stop()
        currentId = id
    }

    fun delete(id: Long) {
        if (id == currentId) stop()
        var rest = conversations.filter { it.id != id }
        if (rest.isEmpty()) rest = listOf(emptyConversation())
        conversations = rest
        if (rest.none { it.id == currentId }) currentId = rest.first().id
        persist()
    }

    // ---- chat ----

    fun send(text: String) {
        val clean = text.trim()
        if (clean.isEmpty() || generating) return
        val convId = currentId
        val userMsg = ChatMessage(ids.incrementAndGet(), Role.USER, clean)
        updateConv(convId) { c ->
            c.copy(
                title = if (c.messages.isEmpty()) clean.take(32) else c.title,
                messages = c.messages + userMsg,
            )
        }
        startGeneration(convId)
    }

    fun stop() {
        job?.cancel()
    }

    /** Retry after a stopped or failed reply: drop that reply and generate again. */
    fun retry() {
        if (generating) return
        val convId = currentId
        val last = current.messages.lastOrNull() ?: return
        if (last.role != Role.ASSISTANT || (last.state != MsgState.STOPPED && last.state != MsgState.ERROR)) return
        updateConv(convId) { c -> c.copy(messages = c.messages.filter { it.id != last.id }) }
        startGeneration(convId)
    }

    private fun startGeneration(convId: Long) {
        val assistantId = ids.incrementAndGet()
        val history = conversations.first { it.id == convId }.messages
        updateConv(convId) { c ->
            c.copy(messages = c.messages + ChatMessage(assistantId, Role.ASSISTANT, "", MsgState.STREAMING))
        }
        val prompt = settings.systemPrompt
        generating = true
        job = viewModelScope.launch {
            val self = coroutineContext[Job]
            try {
                provider.generate(history, prompt).collect { chunk ->
                    updateMsg(convId, assistantId) { it.copy(text = it.text + chunk) }
                }
                updateMsg(convId, assistantId) { it.copy(text = it.text.trim(), state = MsgState.DONE) }
            } catch (e: CancellationException) {
                updateMsg(convId, assistantId) { it.copy(state = MsgState.STOPPED) }
                throw e
            } catch (e: Exception) {
                updateMsg(convId, assistantId) {
                    it.copy(state = MsgState.ERROR, error = e.message ?: e.javaClass.simpleName)
                }
            } finally {
                if (job === self) {
                    generating = false
                    job = null
                }
                persist()
            }
        }
    }

    private fun updateConv(id: Long, f: (Conversation) -> Conversation) {
        conversations = conversations.map { if (it.id == id) f(it) else it }
    }

    private fun updateMsg(convId: Long, msgId: Long, f: (ChatMessage) -> ChatMessage) {
        updateConv(convId) { c -> c.copy(messages = c.messages.map { if (it.id == msgId) f(it) else it }) }
    }

    private fun persist() = store.save(conversations)

    // ---- settings ----

    private fun updateSettings(f: (AppSettings) -> AppSettings) {
        settings = f(settings)
        settingsStore.save(settings)
    }

    fun setTheme(mode: ThemeMode) = updateSettings { it.copy(themeMode = mode) }
    fun setReduceMotion(on: Boolean) = updateSettings { it.copy(reduceMotion = on) }
    fun setSystemPrompt(text: String) = updateSettings { it.copy(systemPrompt = text) }
    fun resetSystemPrompt() = updateSettings { it.copy(systemPrompt = DEFAULT_SYSTEM_PROMPT) }
}
