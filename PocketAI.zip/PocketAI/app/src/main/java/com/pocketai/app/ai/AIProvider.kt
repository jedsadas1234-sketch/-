package com.pocketai.app.ai

import com.pocketai.app.data.ChatMessage
import com.pocketai.app.data.Role
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * Engine abstraction. Milestone 2 adds a llama.cpp-backed implementation
 * next to MockAIProvider without touching the UI.
 * Cancel the collecting coroutine to stop generation.
 */
interface AIProvider {
    val name: String
    fun generate(messages: List<ChatMessage>, systemPrompt: String): Flow<String>
}

/** Fake engine for the UI prototype. Not a real model. */
class MockAIProvider : AIProvider {
    override val name = "Mock engine (no real model yet)"

    override fun generate(messages: List<ChatMessage>, systemPrompt: String): Flow<String> = flow {
        delay(700)
        val last = messages.lastOrNull { it.role == Role.USER }?.text.orEmpty()
        val reply = buildReply(last, systemPrompt)
        for (word in reply.split(" ")) {
            emit("$word ")
            delay(40)
        }
    }

    private fun buildReply(userText: String, systemPrompt: String): String {
        val wantsCode = userText.contains("code", ignoreCase = true)
        val sb = StringBuilder()
        sb.append("**Mock reply.** No real model is loaded yet, so this is canned text. ")
        sb.append("You wrote: `${userText.take(80)}`. ")
        sb.append("System prompt in use: ${systemPrompt.length} characters.")
        if (wantsCode) {
            sb.append("\n\nHere is a sample code block:\n\n")
            sb.append("```kotlin\nfun greet(name: String) = \"Hello, \$name!\"\n```\n")
        }
        return sb.toString()
    }
}
