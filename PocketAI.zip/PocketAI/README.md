# Pocket AI — Milestone 1 (UI prototype)

Kotlin + Jetpack Compose. minSdk 26, targetSdk 34.

## Build APK on GitHub
1. Unzip, push the contents to a new GitHub repo (the `.github` folder must be in the repo root).
2. Open the Actions tab, run "Build APK" (it also runs on every push).
3. Download artifact `PocketAI-debug-apk`, unzip, install `app-debug.apk`.

## What works
- Chat with a MOCK engine (canned replies, no real model)
- Streaming text, stop button, retry after stop/error
- Multiple chats (drawer), switch, delete, saved on device
- Markdown subset: code blocks, **bold**, `inline code`; selectable text
- Light/Dark/System theme + Material You colors (Android 12+)
- Editable system instructions, reduce-motion switch

## Not built yet
Local GGUF model, web search, VRM avatar, voice, floating overlay, summon shortcut (Milestones 2-7).

## Note
This project was not compiled by the author before delivery. If the first
GitHub build fails, send the error log from the Actions run.
