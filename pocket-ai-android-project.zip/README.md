# Pocket AI (Android Source Project)

Native Android Kotlin + Jetpack Compose workspace implementing the Pocket AI specification:
- **8 Screens**: Main Chat, Model Manager (online + SAF `.gguf` import), Model Meeting Room, Collaboration Mode Selector (Sequential, Intelligent Collaboration, Supreme), Compatibility & Thermal Protection, History, Settings, and Feedback.
- **Honest Execution & Native Scaffold**: CMake/JNI bridge (`app/src/main/cpp/gguf_bridge.cpp`) explicitly reports whether `llama.cpp` is linked rather than faking inference or parallel execution.
- **GitHub Actions**: `.github/workflows/build-android.yml` builds and runs unit tests on `ubuntu-latest` with Android SDK & JDK 17.
