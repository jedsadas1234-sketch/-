#include <jni.h>
#include <string>
#include <android/log.h>

#define LOG_TAG "PocketAI_JNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

extern "C" JNIEXPORT jboolean JNICALL
Java_com_pocketai_workspace_runtime_LlamaCppNative_nativeIsLlamaCppLinked(
        JNIEnv* /* env */,
        jobject /* thiz */) {
    return JNI_FALSE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_pocketai_workspace_runtime_LlamaCppNative_nativeInspectGgufHeader(
        JNIEnv* env,
        jobject /* thiz */,
        jstring filePath) {
    const char* pathChars = env->GetStringUTFChars(filePath, nullptr);
    std::string pathStr(pathChars ? pathChars : "");
    env->ReleaseStringUTFChars(filePath, pathChars);

    std::string info = "Path: " + pathStr + " | llama.cpp native core not linked in base scaffold";
    return env->NewStringUTF(info.c_str());
}
