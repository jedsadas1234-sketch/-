cmake_minimum_required(VERSION 3.22.1)
project("pocketai_gguf")

add_library(
    pocketai_gguf
    SHARED
    gguf_bridge.cpp
)

find_library(
    log-lib
    log
)

target_link_libraries(
    pocketai_gguf
    ${log-lib}
)
