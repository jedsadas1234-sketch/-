package com.pocketai.workspace.platform

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import com.pocketai.workspace.model.AiModelConfig
import com.pocketai.workspace.model.CollaborationMode
import com.pocketai.workspace.model.CompatibilityReport
import com.pocketai.workspace.model.ConcernLevel
import com.pocketai.workspace.model.ModelSourceType

class DeviceCompatibilityMonitor(private val context: Context) {

    fun assess(
        selectedModels: List<AiModelConfig>,
        mode: CollaborationMode,
        allowParallelOnline: Boolean
    ): CompatibilityReport {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)

        val totalRamMb = memInfo.totalMem / (1024 * 1024)
        val availRamMb = memInfo.availMem / (1024 * 1024)

        val dataDir = Environment.getDataDirectory()
        val stat = StatFs(dataDir.path)
        val freeStorageMb = stat.availableBytes / (1024 * 1024)

        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"
        val sdk = Build.VERSION.SDK_INT

        val (thermalLabel, blocksWork, thermalSeverityScore) = readThermalState()

        val localModels = selectedModels.filter { it.sourceType == ModelSourceType.LOCAL_GGUF }
        val estimatedLocalMb = localModels.sumOf { cfg ->
            val fileMb = (cfg.fileSizeBytes ?: 0L) / (1024 * 1024)
            if (fileMb > 0) (fileMb * 1.25).toLong() else 2048L
        }

        val reasons = mutableListOf<String>()
        val recommendations = mutableListOf<String>()
        var riskPoints = 0

        if (thermalSeverityScore >= 3) {
            riskPoints += 3
            reasons.add("Device thermal status is " + thermalLabel + "; new inference workloads should pause to protect hardware.")
            recommendations.add("Let the device cool down before running multi-model or local GGUF tasks.")
        } else if (thermalSeverityScore == 2) {
            riskPoints += 1
            reasons.add("Device thermal status is " + thermalLabel + "; avoid unnecessary background or heavy parallel load.")
            recommendations.add("Prefer single-model or online models until thermal state returns to Normal.")
        }

        if (localModels.isNotEmpty()) {
            if (estimatedLocalMb > availRamMb * 0.75) {
                riskPoints += 2
                reasons.add("Estimated local model RAM footprint (~" + estimatedLocalMb + " MB) approaches or exceeds available RAM (" + availRamMb + " MB).")
                recommendations.add("Enable one local model at a time, reduce context length, or use a smaller quantization.")
            } else {
                reasons.add("Local GGUF models are loaded on-demand rather than all at once (estimated ~" + estimatedLocalMb + " MB).")
            }
        }

        if (freeStorageMb < 1500L && localModels.isNotEmpty()) {
            riskPoints += 2
            reasons.add("Available storage is low (" + freeStorageMb + " MB free) for GGUF files and temp buffers.")
            recommendations.add("Free up internal storage before importing larger GGUF models.")
        }

        val parallelRequested = allowParallelOnline &&
            selectedModels.count { it.sourceType == ModelSourceType.ONLINE_OPENAI_COMPATIBLE } > 1 &&
            localModels.isEmpty()

        val executionModeLabel = if (parallelRequested && mode == CollaborationMode.SUPREME) {
            "Parallel (configured online models only, no local GGUF contention)"
        } else {
            "Sequential / Queued (honest single-step or queued execution)"
        }

        if (selectedModels.size >= 4) {
            riskPoints += 1
            reasons.add("" + selectedModels.size + " models selected; multi-step rounds increase latency, token usage, and heat.")
            recommendations.add("Limit active team size or round count for faster responses.")
        }

        reasons.add("Compatibility checks inspect measurable device state; actual runtime behavior still depends on model weights, quantization, and runtime support.")

        val level = when {
            riskPoints >= 3 -> ConcernLevel.HIGH
            riskPoints >= 1 -> ConcernLevel.MODERATE
            else -> ConcernLevel.LOW
        }

        return CompatibilityReport(
            concernLevel = level,
            totalRamMb = totalRamMb,
            availableRamMb = availRamMb,
            freeStorageMb = freeStorageMb,
            abi = abi,
            androidSdk = sdk,
            thermalStatusLabel = thermalLabel,
            thermalBlocksNewWork = blocksWork,
            executionModeLabel = executionModeLabel,
            reasons = reasons,
            recommendations = recommendations
        )
    }

    private fun readThermalState(): Triple<String, Boolean, Int> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return Triple("Not exposed (< Android 10)", false, 0)
        }
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            ?: return Triple("Unavailable", false, 0)

        return when (pm.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> Triple("Normal (None)", false, 0)
            PowerManager.THERMAL_STATUS_LIGHT -> Triple("Light", false, 1)
            PowerManager.THERMAL_STATUS_MODERATE -> Triple("Elevated (Moderate)", false, 2)
            PowerManager.THERMAL_STATUS_SEVERE -> Triple("Critical (Severe)", true, 3)
            PowerManager.THERMAL_STATUS_CRITICAL -> Triple("Critical", true, 3)
            PowerManager.THERMAL_STATUS_EMERGENCY -> Triple("Emergency", true, 4)
            PowerManager.THERMAL_STATUS_SHUTDOWN -> Triple("Shutdown imminent", true, 4)
            else -> Triple("Unknown", false, 0)
        }
    }
}
