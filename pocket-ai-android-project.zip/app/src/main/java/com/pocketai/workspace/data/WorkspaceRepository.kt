package com.pocketai.workspace.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.pocketai.workspace.model.AiModelConfig
import com.pocketai.workspace.model.AppSettingsState
import com.pocketai.workspace.model.ChatThread
import com.pocketai.workspace.model.ModelRole
import com.pocketai.workspace.model.ModelSourceType
import com.pocketai.workspace.model.TeamMeetingRecord
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "pocket_ai_store")

class WorkspaceRepository(private val context: Context) {
    private val json = Json {
        ignoreUnknownKeys = true
        prettyPrint = false
    }

    private object Keys {
        val MODELS = stringPreferencesKey("models_json")
        val THREADS = stringPreferencesKey("threads_json")
        val SETTINGS = stringPreferencesKey("settings_json")
        val MEETING = stringPreferencesKey("meeting_json")
    }

    val modelsFlow: Flow<List<AiModelConfig>> = context.dataStore.data.map { prefs ->
        val raw = prefs[Keys.MODELS]
        if (raw.isNullOrBlank()) {
            defaultModels()
        } else {
            runCatching { json.decodeFromString<List<AiModelConfig>>(raw) }.getOrElse { defaultModels() }
        }
    }

    val threadsFlow: Flow<List<ChatThread>> = context.dataStore.data.map { prefs ->
        val raw = prefs[Keys.THREADS]
        if (raw.isNullOrBlank()) emptyList()
        else runCatching { json.decodeFromString<List<ChatThread>>(raw) }.getOrElse { emptyList() }
    }

    val settingsFlow: Flow<AppSettingsState> = context.dataStore.data.map { prefs ->
        val raw = prefs[Keys.SETTINGS]
        if (raw.isNullOrBlank()) AppSettingsState()
        else runCatching { json.decodeFromString<AppSettingsState>(raw) }.getOrElse { AppSettingsState() }
    }

    val meetingFlow: Flow<TeamMeetingRecord?> = context.dataStore.data.map { prefs ->
        val raw = prefs[Keys.MEETING]
        if (raw.isNullOrBlank()) null
        else runCatching { json.decodeFromString<TeamMeetingRecord>(raw) }.getOrNull()
    }

    suspend fun saveModels(models: List<AiModelConfig>) {
        context.dataStore.edit { it[Keys.MODELS] = json.encodeToString(models) }
    }

    suspend fun saveThreads(threads: List<ChatThread>) {
        context.dataStore.edit { it[Keys.THREADS] = json.encodeToString(threads) }
    }

    suspend fun saveSettings(settings: AppSettingsState) {
        context.dataStore.edit { it[Keys.SETTINGS] = json.encodeToString(settings) }
    }

    suspend fun saveMeeting(meeting: TeamMeetingRecord?) {
        context.dataStore.edit {
            if (meeting == null) it.remove(Keys.MEETING)
            else it[Keys.MEETING] = json.encodeToString(meeting)
        }
    }

    private fun defaultModels(): List<AiModelConfig> = listOf(
        AiModelConfig(
            id = "model_main_default",
            name = "Primary Cloud Model",
            sourceType = ModelSourceType.ONLINE_OPENAI_COMPATIBLE,
            providerName = "OpenAI-Compatible",
            modelIdentifier = "gpt-4o-mini",
            role = ModelRole.MAIN,
            enabled = true,
            isLoaded = false
        ),
        AiModelConfig(
            id = "model_reviewer_default",
            name = "Critique & Review Model",
            sourceType = ModelSourceType.ONLINE_OPENAI_COMPATIBLE,
            providerName = "OpenAI-Compatible",
            modelIdentifier = "gpt-4o-mini",
            role = ModelRole.REVIEWER,
            enabled = false,
            isLoaded = false
        )
    )
}
