package com.pocketai.workspace.orchestrator

import com.pocketai.workspace.model.AiModelConfig
import com.pocketai.workspace.model.CollaborationMode
import com.pocketai.workspace.model.MemberIntro
import com.pocketai.workspace.model.ModelSourceType
import com.pocketai.workspace.model.SearchCitation
import com.pocketai.workspace.model.TeamMeetingRecord
import com.pocketai.workspace.network.OnlineClients
import com.pocketai.workspace.runtime.LlamaCppNative
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope

data class CollaborationResult(
    val finalText: String,
    val executionNote: String,
    val citations: List<SearchCitation> = emptyList(),
    val isError: Boolean = false
)

class CollaborationEngine(
    private val onlineClients: OnlineClients,
    private val nativeBridge: LlamaCppNative,
    private val endpointUrl: String,
    private val apiKey: String
) {
    private suspend fun askModel(
        model: AiModelConfig,
        systemPrompt: String,
        userPrompt: String
    ): Result<String> {
        if (!model.enabled) {
            return Result.failure(IllegalStateException("Model '" + model.name + "' is disabled."))
        }
        return when (model.sourceType) {
            ModelSourceType.ONLINE_OPENAI_COMPATIBLE -> {
                onlineClients.chatCompletion(
                    endpointUrl = endpointUrl,
                    apiKey = apiKey,
                    model = model,
                    systemPrompt = systemPrompt,
                    userPrompt = userPrompt
                )
            }
            ModelSourceType.LOCAL_GGUF -> {
                if (!nativeBridge.isLlamaCppLinked()) {
                    Result.failure(
                        IllegalStateException(
                            "Local GGUF '" + model.name + "' cannot run inference because llama.cpp native library is not linked in this build."
                        )
                    )
                } else {
                    Result.failure(
                        IllegalStateException(
                            "Local GGUF '" + model.name + "' native runner hook is pending llama.cpp C++ completion implementation."
                        )
                    )
                }
            }
        }
    }

    suspend fun runTask(
        prompt: String,
        enabledModels: List<AiModelConfig>,
        mode: CollaborationMode,
        maxRounds: Int,
        allowParallelOnline: Boolean,
        synthesizerId: String? = null,
        citations: List<SearchCitation> = emptyList(),
        onProgress: (String) -> Unit
    ): CollaborationResult {
        if (enabledModels.isEmpty()) {
            return CollaborationResult(
                finalText = "No enabled models available. Enable at least one model in Model Manager.",
                executionNote = "Aborted: empty model roster",
                isError = true
            )
        }

        val groundedPrompt = if (citations.isNotEmpty()) {
            buildString {
                appendLine(prompt)
                appendLine()
                appendLine("Retrieved web sources (cite only from these when making factual claims):")
                citations.forEachIndexed { idx, c ->
                    appendLine("[" + (idx + 1) + "] " + c.title + " (" + c.url + ") - " + c.snippet)
                }
            }
        } else {
            prompt
        }

        val mainModel = enabledModels.first()
        val supporters = enabledModels.drop(1)

        return when (mode) {
            CollaborationMode.SEQUENTIAL -> {
                onProgress("Sequential: " + mainModel.name + " drafting initial response...")
                val initialRes = askModel(
                    mainModel,
                    "You are " + mainModel.name + " with role " + mainModel.role.label + ". Provide a clear initial response.",
                    groundedPrompt
                )
                if (initialRes.isFailure) {
                    return CollaborationResult(
                        finalText = "Main model (" + mainModel.name + ") failed: " + initialRes.exceptionOrNull()?.message,
                        executionNote = "Sequential failed at Main",
                        isError = true
                    )
                }

                var currentDraft = initialRes.getOrThrow()
                val trace = StringBuilder()
                trace.appendLine("### Step 1 — " + mainModel.name + " (" + mainModel.role.label + ") [Initial]")
                trace.appendLine(currentDraft)
                trace.appendLine()

                for ((index, sup) in supporters.withIndex()) {
                    onProgress("Sequential: " + sup.name + " (" + (index + 2) + "/" + enabledModels.size + ") reviewing...")
                    val rev = askModel(
                        sup,
                        "You are " + sup.name + " with role " + sup.role.label + ". Review, verify, challenge, or expand the current work honestly.",
                        "User prompt:\n" + groundedPrompt + "\n\nCurrent draft:\n" + currentDraft
                    )
                    if (rev.isSuccess) {
                        val note = rev.getOrThrow()
                        trace.appendLine("### Step " + (index + 2) + " — " + sup.name + " (" + sup.role.label + ")")
                        trace.appendLine(note)
                        trace.appendLine()
                        currentDraft = note
                    } else {
                        trace.appendLine("### Step " + (index + 2) + " — " + sup.name + " [Failed]")
                        trace.appendLine("Error: " + rev.exceptionOrNull()?.message)
                        trace.appendLine()
                    }
                }

                if (supporters.isNotEmpty()) {
                    onProgress("Sequential: " + mainModel.name + " producing final answer...")
                    val finalRes = askModel(
                        mainModel,
                        "You are " + mainModel.name + " (" + mainModel.role.label + "). Produce the final answer incorporating valid points while preserving disagreements.",
                        "User prompt:\n" + groundedPrompt + "\n\nCollaboration trace:\n" + trace
                    )
                    if (finalRes.isSuccess) {
                        trace.appendLine("### Final — " + mainModel.name)
                        trace.appendLine(finalRes.getOrThrow())
                    }
                }

                CollaborationResult(
                    finalText = trace.toString().trim(),
                    executionNote = "Sequential execution across " + enabledModels.size + " model(s)",
                    citations = citations
                )
            }

            CollaborationMode.INTELLIGENT_COLLABORATION -> {
                val boundedRounds = maxRounds.coerceIn(1, 4)
                val log = StringBuilder()
                onProgress("Intelligent Collaboration: " + mainModel.name + " starting round 1/" + boundedRounds + "...")
                val draftRes = askModel(
                    mainModel,
                    "You are " + mainModel.name + " (" + mainModel.role.label + "). Coordinate the solution and state assumptions/uncertainties.",
                    groundedPrompt
                )
                if (draftRes.isFailure) {
                    return CollaborationResult(
                        finalText = "Coordination failed on " + mainModel.name + ": " + draftRes.exceptionOrNull()?.message,
                        executionNote = "Intelligent Collaboration failed",
                        isError = true
                    )
                }
                var currentWork = draftRes.getOrThrow()
                log.appendLine("### " + mainModel.name + " (" + mainModel.role.label + ") — Initial Position")
                log.appendLine(currentWork)
                log.appendLine()

                for (round in 1..boundedRounds) {
                    for (sup in supporters) {
                        onProgress("Round " + round + "/" + boundedRounds + ": " + sup.name + " critiquing...")
                        val critique = askModel(
                            sup,
                            "You are " + sup.name + " (" + sup.role.label + "). Independently critique or challenge the current work. Do not force agreement; note real risks or disagreements.",
                            "Prompt:\n" + groundedPrompt + "\n\nCurrent work:\n" + currentWork
                        )
                        val critiqueText = critique.getOrElse { "Error: " + it.message }
                        log.appendLine("### Round " + round + " — " + sup.name + " (" + sup.role.label + ")")
                        log.appendLine(critiqueText)
                        log.appendLine()
                    }
                    onProgress("Round " + round + "/" + boundedRounds + ": " + mainModel.name + " responding...")
                    val mainReply = askModel(
                        mainModel,
                        "You are " + mainModel.name + " (" + mainModel.role.label + "). Address critiques, preserve unresolved disagreements honestly, and refine the work.",
                        "Prompt:\n" + groundedPrompt + "\n\nDiscussion so far:\n" + log
                    )
                    if (mainReply.isSuccess) {
                        currentWork = mainReply.getOrThrow()
                        log.appendLine("### Round " + round + " Synthesis — " + mainModel.name)
                        log.appendLine(currentWork)
                        log.appendLine()
                    }
                }

                CollaborationResult(
                    finalText = log.toString().trim(),
                    executionNote = "Sequential turn-based rounds (" + boundedRounds + " round(s))",
                    citations = citations
                )
            }

            CollaborationMode.SUPREME -> {
                val panel = enabledModels.take(4)
                val synth = enabledModels.firstOrNull { it.id == synthesizerId } ?: mainModel
                val canRunParallel = allowParallelOnline &&
                    panel.all { it.sourceType == ModelSourceType.ONLINE_OPENAI_COMPATIBLE }

                val analyses: List<Pair<AiModelConfig, Result<String>>> = if (canRunParallel) {
                    onProgress("Supreme (Parallel): querying " + panel.size + " online models concurrently...")
                    coroutineScope {
                        panel.map { m ->
                            async {
                                m to askModel(
                                    m,
                                    "You are " + m.name + " (" + m.role.label + "). Provide a focused independent analysis of the prompt.",
                                    groundedPrompt
                                )
                            }
                        }.awaitAll()
                    }
                } else {
                    onProgress("Supreme (Queued/Sequential): analyzing with " + panel.size + " model(s)...")
                    val list = mutableListOf<Pair<AiModelConfig, Result<String>>>()
                    for ((idx, m) in panel.withIndex()) {
                        onProgress("Supreme (" + (idx + 1) + "/" + panel.size + "): " + m.name + " analyzing...")
                        list.add(
                            m to askModel(
                                m,
                                "You are " + m.name + " (" + m.role.label + "). Provide a focused independent analysis of the prompt.",
                                groundedPrompt
                            )
                        )
                    }
                    list
                }

                val collected = analyses.joinToString("\n\n") { (m, res) ->
                    val body = res.getOrElse { "Failed: " + it.message }
                    "Analysis by " + m.name + " [" + m.role.label + "]:\n" + body
                }

                onProgress("Supreme: " + synth.name + " synthesizing final output...")
                val synthRes = askModel(
                    synth,
                    "You are " + synth.name + " acting as Synthesizer. Combine the collected analyses into a clear final response while flagging conflicts or missing info.",
                    "Original prompt:\n" + groundedPrompt + "\n\nCollected analyses:\n" + collected
                )

                val finalOutput = buildString {
                    appendLine(collected)
                    appendLine()
                    appendLine("### Synthesizer Output — " + synth.name)
                    appendLine(synthRes.getOrElse { "Synthesizer failed: " + it.message })
                }.trim()

                val execLabel = if (canRunParallel) {
                    "Parallel analysis (" + panel.size + " models) -> " + synth.name + " synthesis"
                } else {
                    "Sequential/Queued analysis (" + panel.size + " models) -> " + synth.name + " synthesis"
                }

                CollaborationResult(
                    finalText = finalOutput,
                    executionNote = execLabel,
                    citations = citations
                )
            }
        }
    }

    suspend fun runTeamMeeting(
        enabledModels: List<AiModelConfig>,
        maxRounds: Int,
        onProgress: (String) -> Unit
    ): TeamMeetingRecord {
        val boundedRounds = maxRounds.coerceIn(1, 3)
        val intros = mutableListOf<MemberIntro>()
        val rosterText = enabledModels.joinToString("\n") {
            "- " + it.name + " (id=" + it.id + ", source=" + it.sourceType.name + ", role=" + it.role.label + ", quant=" + (it.quantization ?: "n/a") + ")"
        }

        for ((idx, m) in enabledModels.withIndex()) {
            onProgress("Meeting round 1/" + boundedRounds + ": " + m.name + " (" + (idx + 1) + "/" + enabledModels.size + ") introducing...")
            val verifiedMeta = "Source=" + m.sourceType.name + ", Provider=" + m.providerName + ", ModelId=" + m.modelIdentifier + ", ConfiguredRole=" + m.role.label
            val res = askModel(
                m,
                "Introduce yourself to your AI teammates concisely. State: 1) runtime identity, 2) strengths, 3) limitations/uncertainty, 4) suggested role, 5) preferred working style. Do not claim capabilities not backed by your setup.",
                "Team roster:\n" + rosterText
            )
            val raw = res.getOrElse { "Unable to generate self-introduction: " + it.message }
            intros.add(
                MemberIntro(
                    modelId = m.id,
                    modelName = m.name,
                    verifiedMetadata = verifiedMeta,
                    runtimeIdentityClaim = if (res.isSuccess) m.modelIdentifier else "Unavailable",
                    strengths = if (res.isSuccess) raw else "N/A (runtime error)",
                    limitations = if (res.isSuccess) "Self-reported only; verify against actual task performance." else (res.exceptionOrNull()?.message ?: "Runtime unavailable"),
                    suggestedRole = m.role.label,
                    workingStyle = if (res.isSuccess) "See self-introduction above" else "Offline/Unconfigured",
                    peerReviewNote = if (boundedRounds >= 2 && res.isSuccess) "Reviewed team roster of " + enabledModels.size + " member(s)." else "Single-round intro recorded.",
                    statusNote = if (res.isSuccess) "Responded" else "Error / Unavailable"
                )
            )
        }

        val assignments = enabledModels.associate { it.id to it.role }
        val rosterSig = enabledModels.joinToString("|") { it.id + ":" + it.role.name + ":" + it.enabled }
        val summary = buildString {
            appendLine("Team size: " + enabledModels.size + " enabled model(s).")
            appendLine("Verified metadata is shown separately from each model's self-description.")
            enabledModels.forEach {
                appendLine("* " + it.name + " -> Role: " + it.role.label + " (" + it.sourceType.name + ")")
            }
        }.trim()

        return TeamMeetingRecord(
            id = "meeting_" + System.currentTimeMillis(),
            rosterSignature = rosterSig,
            createdAtMs = System.currentTimeMillis(),
            roundsCompleted = boundedRounds,
            maxRounds = boundedRounds,
            intros = intros,
            teamSummary = summary,
            suggestedRoleAssignments = assignments
        )
    }
}
