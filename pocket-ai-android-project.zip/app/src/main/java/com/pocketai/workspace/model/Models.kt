package com.pocketai.workspace.model

import kotlinx.serialization.Serializable

@Serializable
enum class ModelSourceType {
    LOCAL_GGUF,
    ONLINE_OPENAI_COMPATIBLE
}

@Serializable
enum class ModelRole(val label: String) {
    MAIN("Main"),
    REVIEWER("Reviewer"),
    RESEARCHER("Researcher"),
    PROGRAMMER("Programmer"),
    ANALYST("Analyst"),
    SYNTHESIZER("Synthesizer")
}

@Serializable
enum class CollaborationMode(val title: String, val subtitle: String) {
    SEQUENTIAL(
        "Sequential",
        "Main drafts -> Supporting models review/expand in order -> Main finalizes"
    ),
    INTELLIGENT_COLLABORATION(
        "Intelligent Collaboration",
        "Main coordinates -> Supporting critique & debate (bounded rounds) -> Main synthesizes"
    ),
    SUPREME(
        "Supreme",
        "Up to 4 models analyze -> Chosen Synthesizer produces final answer"
    )
}

@Serializable
enum class ChatRoutingMode(val label: String) {
    OFFLINE("Offline"),
    SEARCH("Search"),
    AUTO("Auto")
}

@Serializable
enum class ThemePreference(val label: String) {
    SYSTEM("System"),
    LIGHT("Light"),
    DARK("Dark")
}

@Serializable
enum class FeedbackCategory(val label: String) {
    BUG("Bug"),
    UI_UX("UI/UX"),
    PERFORMANCE("Performance"),
    MODEL_COMPATIBILITY("Model Compatibility"),
    COLLABORATION_ISSUE("Collaboration Issue"),
    FEATURE_SUGGESTION("Feature Suggestion"),
    OTHER("Other")
}

@Serializable
data class AiModelConfig(
    val id: String,
    val name: String,
    val sourceType: ModelSourceType,
    val providerName: String,
    val modelIdentifier: String,
    val role: ModelRole = ModelRole.MAIN,
    val enabled: Boolean = true,
    val fileSizeBytes: Long? = null,
    val quantization: String? = null,
    val contextLength: Int = 4096,
    val isLoaded: Boolean = false,
    val fileAccessible: Boolean = true
)

@Serializable
data class SearchCitation(
    val title: String,
    val url: String,
    val snippet: String
)

@Serializable
data class ChatMessage(
    val id: String,
    val sender: String,
    val content: String,
    val timestampMs: Long,
    val isUser: Boolean,
    val isError: Boolean = false,
    val executionNote: String? = null,
    val citations: List<SearchCitation> = emptyList()
)

@Serializable
data class ChatThread(
    val id: String,
    val title: String,
    val createdAtMs: Long,
    val updatedAtMs: Long,
    val mode: CollaborationMode,
    val routingMode: ChatRoutingMode,
    val messages: List<ChatMessage> = emptyList()
)

@Serializable
data class MemberIntro(
    val modelId: String,
    val modelName: String,
    val verifiedMetadata: String,
    val runtimeIdentityClaim: String,
    val strengths: String,
    val limitations: String,
    val suggestedRole: String,
    val workingStyle: String,
    val peerReviewNote: String,
    val statusNote: String
)

@Serializable
data class TeamMeetingRecord(
    val id: String,
    val rosterSignature: String,
    val createdAtMs: Long,
    val roundsCompleted: Int,
    val maxRounds: Int,
    val intros: List<MemberIntro>,
    val teamSummary: String,
    val suggestedRoleAssignments: Map<String, ModelRole>
)

@Serializable
data class AppSettingsState(
    val theme: ThemePreference = ThemePreference.SYSTEM,
    val defaultContextLength: Int = 4096,
    val maxCollaborationRounds: Int = 2,
    val allowParallelOnlineCalls: Boolean = false,
    val onlineEndpointUrl: String = "https://api.openai.com/v1/chat/completions",
    val onlineApiKey: String = "",
    val searchEndpointUrl: String = "",
    val searchApiKey: String = "",
    val includeDiagnosticsInFeedback: Boolean = false
)

enum class ConcernLevel(val label: String) {
    LOW("Low concern"),
    MODERATE("Moderate concern"),
    HIGH("High concern")
}

data class CompatibilityReport(
    val concernLevel: ConcernLevel,
    val totalRamMb: Long,
    val availableRamMb: Long,
    val freeStorageMb: Long,
    val abi: String,
    val androidSdk: Int,
    val thermalStatusLabel: String,
    val thermalBlocksNewWork: Boolean,
    val executionModeLabel: String,
    val reasons: List<String>,
    val recommendations: List<String>
)
