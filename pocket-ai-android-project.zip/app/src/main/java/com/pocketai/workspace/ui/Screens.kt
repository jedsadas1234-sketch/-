package com.pocketai.workspace.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.pocketai.workspace.model.*
import com.pocketai.workspace.viewmodel.AppScreen
import com.pocketai.workspace.viewmodel.PocketAiUiState
import com.pocketai.workspace.viewmodel.PocketAiViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PocketAiAppShell(vm: PocketAiViewModel, state: PocketAiUiState) {
    var currentScreen by remember { mutableStateOf(AppScreen.CHAT) }
    val primaryNav = listOf(
        AppScreen.CHAT,
        AppScreen.MODELS,
        AppScreen.MEETING,
        AppScreen.COLLABORATION,
        AppScreen.COMPATIBILITY
    )
    val secondaryScreens = listOf(AppScreen.HISTORY, AppScreen.SETTINGS, AppScreen.FEEDBACK)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Pocket AI — " + currentScreen.title) },
                actions = {
                    secondaryScreens.forEach { scr ->
                        IconButton(onClick = { currentScreen = scr }) {
                            Icon(
                                imageVector = when (scr) {
                                    AppScreen.HISTORY -> Icons.Default.History
                                    AppScreen.SETTINGS -> Icons.Default.Settings
                                    AppScreen.FEEDBACK -> Icons.Default.Feedback
                                    else -> Icons.Default.Info
                                },
                                contentDescription = scr.title
                            )
                        }
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                primaryNav.forEach { screen ->
                    NavigationBarItem(
                        selected = currentScreen == screen,
                        onClick = { currentScreen = screen },
                        icon = {
                            Icon(
                                imageVector = when (screen) {
                                    AppScreen.CHAT -> Icons.Default.Chat
                                    AppScreen.MODELS -> Icons.Default.Memory
                                    AppScreen.MEETING -> Icons.Default.Groups
                                    AppScreen.COLLABORATION -> Icons.Default.Hub
                                    AppScreen.COMPATIBILITY -> Icons.Default.Speed
                                    else -> Icons.Default.Circle
                                },
                                contentDescription = screen.title
                            )
                        },
                        label = { Text(screen.title, maxLines = 1) }
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            state.statusBanner?.let { banner ->
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = banner,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            when (currentScreen) {
                AppScreen.CHAT -> MainChatScreen(vm, state)
                AppScreen.MODELS -> ModelManagerScreen(vm, state)
                AppScreen.MEETING -> MeetingRoomScreen(vm, state)
                AppScreen.COLLABORATION -> CollaborationModeScreen(vm, state)
                AppScreen.COMPATIBILITY -> CompatibilityScreen(vm, state)
                AppScreen.HISTORY -> HistoryScreen(vm, state) { currentScreen = AppScreen.CHAT }
                AppScreen.SETTINGS -> SettingsScreen(vm, state)
                AppScreen.FEEDBACK -> FeedbackScreen(vm, state)
            }
        }
    }
}

@Composable
fun MainChatScreen(vm: PocketAiViewModel, state: PocketAiUiState) {
    val context = LocalContext.current
    var input by remember { mutableStateOf("") }
    val activeThread = state.threads.find { it.id == state.activeThreadId }
    val messages = activeThread?.messages ?: emptyList()

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ChatRoutingMode.entries.forEach { rm ->
                FilterChip(
                    selected = state.routingMode == rm,
                    onClick = { vm.setRoutingMode(rm) },
                    label = { Text(rm.label) }
                )
            }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { vm.startNewThread() }) {
                Text("New")
            }
        }

        Text(
            text = "Mode: " + state.collaborationMode.title + " | Enabled: " + state.models.count { it.enabled },
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(vertical = 4.dp)
        )

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (msg.isUser) MaterialTheme.colorScheme.primaryContainer
                        else if (msg.isError) MaterialTheme.colorScheme.errorContainer
                        else MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = msg.sender,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelLarge,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = {
                                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    cm.setPrimaryClip(ClipData.newPlainText("PocketAI", msg.content))
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy", modifier = Modifier.size(16.dp))
                            }
                        }
                        if (msg.executionNote != null) {
                            Text(
                                text = msg.executionNote,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = msg.content,
                            style = MaterialTheme.typography.bodyMedium,
                            fontFamily = if (msg.content.contains("```") || msg.content.contains("###")) FontFamily.Monospace else FontFamily.Default
                        )
                        if (msg.citations.isNotEmpty()) {
                            Spacer(Modifier.height(6.dp))
                            Text("Sources:", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelSmall)
                            msg.citations.forEach { c ->
                                Text("• " + c.title + " — " + c.url, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        if (msg.isError && !msg.isUser) {
                            TextButton(onClick = { vm.retryLastPrompt() }) {
                                Text("Retry")
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ask the model team...") },
                maxLines = 4
            )
            if (state.isGenerating) {
                Button(onClick = { vm.cancelGeneration() }) {
                    Text("Cancel")
                }
            } else {
                Button(
                    onClick = {
                        val text = input
                        input = ""
                        vm.sendMessage(text)
                    }
                ) {
                    Text("Send")
                }
            }
        }
    }
}

@Composable
fun ModelManagerScreen(vm: PocketAiViewModel, state: PocketAiUiState) {
    var name by remember { mutableStateOf("") }
    var provider by remember { mutableStateOf("OpenAI-Compatible") }
    var modelId by remember { mutableStateOf("gpt-4o-mini") }
    val role by remember { mutableStateOf(ModelRole.ANALYST) }

    val safPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) vm.importGgufFromSaf(uri)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Add Online Model", fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Display Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = provider, onValueChange = { provider = it }, label = { Text("Provider") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = modelId, onValueChange = { modelId = it }, label = { Text("Model ID") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = { vm.addOnlineModel(name, provider, modelId, role); name = "" }) {
                            Text("Add Model")
                        }
                        OutlinedButton(onClick = { safPicker.launch(arrayOf("*/*")) }) {
                            Text("Import .gguf (SAF)")
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { vm.unloadAllLocalModels() }) {
                            Text("Unload Local GGUF")
                        }
                        Text(
                            text = "Native llama.cpp: " + (if (state.nativeLlamaLinked) "Linked" else "Not linked"),
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.align(Alignment.CenterVertically)
                        )
                    }
                }
            }
        }

        items(state.models, key = { it.id }) { model ->
            val slotLabel = if (state.models.firstOrNull()?.id == model.id) "MAIN SLOT" else "SUPPORTING SLOT"
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(model.name + " (" + slotLabel + ")", fontWeight = FontWeight.Bold)
                            Text(
                                text = model.sourceType.name + " • " + model.providerName + " • Role: " + model.role.label,
                                style = MaterialTheme.typography.bodySmall
                            )
                            if (model.sourceType == ModelSourceType.LOCAL_GGUF) {
                                val sizeMb = (model.fileSizeBytes ?: 0L) / (1024 * 1024)
                                Text(
                                    text = "Quant: " + (model.quantization ?: "unknown") + " • Size: " + sizeMb + " MB • Loaded: " + model.isLoaded,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                        Switch(
                            checked = model.enabled,
                            onCheckedChange = { vm.toggleModelEnabled(model.id, it) }
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TextButton(onClick = { vm.promoteToMain(model.id) }) { Text("Make Main") }
                        TextButton(onClick = { vm.moveModel(model.id, -1) }) { Text("Up") }
                        TextButton(onClick = { vm.moveModel(model.id, 1) }) { Text("Down") }
                        TextButton(onClick = { vm.removeModel(model.id) }) { Text("Remove") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(ModelRole.MAIN, ModelRole.REVIEWER, ModelRole.RESEARCHER, ModelRole.PROGRAMMER, ModelRole.ANALYST, ModelRole.SYNTHESIZER).forEach { r ->
                            FilterChip(
                                selected = model.role == r,
                                onClick = { vm.setModelRole(model.id, r) },
                                label = { Text(r.label, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MeetingRoomScreen(vm: PocketAiViewModel, state: PocketAiUiState) {
    val meeting = state.meeting
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Model Meeting Room", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("Enabled models introduce themselves, state limitations honestly, and propose roles. Saved until roster changes or refreshed.")
                    if (state.isMeetingRunning) {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        Text(state.meetingProgress ?: "Running meeting...", style = MaterialTheme.typography.bodySmall)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { vm.startTeamMeeting(forceRefresh = false) },
                            enabled = !state.isMeetingRunning
                        ) {
                            Text("Start / Load Meeting")
                        }
                        OutlinedButton(
                            onClick = { vm.startTeamMeeting(forceRefresh = true) },
                            enabled = !state.isMeetingRunning
                        ) {
                            Text("Refresh Now")
                        }
                    }
                }
            }
        }

        if (meeting != null) {
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Team Summary (Rounds: " + meeting.roundsCompleted + "/" + meeting.maxRounds + ")", fontWeight = FontWeight.Bold)
                        Text(meeting.teamSummary, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            items(meeting.intros, key = { it.modelId }) { intro ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(intro.modelName + " — " + intro.statusNote, fontWeight = FontWeight.Bold)
                        Text("Verified metadata: " + intro.verifiedMetadata, style = MaterialTheme.typography.labelSmall)
                        Text("Strengths / Intro: " + intro.strengths, style = MaterialTheme.typography.bodySmall)
                        Text("Limitations & Uncertainty: " + intro.limitations, style = MaterialTheme.typography.bodySmall)
                        Text("Suggested Role: " + intro.suggestedRole + " | " + intro.peerReviewNote, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
fun CollaborationModeScreen(vm: PocketAiViewModel, state: PocketAiUiState) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Collaboration Modes", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        CollaborationMode.entries.forEach { mode ->
            Card(
                onClick = { vm.setCollaborationMode(mode) },
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (state.collaborationMode == mode) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(mode.title, fontWeight = FontWeight.Bold)
                    Text(mode.subtitle, style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        Text("Supreme Synthesizer", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
        state.models.filter { it.enabled }.forEach { m ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = (state.supremeSynthesizerId ?: state.models.firstOrNull { it.enabled }?.id) == m.id,
                    onClick = { vm.setSupremeSynthesizer(m.id) }
                )
                Text(m.name + " (" + m.role.label + ")")
            }
        }
    }
}

@Composable
fun CompatibilityScreen(vm: PocketAiViewModel, state: PocketAiUiState) {
    val report = state.compatibilityReport
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Compatibility & Thermal", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            Button(onClick = { vm.refreshCompatibility() }) { Text("Refresh") }
        }
        if (report != null) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Assessment: " + report.concernLevel.label, fontWeight = FontWeight.Bold)
                    Text("RAM: " + report.availableRamMb + " MB available / " + report.totalRamMb + " MB total")
                    Text("Free Storage: " + report.freeStorageMb + " MB")
                    Text("ABI: " + report.abi + " • Android SDK: " + report.androidSdk)
                    Text("Thermal Status: " + report.thermalStatusLabel)
                    Text("Execution Transparency: " + report.executionModeLabel)
                }
            }
            Text("Reasons & Uncertainty", fontWeight = FontWeight.Bold)
            report.reasons.forEach { Text("• " + it, style = MaterialTheme.typography.bodySmall) }
            Text("Recommendations", fontWeight = FontWeight.Bold)
            report.recommendations.forEach { Text("• " + it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@Composable
fun HistoryScreen(vm: PocketAiViewModel, state: PocketAiUiState, onOpenChat: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Conversation History", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            TextButton(onClick = { vm.clearHistory() }) { Text("Clear All") }
        }
        if (state.threads.isEmpty()) {
            Text("No saved conversations yet.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(state.threads, key = { it.id }) { thread ->
                    Card(
                        onClick = {
                            vm.selectThread(thread.id)
                            onOpenChat()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(thread.title, fontWeight = FontWeight.Bold)
                            Text("" + thread.messages.size + " messages • " + thread.mode.title + " • " + thread.routingMode.label, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: PocketAiViewModel, state: PocketAiUiState) {
    val s = state.settings
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Theme", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ThemePreference.entries.forEach { pref ->
                FilterChip(
                    selected = s.theme == pref,
                    onClick = { vm.updateSettings { prev -> prev.copy(theme = pref) } },
                    label = { Text(pref.label) }
                )
            }
        }

        Text("Online Model Endpoint & Key", fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = s.onlineEndpointUrl,
            onValueChange = { v -> vm.updateSettings { prev -> prev.copy(onlineEndpointUrl = v) } },
            label = { Text("Chat Completions URL") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = s.onlineApiKey,
            onValueChange = { v -> vm.updateSettings { prev -> prev.copy(onlineApiKey = v) } },
            label = { Text("API Key (stored locally on device)") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Text("Search Provider Endpoint (Optional)", fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = s.searchEndpointUrl,
            onValueChange = { v -> vm.updateSettings { prev -> prev.copy(searchEndpointUrl = v) } },
            label = { Text("Search JSON Endpoint (?q=... -> {results:[...]})") },
            modifier = Modifier.fillMaxWidth()
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
                checked = s.allowParallelOnlineCalls,
                onCheckedChange = { v -> vm.updateSettings { prev -> prev.copy(allowParallelOnlineCalls = v) } }
            )
            Text("Allow parallel calls in Supreme when all selected models are online", style = MaterialTheme.typography.bodySmall)
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
                checked = s.includeDiagnosticsInFeedback,
                onCheckedChange = { v -> vm.updateSettings { prev -> prev.copy(includeDiagnosticsInFeedback = v) } }
            )
            Text("Include minimal device diagnostics in feedback report (explicit opt-in)", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun FeedbackScreen(vm: PocketAiViewModel, state: PocketAiUiState) {
    val context = LocalContext.current
    var category by remember { mutableStateOf(FeedbackCategory.BUG) }
    var desc by remember { mutableStateOf("") }
    var generatedReport by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Feedback & Privacy", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        Text("No automatic background uploads or webhooks. Review and copy your report manually.", style = MaterialTheme.typography.bodySmall)

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FeedbackCategory.entries.take(4).forEach { cat ->
                FilterChip(selected = category == cat, onClick = { category = cat }, label = { Text(cat.label) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FeedbackCategory.entries.drop(4).forEach { cat ->
                FilterChip(selected = category == cat, onClick = { category = cat }, label = { Text(cat.label) })
            }
        }

        OutlinedTextField(
            value = desc,
            onValueChange = { desc = it },
            label = { Text("Describe issue or suggestion") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { generatedReport = vm.buildFeedbackReport(category, desc) }) {
                Text("Generate Report")
            }
            if (generatedReport.isNotBlank()) {
                OutlinedButton(onClick = {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("PocketAI Feedback", generatedReport))
                }) {
                    Text("Copy Report")
                }
            }
        }

        if (generatedReport.isNotBlank()) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = generatedReport,
                    fontFamily = FontFamily.Monospace,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }
    }
}
