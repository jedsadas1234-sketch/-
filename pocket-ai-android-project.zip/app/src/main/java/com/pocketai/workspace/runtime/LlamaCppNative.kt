package com.pocketai.workspace.runtime

class LlamaCppNative {
    private var libraryLoaded = false

    init {
        try {
            System.loadLibrary("pocketai_gguf")
            libraryLoaded = true
        } catch (_: UnsatisfiedLinkError) {
            libraryLoaded = false
        }
    }

    fun isNativeLibraryLoaded(): Boolean = libraryLoaded

    fun isLlamaCppLinked(): Boolean {
        if (!libraryLoaded) return false
        return try {
            nativeIsLlamaCppLinked()
        } catch (_: Throwable) {
            false
        }
    }

    fun inspectGguf(pathOrUri: String): String {
        if (!libraryLoaded) {
            return "Native JNI library not loaded in current environment."
        }
        return try {
            nativeInspectGgufHeader(pathOrUri)
        } catch (e: Throwable) {
            "JNI inspection error: " + (e.message ?: "unknown")
        }
    }

    private external fun nativeIsLlamaCppLinked(): Boolean
    private external fun nativeInspectGgufHeader(filePath: String): String
}
