package com.pocketai.workspace.network

import com.pocketai.workspace.model.AiModelConfig
import com.pocketai.workspace.model.SearchCitation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

data class SearchOutcome(
    val citations: List<SearchCitation>,
    val error: String? = null
)

class OnlineClients(private val json: Json = Json { ignoreUnknownKeys = true }) {

    suspend fun chatCompletion(
        endpointUrl: String,
        apiKey: String,
        model: AiModelConfig,
        systemPrompt: String,
        userPrompt: String,
        maxTokens: Int = 1024
    ): Result<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("No API key configured for " + model.name + ". Add a key in Settings first.")
            )
        }
        var conn: HttpURLConnection? = null
        try {
            val url = URL(endpointUrl)
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 20_000
                readTimeout = 45_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Authorization", "Bearer " + apiKey)
            }

            val escapedSys = systemPrompt.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n")
            val escapedUser = userPrompt.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n")
            val payload = "{\"model\":\"" + model.modelIdentifier + "\",\"max_tokens\":" + maxTokens + ",\"messages\":[{\"role\":\"system\",\"content\":\"" + escapedSys + "\"},{\"role\":\"user\",\"content\":\"" + escapedUser + "\"}]}"

            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                writer.write(payload)
                writer.flush()
            }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }

            if (code !in 200..299) {
                return@withContext Result.failure(
                    RuntimeException("HTTP " + code + " from " + model.providerName + ": " + body.take(300))
                )
            }

            val root = json.parseToJsonElement(body).jsonObject
            val content = root["choices"]?.jsonArray
                ?.firstOrNull()?.jsonObject
                ?.get("message")?.jsonObject
                ?.get("content")?.jsonPrimitive?.content

            if (content.isNullOrBlank()) {
                Result.failure(RuntimeException("Empty response content returned by " + model.name + "."))
            } else {
                Result.success(content)
            }
        } catch (t: Throwable) {
            Result.failure(RuntimeException("Network error calling " + model.name + ": " + (t.message ?: "unknown")))
        } finally {
            conn?.disconnect()
        }
    }

    suspend fun searchWeb(
        searchEndpointUrl: String,
        apiKey: String,
        query: String
    ): SearchOutcome = withContext(Dispatchers.IO) {
        if (searchEndpointUrl.isBlank()) {
            return@withContext SearchOutcome(
                citations = emptyList(),
                error = "Search endpoint is not configured in Settings. No fabricated results returned."
            )
        }
        var conn: HttpURLConnection? = null
        try {
            val sep = if (searchEndpointUrl.contains("?")) "&" else "?"
            val encodedQ = java.net.URLEncoder.encode(query, "UTF-8")
            val url = URL(searchEndpointUrl + sep + "q=" + encodedQ)
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 15_000
                readTimeout = 20_000
                if (apiKey.isNotBlank()) {
                    setRequestProperty("Authorization", "Bearer " + apiKey)
                }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
            if (code !in 200..299) {
                return@withContext SearchOutcome(
                    citations = emptyList(),
                    error = "Search provider returned HTTP " + code + "."
                )
            }
            val obj = json.parseToJsonElement(body).jsonObject
            val resultsArray = obj["results"]?.jsonArray ?: return@withContext SearchOutcome(
                citations = emptyList(),
                error = "Search response had no 'results' array."
            )
            val citations = resultsArray.mapNotNull { el ->
                val item = el.jsonObject
                val title = item["title"]?.jsonPrimitive?.content ?: return@mapNotNull null
                val href = item["url"]?.jsonPrimitive?.content ?: return@mapNotNull null
                val snippet = item["snippet"]?.jsonPrimitive?.content ?: ""
                SearchCitation(title = title, url = href, snippet = snippet)
            }
            SearchOutcome(citations = citations, error = null)
        } catch (t: Throwable) {
            SearchOutcome(
                citations = emptyList(),
                error = "Search failed: " + (t.message ?: "unknown error")
            )
        } finally {
            conn?.disconnect()
        }
    }
}
