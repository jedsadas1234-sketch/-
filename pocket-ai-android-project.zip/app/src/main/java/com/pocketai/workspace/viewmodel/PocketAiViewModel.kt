package com.pocketai.workspace.viewmodel

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pocketai.workspace.data.WorkspaceRepository
import com.pocketai.workspace.model.AiModelConfig
import com.pocketai.workspace.model.AppSettingsState
import com.pocketai.workspace.model.ChatMessage
import com.pocketai.workspace.model.ChatThread
import com.pocketai.workspace.model.ChatRoutingMode
import com.pocketai.workspace.model.CollaborationMode
import com.pocketai.workspace.model.CompatibilityReport
import com.pocketai.workspace.model.FeedbackCategory
import com.pocketai.workspace.model.ModelRole
import com.pocketai.workspace.model.ModelSourceType
import com.pocketai.workspace.model.SearchCitation
import com.pocketai.workspace.model.TeamMeetingRecord
import com.pocketai.workspace.network.OnlineClients
import com.pocketai.workspace.orchestrator.CollaborationEngine
import com.pocketai.workspace.platform.DeviceCompatibilityMonitor
import com.pocketai.workspace.runtime.LlamaCppNative
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

enum class AppScreen(val route: String, val title: String) {
    CHAT("chat", "Chat"),
    MODELS("models", "Models"),
    MEETING("meeting", "Meeting"),
    COLLABORATION("collaboration", "Modes"),
    COMPATIBILITY("compatibility", "Device"),
    HISTORY("history", "History"),
    SETTINGS("settings", "Settings"),
    FEEDBACK("feedback", "Feedback")
}

data class PocketAiUiState(
    val models: List<AiModelConfig> = emptyList(),
    val threads: List<ChatThread> = emptyList(),
    val activeThreadId: String? = null,
    val settings: AppSettingsState = AppSettingsState(),
    val meeting: TeamMeetingRecord? = null,
    val collaborationMode: CollaborationMode = CollaborationMode.SEQUENTIAL,
    val routingMode: ChatRoutingMode = ChatRoutingMode.AUTO,
    val supremeSynthesizerId: String? = null,
    val isGenerating: Boolean = false,
    val statusBanner: String? = null,
    val isMeetingRunning: Boolean = false,
    val meetingProgress: String? = null,
    val compatibilityReport: CompatibilityReport? = null,
    val nativeLlamaLinked: Boolean = false
)

class PocketAiViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = WorkspaceRepository(app)
    private val onlineClients = OnlineClients()
    private val nativeBridge = LlamaCppNative()
    private val compatMonitor = DeviceCompatibilityMonitor(app)

    private val _collaborationMode = MutableStateFlow(CollaborationMode.SEQUENTIAL)
    private val _routingMode = MutableStateFlow(ChatRoutingMode.AUTO)
    private val _supremeSynthesizerId = MutableStateFlow<String?>(null)
    private val _activeThreadId = MutableStateFlow<String?>(null)
    private val _isGenerating = MutableStateFlow(false)
    private val _statusBanner = MutableStateFlow<String?>(null)
    private val _isMeetingRunning = MutableStateFlow(false)
    private val _meetingProgress = MutableStateFlow<String?>(null)

    private var generationJob: Job? = null
    private var lastPromptForRetry: String? = null

    val uiState: StateFlow<PocketAiUiState> = combine(
        repo.modelsFlow,
        repo.threadsFlow,
        repo.settingsFlow,
        repo.meetingFlow,
        _collaborationMode,
        _routingMode,
        _supremeSynthesizerId,
        _activeThreadId,
        _isGenerating,
        _statusBanner,
        _isMeetingRunning,
        _meetingProgress
    ) { values ->
        val models = values[0] as List<AiModelConfig>
        val threads = values[1] as List<ChatThread>
        val settings = values[2] as AppSettingsState
        val meeting = values[3] as TeamMeetingRecord?
        val mode = values[4] as CollaborationMode
        val routing = values[5] as ChatRoutingMode
        val synthId = values[6] as String?
        val threadId = values[7] as String?
        val generating = values[8] as Boolean
        val banner = values[9] as String?
        val meetingRunning = values[10] as Boolean
        val meetingProg = values[11] as String?

        val enabled = models.filter { it.enabled }
        val report = compatMonitor.assess(
            selectedModels = enabled,
            mode = mode,
            allowParallelOnline = settings.allowParallelOnlineCalls
        )

        PocketAiUiState(
            models = models,
            threads = threads,
            activeThreadId = threadId ?: threads.firstOrNull()?.id,
            settings = settings,
            meeting = meeting,
            collaborationMode = mode,
            routingMode = routing,
            supremeSynthesizerId = synthId,
            isGenerating = generating,
            statusBanner = banner,
            isMeetingRunning = meetingRunning,
            meetingProgress = meetingProg,
            compatibilityReport = report,
            nativeLlamaLinked = nativeBridge.isLlamaCppLinked()
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), PocketAiUiState())

    fun selectThread(threadId: String) {
        _activeThreadId.value = threadId
    }

    fun startNewThread() {
        _activeThreadId.value = null
        _statusBanner.value = null
    }

    fun setCollaborationMode(mode: CollaborationMode) {
        _collaborationMode.value = mode
    }

    fun setRoutingMode(mode: ChatRoutingMode) {
        _routingMode.value = mode
    }

    fun setSupremeSynthesizer(modelId: String?) {
        _supremeSynthesizerId.value = modelId
    }

    fun refreshCompatibility() {
        _statusBanner.value = "Refreshed device & thermal compatibility assessment."
    }

    fun addOnlineModel(name: String, provider: String, modelId: String, role: ModelRole) {
        viewModelScope.launch {
            val cleanName = name.trim().ifEmpty { modelId.trim() }
            if (cleanName.isBlank() || modelId.isBlank()) {
                _statusBanner.value = "Model name and model ID are required."
                return@launch
            }
            val current = uiState.value.models
            val newModel = AiModelConfig(
                id = "m_" + UUID.randomUUID().toString().take(8),
                name = cleanName,
                sourceType = ModelSourceType.ONLINE_OPENAI_COMPATIBLE,
                providerName = provider.trim().ifEmpty { "OpenAI-Compatible" },
                modelIdentifier = modelId.trim(),
                role = role,
                enabled = true,
                isLoaded = false
            )
            repo.saveModels(current + newModel)
            _statusBanner.value = "Added online model '" + cleanName + "'."
        }
    }

    fun importGgufFromSaf(uri: Uri) {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
            }

            var displayName = uri.lastPathSegment ?: "model.gguf"
            var fileSize: Long? = null
            ctx.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIdx >= 0 && !cursor.isNull(nameIdx)) {
                        displayName = cursor.getString(nameIdx)
                    }
                    if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) {
                        fileSize = cursor.getLong(sizeIdx)
                    }
                }
            }

            val current = uiState.value.models
            val model = AiModelConfig(
                id = "gguf_" + UUID.randomUUID().toString().take(8),
                name = displayName.removeSuffix(".gguf"),
                sourceType = ModelSourceType.LOCAL_GGUF,
                providerName = "Local GGUF (SAF)",
                modelIdentifier = uri.toString(),
                role = if (current.none { it.enabled }) ModelRole.MAIN else ModelRole.ANALYST,
                enabled = true,
                fileSizeBytes = fileSize,
                quantization = inferQuantization(displayName),
                contextLength = uiState.value.settings.defaultContextLength,
                isLoaded = false,
                fileAccessible = true
            )
            repo.saveModels(current + model)
            _statusBanner.value = "Imported GGUF reference '" + displayName + "'. Native llama.cpp linkage: " + nativeBridge.isLlamaCppLinked() + "."
        }
    }

    private fun inferQuantization(filename: String): String? {
        val upper = filename.uppercase()
        val known = listOf("Q2_K", "Q3_K_M", "Q4_K_M", "Q4_0", "Q5_K_M", "Q6_K", "Q8_0", "F16")
        return known.firstOrNull { upper.contains(it) }
    }

    fun toggleModelEnabled(modelId: String, enabled: Boolean) {
        viewModelScope.launch {
            val updated = uiState.value.models.map {
                if (it.id == modelId) it.copy(enabled = enabled, isLoaded = if (!enabled) false else it.isLoaded)
                else it
            }
            repo.saveModels(updated)
        }
    }

    fun setModelRole(modelId: String, role: ModelRole) {
        viewModelScope.launch {
            val updated = uiState.value.models.map {
                if (it.id == modelId) it.copy(role = role) else it
            }
            repo.saveModels(updated)
        }
    }

    fun moveModel(modelId: String, direction: Int) {
        viewModelScope.launch {
            val list = uiState.value.models.toMutableList()
            val idx = list.indexOfFirst { it.id == modelId }
            val targetIdx = idx + direction
            if (idx >= 0 && targetIdx in list.indices) {
                val item = list.removeAt(idx)
                list.add(targetIdx, item)
                repo.saveModels(list)
            }
        }
    }

    fun promoteToMain(modelId: String) {
        viewModelScope.launch {
            val list = uiState.value.models.toMutableList()
            val idx = list.indexOfFirst { it.id == modelId }
            if (idx > 0) {
                val item = list.removeAt(idx).copy(role = ModelRole.MAIN, enabled = true)
                list.add(0, item)
                repo.saveModels(list)
                _statusBanner.value = "'" + item.name + "' promoted to Main Model slot."
            }
        }
    }

    fun removeModel(modelId: String) {
        viewModelScope.launch {
            val updated = uiState.value.models.filterNot { it.id == modelId }
            repo.saveModels(updated)
        }
    }

    fun unloadAllLocalModels() {
        viewModelScope.launch {
            val updated = uiState.value.models.map {
                if (it.sourceType == ModelSourceType.LOCAL_GGUF) it.copy(isLoaded = false) else it
            }
            repo.saveModels(updated)
            _statusBanner.value = "Unloaded all local GGUF model states."
        }
    }

    fun updateSettings(transform: (AppSettingsState) -> AppSettingsState) {
        viewModelScope.launch {
            val next = transform(uiState.value.settings)
            repo.saveSettings(next)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repo.saveThreads(emptyList())
            _activeThreadId.value = null
            _statusBanner.value = "Cleared conversation history."
        }
    }

    fun cancelGeneration() {
        generationJob?.cancel()
        generationJob = null
        _isGenerating.value = false
        _statusBanner.value = "Generation cancelled."
    }

    fun retryLastPrompt() {
        val prompt = lastPromptForRetry ?: return
        sendMessage(prompt)
    }

    fun sendMessage(rawPrompt: String) {
        val prompt = rawPrompt.trim()
        if (prompt.isEmpty() || _isGenerating.value) return
        lastPromptForRetry = prompt

        val state = uiState.value
        val compat = state.compatibilityReport
        if (compat?.thermalBlocksNewWork == true) {
            _statusBanner.value = "Thermal protection (" + compat.thermalStatusLabel + "): paused starting new inference to protect device."
            return
        }

        val routing = state.routingMode
        val candidateModels = when (routing) {
            ChatRoutingMode.OFFLINE -> state.models.filter { it.enabled && it.sourceType == ModelSourceType.LOCAL_GGUF }
            ChatRoutingMode.SEARCH, ChatRoutingMode.AUTO -> state.models.filter { it.enabled }
        }

        if (candidateModels.isEmpty()) {
            _statusBanner.value = if (routing == ChatRoutingMode.OFFLINE) {
                "Offline mode active, but no local GGUF model is enabled."
            } else {
                "No enabled models selected. Enable one in Model Manager."
            }
            return
        }

        val now = System.currentTimeMillis()
        val userMsg = ChatMessage(
            id = "msg_" + UUID.randomUUID().toString().take(8),
            sender = "You",
            content = prompt,
            timestampMs = now,
            isUser = true
        )

        val currentThreadId = state.activeThreadId ?: ("thread_" + UUID.randomUUID().toString().take(8))
        val existingThread = state.threads.find { it.id == currentThreadId }
        val workingThread = (existingThread ?: ChatThread(
            id = currentThreadId,
            title = prompt.take(40),
            createdAtMs = now,
            updatedAtMs = now,
            mode = state.collaborationMode,
            routingMode = routing,
            messages = emptyList()
        )).copy(
            updatedAtMs = now,
            mode = state.collaborationMode,
            routingMode = routing,
            messages = (existingThread?.messages ?: emptyList()) + userMsg
        )

        _activeThreadId.value = currentThreadId
        _isGenerating.value = true
        _statusBanner.value = "Starting..."

        generationJob = viewModelScope.launch {
            val updatedThreadsWithUser = upsertThread(uiState.value.threads, workingThread)
            repo.saveThreads(updatedThreadsWithUser)

            var citations: List<SearchCitation> = emptyList()
            var searchWarning: String? = null
            if (routing == ChatRoutingMode.SEARCH || (routing == ChatRoutingMode.AUTO && state.settings.searchEndpointUrl.isNotBlank())) {
                _statusBanner.value = "Searching web..."
                val outcome = onlineClients.searchWeb(
                    searchEndpointUrl = state.settings.searchEndpointUrl,
                    apiKey = state.settings.searchApiKey,
                    query = prompt
                )
                citations = outcome.citations
                searchWarning = outcome.error
            }

            val engine = CollaborationEngine(
                onlineClients = onlineClients,
                nativeBridge = nativeBridge,
                endpointUrl = state.settings.onlineEndpointUrl,
                apiKey = state.settings.onlineApiKey
            )

            val result = engine.runTask(
                prompt = prompt,
                enabledModels = candidateModels,
                mode = state.collaborationMode,
                maxRounds = state.settings.maxCollaborationRounds,
                allowParallelOnline = state.settings.allowParallelOnlineCalls,
                synthesizerId = state.supremeSynthesizerId,
                citations = citations,
                onProgress = { prog -> _statusBanner.value = prog }
            )

            val combinedText = if (searchWarning != null && citations.isEmpty()) {
                result.finalText + "\n\n[Search notice: " + searchWarning + "]"
            } else {
                result.finalText
            }

            val assistantMsg = ChatMessage(
                id = "msg_" + UUID.randomUUID().toString().take(8),
                sender = candidateModels.first().name,
                content = combinedText,
                timestampMs = System.currentTimeMillis(),
                isUser = false,
                isError = result.isError,
                executionNote = result.executionNote,
                citations = result.citations
            )

            val latestThreads = uiState.value.threads
            val target = latestThreads.find { it.id == currentThreadId } ?: workingThread
            val finalThread = target.copy(
                updatedAtMs = System.currentTimeMillis(),
                messages = target.messages + assistantMsg
            )
            repo.saveThreads(upsertThread(latestThreads, finalThread))
            _isGenerating.value = false
            _statusBanner.value = result.executionNote
        }
    }

    fun startTeamMeeting(forceRefresh: Boolean = false) {
        val state = uiState.value
        val enabled = state.models.filter { it.enabled }
        if (enabled.isEmpty()) {
            _statusBanner.value = "Enable at least one model before starting a team meeting."
            return
        }
        val sig = enabled.joinToString("|") { it.id + ":" + it.role.name + ":" + it.enabled }
        val existing = state.meeting
        if (!forceRefresh && existing != null && existing.rosterSignature == sig) {
            _statusBanner.value = "Reusing saved meeting record for current team roster."
            return
        }

        _isMeetingRunning.value = true
        viewModelScope.launch {
            val engine = CollaborationEngine(
                onlineClients = onlineClients,
                nativeBridge = nativeBridge,
                endpointUrl = state.settings.onlineEndpointUrl,
                apiKey = state.settings.onlineApiKey
            )
            val record = engine.runTeamMeeting(
                enabledModels = enabled,
                maxRounds = state.settings.maxCollaborationRounds,
                onProgress = { p -> _meetingProgress.value = p }
            )
            repo.saveMeeting(record)
            _isMeetingRunning.value = false
            _meetingProgress.value = null
            _statusBanner.value = "Team meeting completed and saved."
        }
    }

    fun buildFeedbackReport(category: FeedbackCategory, description: String): String {
        val state = uiState.value
        val compat = state.compatibilityReport
        val sb = StringBuilder()
        sb.appendLine("Pocket AI Feedback Report")
        sb.appendLine("Category: " + category.label)
        sb.appendLine("Timestamp: " + System.currentTimeMillis())
        sb.appendLine("Description: " + description.trim().ifEmpty { "(none provided)" })

        if (state.settings.includeDiagnosticsInFeedback && compat != null) {
            sb.appendLine("--- Optional Diagnostics (User Opt-In) ---")
            sb.appendLine("App Version: 0.1.0-alpha")
            sb.appendLine("Android SDK: " + compat.androidSdk)
            sb.appendLine("ABI: " + compat.abi)
            sb.appendLine("RAM (Avail/Total MB): " + compat.availableRamMb + "/" + compat.totalRamMb)
            sb.appendLine("Thermal Status: " + compat.thermalStatusLabel)
            sb.appendLine("Collaboration Mode: " + state.collaborationMode.title)
            sb.appendLine("Enabled Models: " + state.models.filter { it.enabled }.joinToString { it.id + "(" + (it.quantization ?: "online") + ")" })
        } else {
            sb.appendLine("Diagnostics: Omitted (opt-in disabled)")
        }
        return sb.toString().trim()
    }

    private fun upsertThread(list: List<ChatThread>, thread: ChatThread): List<ChatThread> {
        val mutable = list.toMutableList()
        val idx = mutable.indexOfFirst { it.id == thread.id }
        if (idx >= 0) mutable[idx] = thread else mutable.add(0, thread)
        return mutable.sortedByDescending { it.updatedAtMs }
    }
}
