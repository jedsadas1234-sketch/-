package com.pocketai.workspace

import com.pocketai.workspace.model.CollaborationMode
import com.pocketai.workspace.model.ModelRole
import org.junit.Assert.assertEquals
import org.junit.Test

class CollaborationModeTest {
    @Test
    fun rolesAndModesAreDistinct() {
        assertEquals(3, CollaborationMode.entries.size)
        assertEquals("Main", ModelRole.MAIN.label)
        assertEquals("Synthesizer", ModelRole.SYNTHESIZER.label)
    }
}
