package com.pocketai.app.llm

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class EstimatesTest {

    @Test
    fun asciiCountsAboutThreeCharsPerToken() {
        assertEquals(4, estimateTokens("hello world")) // 11 chars
        assertEquals(0, estimateTokens(""))
    }

    @Test
    fun nonAsciiCountsOneTokenPerChar() {
        assertEquals(6, estimateTokens("สวัสดี"))
    }

    @Test
    fun kvBytesForGqaModel() {
        // 32 layers, embd 4096, 32 heads, 8 KV heads -> embdKv 1024; 2 * 32 * 1024 * 2048 * 2 bytes
        val meta = GgufMeta(blockCount = 32, embeddingLength = 4096, headCount = 32, headCountKv = 8)
        assertEquals(268_435_456L, estimateKvBytes(meta, 2048))
    }

    @Test
    fun kvBytesUnknownWithoutHeaderFields() {
        assertNull(estimateKvBytes(GgufMeta(null, 4096, 32, 8), 2048))
    }

    @Test
    fun readsArchitectureKeysAndSkipsOthers() {
        val out = ByteArrayOutputStream()
        fun le(size: Int, f: ByteBuffer.() -> Unit) {
            val b = ByteBuffer.allocate(size).order(ByteOrder.LITTLE_ENDIAN)
            b.f()
            out.write(b.array())
        }
        fun str(s: String) {
            val bytes = s.toByteArray(Charsets.UTF_8)
            le(8) { putLong(bytes.size.toLong()) }
            out.write(bytes)
        }
        out.write("GGUF".toByteArray(Charsets.ISO_8859_1))
        le(4) { putInt(3) }          // version
        le(8) { putLong(0) }         // tensor count
        le(8) { putLong(5) }         // kv count

        str("general.name"); le(4) { putInt(8) }; str("test")             // string, skipped
        str("llama.block_count"); le(4) { putInt(4) }; le(4) { putInt(32) }
        str("llama.embedding_length"); le(4) { putInt(4) }; le(4) { putInt(4096) }
        str("llama.attention.head_count"); le(4) { putInt(4) }; le(4) { putInt(32) }
        str("llama.attention.head_count_kv"); le(4) { putInt(4) }; le(4) { putInt(8) }

        val meta = GgufReader.read(ByteArrayInputStream(out.toByteArray()))
        assertEquals(GgufMeta(32, 4096, 32, 8), meta)
    }

    @Test
    fun rejectsNonGguf() {
        assertNull(GgufReader.read(ByteArrayInputStream("NOPE0000000000000000".toByteArray())))
    }
}
