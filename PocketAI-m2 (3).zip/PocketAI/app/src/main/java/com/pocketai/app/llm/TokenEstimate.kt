package com.pocketai.app.llm

/** Tokens reserved for chat-template markers around the whole prompt. */
const val TEMPLATE_RESERVE_TOKENS = 32

/** Tokens added per message for role markers. */
const val PER_MESSAGE_TOKENS = 8

/**
 * Cheap token estimate used only to trim old history before the native side checks exactly.
 * ASCII: about 3 characters per token. Any other character (Thai, CJK, emoji...) counts as one
 * token, which over-estimates on purpose: tokenizers split those scripts far more densely.
 */
fun estimateTokens(text: String): Int {
    var ascii = 0
    var other = 0
    for (c in text) {
        if (c.code < 128) ascii++ else other++
    }
    return (ascii + 2) / 3 + other
}
