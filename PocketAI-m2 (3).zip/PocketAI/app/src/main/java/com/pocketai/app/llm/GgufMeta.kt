package com.pocketai.app.llm

import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.EOFException
import java.io.File
import java.io.FileInputStream
import java.io.InputStream

/** Allowance for llama.cpp compute buffers and runtime overhead. A fixed guess, not measured. */
const val COMPUTE_OVERHEAD_BYTES = 256L * 1024 * 1024

/** Architecture numbers read from a GGUF header. Any field can be null if the file does not have it. */
data class GgufMeta(
    val blockCount: Long?,
    val embeddingLength: Long?,
    val headCount: Long?,
    val headCountKv: Long?,
)

/** [kvBytes] is null when the header did not give enough information. */
data class MemoryEstimate(val weightsBytes: Long, val kvBytes: Long?, val overheadBytes: Long) {
    val totalBytes: Long get() = weightsBytes + (kvBytes ?: 0L) + overheadBytes
}

/**
 * KV cache size with llama.cpp's default f16 cache: K and V, per layer, per KV head, per token.
 * Head size is taken as embedding / heads, so models with a custom head size are approximate.
 */
fun estimateKvBytes(meta: GgufMeta, nCtx: Int): Long? {
    val layers = meta.blockCount ?: return null
    val embd = meta.embeddingLength ?: return null
    val heads = meta.headCount ?: return null
    if (heads <= 0L || layers <= 0L || embd <= 0L) return null
    val kvHeads = meta.headCountKv ?: heads
    val embdKv = embd / heads * kvHeads
    return 2L * layers * embdKv * nCtx.toLong() * 2L
}

/** Minimal GGUF (v2/v3) header reader. Reads key/value metadata only, never tensors. */
object GgufReader {
    private const val MAX_KEY_BYTES = 1L shl 20

    fun read(file: File): GgufMeta? = try {
        FileInputStream(file).use { read(it) }
    } catch (_: Exception) {
        null
    }

    fun read(input: InputStream): GgufMeta? {
        return try {
            val ins = DataInputStream(BufferedInputStream(input, 1 shl 16))
            val magic = ByteArray(4)
            ins.readFully(magic)
            if (String(magic, Charsets.ISO_8859_1) != "GGUF") return null
            val version = ins.u32()
            if (version < 2L) return null
            ins.u64() // tensor count
            val kvCount = ins.u64()

            var blocks: Long? = null
            var embd: Long? = null
            var heads: Long? = null
            var headsKv: Long? = null

            var i = 0L
            while (i < kvCount) {
                i++
                val keyLen = ins.u64()
                if (keyLen < 0 || keyLen > MAX_KEY_BYTES) return null
                val keyBytes = ByteArray(keyLen.toInt())
                ins.readFully(keyBytes)
                val key = String(keyBytes, Charsets.UTF_8)
                val type = ins.u32().toInt()

                val wanted = when {
                    key.endsWith(".attention.head_count_kv") -> 3
                    key.endsWith(".attention.head_count") -> 2
                    key.endsWith(".block_count") -> 0
                    key.endsWith(".embedding_length") -> 1
                    else -> -1
                }
                if (wanted >= 0 && isInteger(type)) {
                    val v = ins.readInteger(type)
                    when (wanted) {
                        0 -> if (blocks == null) blocks = v
                        1 -> if (embd == null) embd = v
                        2 -> if (heads == null) heads = v
                        3 -> if (headsKv == null) headsKv = v
                    }
                    if (blocks != null && embd != null && heads != null && headsKv != null) break
                } else {
                    ins.skipValue(type)
                }
            }
            GgufMeta(blocks, embd, heads, headsKv)
        } catch (_: Exception) {
            null
        }
    }

    private fun isInteger(type: Int) = type in 0..5 || type == 10 || type == 11

    private fun scalarSize(type: Int): Int = when (type) {
        0, 1, 7 -> 1
        2, 3 -> 2
        4, 5, 6 -> 4
        10, 11, 12 -> 8
        else -> throw IllegalStateException("Unknown GGUF value type $type")
    }

    private fun DataInputStream.readInteger(type: Int): Long = when (type) {
        0 -> (readUnsignedByte()).toLong()
        1 -> readByte().toLong()
        2 -> le(2)
        3 -> le(2).toShort().toLong()
        4 -> le(4)
        5 -> le(4).toInt().toLong()
        else -> le(8) // 10 u64, 11 i64
    }

    private fun DataInputStream.skipValue(type: Int) {
        when (type) {
            8 -> skipFully(u64())
            9 -> {
                val elem = u32().toInt()
                val count = u64()
                if (elem == 8) {
                    var n = 0L
                    while (n < count) {
                        skipFully(u64())
                        n++
                    }
                } else {
                    skipFully(count * scalarSize(elem))
                }
            }
            else -> skipFully(scalarSize(type).toLong())
        }
    }

    private fun DataInputStream.le(bytes: Int): Long {
        val b = ByteArray(bytes)
        readFully(b)
        var v = 0L
        for (k in bytes - 1 downTo 0) v = (v shl 8) or (b[k].toLong() and 0xFF)
        return v
    }

    private fun DataInputStream.u32(): Long = le(4)
    private fun DataInputStream.u64(): Long = le(8)

    private fun DataInputStream.skipFully(n: Long) {
        if (n < 0) throw IllegalStateException("negative skip")
        var left = n
        while (left > 0) {
            val s = skip(left)
            if (s <= 0) {
                if (read() < 0) throw EOFException()
                left--
            } else {
                left -= s
            }
        }
    }
}
