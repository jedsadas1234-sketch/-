package com.pocketai.app.llm

import com.pocketai.app.ai.AIProvider
import com.pocketai.app.ai.GenSettings
import com.pocketai.app.ai.ProviderStatus
import com.pocketai.app.data.ChatMessage
import com.pocketai.app.data.Role
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.job
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean

/** Runs the loaded GGUF model on-device. Cancel the collector to stop generation. */
class LocalAIProvider(private val models: ModelManager) : AIProvider {

    override val name: String
        get() = (models.status as? ModelManager.Status.Loaded)?.let { "Local: ${it.file.name}" }
            ?: "Local (no model loaded)"

    private val stopRequested = AtomicBoolean(false)

    override fun getStatus(): ProviderStatus = when (val s = models.status) {
        is ModelManager.Status.Loaded -> ProviderStatus.Ready(s.file.name)
        is ModelManager.Status.Loading -> ProviderStatus.Loading(s.name)
        is ModelManager.Status.Failed -> ProviderStatus.Failed(s.message)
        else -> ProviderStatus.NoModel
    }

    override fun loadModel(modelName: String, contextLength: Int) {
        val file = models.files.firstOrNull { it.name == modelName } ?: return
        stopGeneration()
        models.load(file, contextLength)
    }

    override fun unloadModel() {
        stopGeneration()
        models.unload()
    }

    override fun stopGeneration() {
        stopRequested.set(true)
    }

    override fun generate(
        messages: List<ChatMessage>,
        systemPrompt: String,
        gen: GenSettings,
    ): Flow<String> = channelFlow {
        val handle = models.handle
        val loaded = models.status as? ModelManager.Status.Loaded
        if (handle == 0L || loaded == null) throw IllegalStateException("No model loaded.")
        stopRequested.set(false)

        // Rough history trimming (about 3 chars per token). The native side checks exactly.
        // Non-ASCII characters (Thai, CJK, emoji) count as one token each, see estimateTokens().
        val budgetTokens = (loaded.nCtx - gen.maxTokens - TEMPLATE_RESERVE_TOKENS).coerceAtLeast(256)
        val sys = systemPrompt.trim()
        var used = if (sys.isEmpty()) 0 else estimateTokens(sys) + PER_MESSAGE_TOKENS
        val kept = ArrayDeque<ChatMessage>()
        for (m in messages.filter { it.text.isNotBlank() }.asReversed()) {
            val cost = estimateTokens(m.text) + PER_MESSAGE_TOKENS
            if (kept.isNotEmpty() && used + cost > budgetTokens) break
            kept.addFirst(m)
            used += cost
        }

        val roles = ArrayList<String>()
        val contents = ArrayList<ByteArray>()
        if (sys.isNotEmpty()) {
            roles.add("system")
            contents.add(sys.toByteArray(Charsets.UTF_8))
        }
        for (m in kept) {
            roles.add(if (m.role == Role.USER) "user" else "assistant")
            contents.add(m.text.toByteArray(Charsets.UTF_8))
        }

        withContext(Dispatchers.Default) {
            val job = coroutineContext.job
            NativeLlama.generate(
                handle,
                roles.toTypedArray(),
                contents.toTypedArray(),
                gen.maxTokens,
                gen.temperature,
                gen.topP,
                gen.topK,
                object : NativeLlama.TokenSink {
                    override fun onToken(bytes: ByteArray): Boolean {
                        if (bytes.isNotEmpty()) trySend(String(bytes, Charsets.UTF_8))
                        return job.isActive && !stopRequested.get()
                    }
                },
            )
        }
    }.buffer(Channel.UNLIMITED)
}
