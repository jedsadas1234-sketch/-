# Pocket AI: architecture, risks, feasibility

Status: written without a device or a local compiler. Items marked "verify" are not tested.

## Current structure (single Gradle module `app`)
- `ai/` AIProvider interface: getStatus, loadModel, unloadModel, generate, stopGeneration. MockAIProvider and LocalAIProvider implement it.
- `llm/` ModelManager (import, load, unload, delete, RAM estimate), GgufReader, NativeLlama (JNI), TokenEstimate.
- `data/` conversations (JSON file) and settings (SharedPreferences).
- `ui/` Compose screens, MarkdownText, theme.
- `cpp/` llama_jni.cpp + CMakeLists.txt, llama.cpp v1.0.0 built for arm64-v8a, CPU only.

Not split into the brief's modules (feature-chat, ai-engine, local-llm, ...). Packages mirror them, so a split
later is mechanical. Decision needed before M3: split now or after the avatar milestone.

## Dependencies
| Dependency | Why |
|---|---|
| Compose BOM 2024.09.00, material3, icons-extended | UI, theme, icons |
| activity-compose, lifecycle-viewmodel/runtime-compose | Activity host, ViewModel, state |
| llama.cpp v1.0.0 (NDK/CMake) | Local GGUF inference |
| JUnit 4.13.2 (test only) | Unit tests |

## Risks and feasibility
| Area | Verdict | Notes |
|---|---|---|
| Local GGUF inference | Built, CI compiles | Not every model/quantization runs. CPU only. Large models can be killed by Android (low memory). RAM estimate on the Models screen is approximate. |
| Web search | Feasible, needs a decision | A provider with a secret key needs a backend/proxy; keys must not be in the APK. Candidates are not chosen. Mode switch (Offline/Search/Auto) and source list are plain app code. |
| VRM rendering | Needs prototype | Options: (a) WebView + three.js + three-vrm (supports VRM; heavy inside an overlay), (b) Filament with glTF plus own VRM expression/spring-bone code, (c) Unity as a Library (large APK, hard integration). Brief forbids assuming desktop VRM libraries work. Verify VRM 0.x vs 1.0 support before choosing. |
| Voice input | Feasible | Android SpeechRecognizer; availability and offline support vary by device (verify on target phone). Needs RECORD_AUDIO at runtime. |
| Voice output + lip sync | Feasible, approximate | Android TextToSpeech. No viseme data; use utterance progress/range callbacks or an amplitude-style approximation and label it approximate. |
| Expression/gesture metadata | Feasible | Model returns JSON-like fields; app validates against an allowlist (emotion, gesture, speaking), defaults to neutral/idle. Never execute model output. |
| Floating overlay | Feasible with limits | SYSTEM_ALERT_WINDOW + TYPE_APPLICATION_OVERLAY, user grants in Settings. Needs a foreground service; Android restricts background work and requires foreground service types on recent versions (verify per target SDK). Must have a reliable off switch. |
| Global triple-tap | Not feasible as stated | A normal app cannot observe taps in other apps. AccessibilityService could, but Play policy restricts it to genuine accessibility use. Compliant alternatives: Quick Settings tile, notification action, launcher shortcut, in-app gesture. Recommended: Quick Settings tile + notification action. |
| Privacy | Done for chats | `allowBackup=false`. No INTERNET permission yet; adding search adds it, and only for the search path. |

## Milestone status
- M1 UI prototype: done. M2 local AI: done, plus gaps closed in this revision (markdown, copy, KV cache reuse, top-p/top-k, stop-safe unload).
- M3 search, M4 avatar, M5 voice, M6 overlay, M7 summon shortcut, M8 optimization: not started.

## Known limits
- Token budget for history is an estimate; native code does the exact check and reports "Prompt too long".
- KV cache reuse falls back to a full re-evaluation if the model's memory does not support partial removal.
- No on-device testing yet: speed, memory, thermal behavior unknown.
