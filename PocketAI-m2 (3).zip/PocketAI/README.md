# Pocket AI — Milestone 2 (local model)

Kotlin + Jetpack Compose + llama.cpp (JNI). minSdk 26, targetSdk 34, arm64-v8a only.

## Build APK on GitHub
1. Unzip, push the contents to a GitHub repo (`.github` folder in the repo root).
2. Actions tab, run "Build APK" (also runs on every push). First build is slow
   (compiles llama.cpp; CMake downloads tag v1.0.0 from GitHub).
3. Download artifact `PocketAI-debug-apk`, unzip, install `app-debug.apk`.

## Use
1. Models icon (chip, top right) -> Import GGUF file -> Load.
2. Chat. Stop button works during generation.
3. No model loaded = mock engine with canned replies (labelled as such).

Tips: small instruct models (1B-3B, Q4_K_M) first. Phones with 4 GB RAM: 1B models.
Not every model/quantization runs. Loading too large a model can kill the app.

## What works (untested on a device by the author)
- Everything from Milestone 1 (chats, theme, system prompt)
- SAF import of .gguf (copied to app storage, header checked), load/unload/delete
- Chat template from the model (falls back to ChatML), streaming, stop
- Context length (auto from RAM), max tokens, temperature, top-p, top-k
- KV cache reused for the unchanged start of the conversation; CPU only, no GPU
- Markdown: code blocks with copy button, headings, lists, quotes, tables (monospace), bold, italic, links
- Copy button on replies; Unload / Load / Delete stop a running reply first
- Models screen shows an approximate RAM estimate per model (weights + KV cache from the GGUF header)
- Chats are excluded from Android backup (`allowBackup=false`); nothing leaves the device
- Uses the `AIProvider` interface: getStatus, loadModel, unloadModel, generate, stopGeneration

## Not built yet
Web search, VRM avatar, voice, floating overlay, summon shortcut (Milestones 3-7).

## Build locally
Android Studio: open this folder, let it sync (JDK 17, Gradle 8.9, NDK 26.3.11579264, CMake 3.22.1).
Command line: `gradle assembleDebug` with Gradle 8.9. `gradle-wrapper.jar` is not included (binary);
create it with `gradle wrapper --gradle-version 8.9`. llama.cpp must exist at
`app/src/main/cpp/llama.cpp` (git clone tag v1.0.0), otherwise CMake downloads it.
If you unzip on a machine whose clock is behind the zip time, run
`find . -exec touch -c {} +` first, or Ninja loops with "manifest 'build.ninja' still dirty".

## Tests
`gradle testDebugUnitTest` runs JVM unit tests (token estimate, GGUF header reader, KV estimate).
Not run by the author; not part of the CI workflow.

## Docs
`docs/ARCHITECTURE.md`: architecture, risks, feasibility, dependencies, next milestones.

## Note
Compiled on GitHub Actions up to the use_mmap fix. The Milestone 2+ changes listed above were
written without a compiler or a device; if the build fails, send the error from the failing step.
