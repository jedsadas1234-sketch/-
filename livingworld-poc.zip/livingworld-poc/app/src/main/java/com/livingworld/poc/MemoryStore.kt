package com.livingworld.poc

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** ความจำ NPC ลง SQLite (แยกต่อ NPC ด้วย npc_id) */
class MemoryStore(ctx: Context) : SQLiteOpenHelper(ctx, "livingworld.db", null, 1) {
    data class Turn(val role: String, val content: String)
    data class Relation(val familiarity: Int, val lastMet: Long)

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE turns (id INTEGER PRIMARY KEY AUTOINCREMENT, npc_id TEXT NOT NULL, " +
                "role TEXT NOT NULL, content TEXT NOT NULL, ts INTEGER NOT NULL)"
        )
        db.execSQL("CREATE INDEX idx_turns_npc ON turns (npc_id, id)")
        db.execSQL(
            "CREATE TABLE relation (npc_id TEXT PRIMARY KEY, familiarity INTEGER NOT NULL DEFAULT 0, " +
                "first_met INTEGER NOT NULL, last_met INTEGER NOT NULL)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun addTurn(npcId: String, role: String, content: String) {
        val cv = ContentValues().apply {
            put("npc_id", npcId)
            put("role", role)
            put("content", content)
            put("ts", System.currentTimeMillis())
        }
        writableDatabase.insert("turns", null, cv)
    }

    /** เรียงเก่า -> ใหม่ */
    fun recentTurns(npcId: String, limit: Int): List<Turn> {
        val out = ArrayList<Turn>()
        readableDatabase.rawQuery(
            "SELECT role, content FROM turns WHERE npc_id = ? ORDER BY id DESC LIMIT ?",
            arrayOf(npcId, limit.toString()),
        ).use { c ->
            while (c.moveToNext()) out.add(Turn(c.getString(0), c.getString(1)))
        }
        out.reverse()
        return out
    }

    fun relation(npcId: String): Relation {
        readableDatabase.rawQuery(
            "SELECT familiarity, last_met FROM relation WHERE npc_id = ?", arrayOf(npcId),
        ).use { c ->
            if (c.moveToFirst()) return Relation(c.getInt(0), c.getLong(1))
        }
        return Relation(0, 0L)
    }

    fun bumpFamiliarity(npcId: String) {
        val now = System.currentTimeMillis()
        val db = writableDatabase
        db.execSQL(
            "INSERT OR IGNORE INTO relation (npc_id, familiarity, first_met, last_met) VALUES (?, 0, ?, ?)",
            arrayOf<Any?>(npcId, now, now),
        )
        db.execSQL(
            "UPDATE relation SET familiarity = familiarity + 1, last_met = ? WHERE npc_id = ?",
            arrayOf<Any?>(now, npcId),
        )
    }

    fun clearAll() {
        writableDatabase.execSQL("DELETE FROM turns")
        writableDatabase.execSQL("DELETE FROM relation")
    }
}
