package com.livingworld.poc

import kotlin.math.hypot
import kotlin.random.Random

/** พิกัด normalized 0..1 ความเร็วเป็น px/s */
class Mover(var x: Float, var y: Float) {
    var tx = x
    var ty = y

    /** return true ถ้าถึงเป้าหมายแล้ว */
    fun step(speed: Float, dt: Float, w: Float, h: Float): Boolean {
        val dx = (tx - x) * w
        val dy = (ty - y) * h
        val d = hypot(dx, dy)
        val s = speed * dt
        if (d <= s) {
            x = tx
            y = ty
            return true
        }
        x += dx / d * s / w
        y += dy / d * s / h
        return false
    }
}

class NpcRuntime(val def: NpcDef) {
    val m = Mover(def.homeX, def.homeY)
    var waitS = 0f
}

/** ตรรกะเกมเบาๆ ล้วน ไม่เรียก LLM — NPC เดินสุ่มเอง */
class World {
    val npcs = NPCS.map { NpcRuntime(it) }
    val player = Mover(0.5f, 0.88f)

    @Volatile
    var talkingTo: String? = null
    private var pendingTalk: String? = null

    fun onTap(px: Float, py: Float, w: Float, h: Float) {
        if (talkingTo != null) return
        val nx = px / w
        val ny = py / h
        val hit = npcs.firstOrNull { hypot((it.m.x - nx) * w, (it.m.y - ny) * h) < 48f }
        if (hit != null) {
            pendingTalk = hit.def.id
            player.tx = hit.m.x
            player.ty = hit.m.y
        } else {
            pendingTalk = null
            player.tx = nx.coerceIn(0.02f, 0.98f)
            player.ty = ny.coerceIn(0.02f, 0.98f)
        }
    }

    /** return npc id ถ้าผู้เล่นเดินถึงและควรเปิดหน้าต่างคุย */
    fun update(dt: Float, w: Float, h: Float): String? {
        player.step(PLAYER_SPEED, dt, w, h)
        for (n in npcs) {
            val id = n.def.id
            if (id == talkingTo || id == pendingTalk) continue
            if (n.waitS > 0f) {
                n.waitS -= dt
                continue
            }
            if (n.m.step(NPC_SPEED, dt, w, h)) {
                n.waitS = 2f + Random.nextFloat() * 4f
                val wp = WAYPOINTS.random()
                n.m.tx = wp.x
                n.m.ty = wp.y
            }
        }
        val target = pendingTalk
        if (target != null && talkingTo == null) {
            val n = npcs.first { it.def.id == target }
            player.tx = n.m.x
            player.ty = n.m.y
            val d = hypot((n.m.x - player.x) * w, (n.m.y - player.y) * h)
            if (d < 90f) {
                pendingTalk = null
                player.tx = player.x
                player.ty = player.y
                talkingTo = target
                return target
            }
        }
        return null
    }

    private companion object {
        const val PLAYER_SPEED = 220f
        const val NPC_SPEED = 70f
    }
}
