package com.livingworld.poc

/**
 * ตัดข้อความระหว่าง <think> ... </think> ออกแบบ streaming
 * รองรับกรณีแท็กถูกแบ่งข้าม chunk (เช่น "<thi" + "nk>")
 */
class ThinkFilter {
    private var inThink = false
    private val buf = StringBuilder()

    fun feed(chunk: String): String {
        buf.append(chunk)
        val out = StringBuilder()
        while (true) {
            if (!inThink) {
                val i = buf.indexOf(OPEN)
                if (i >= 0) {
                    out.append(buf, 0, i)
                    buf.delete(0, i + OPEN.length)
                    inThink = true
                    continue
                }
                val keep = partialSuffix(OPEN)
                out.append(buf, 0, buf.length - keep)
                buf.delete(0, buf.length - keep)
                break
            } else {
                val i = buf.indexOf(CLOSE)
                if (i >= 0) {
                    buf.delete(0, i + CLOSE.length)
                    inThink = false
                    continue
                }
                val keep = partialSuffix(CLOSE)
                buf.delete(0, buf.length - keep)
                break
            }
        }
        return out.toString()
    }

    /** เรียกตอนจบ: ถ้ายังอยู่ใน think (ไม่ปิดแท็ก) ทิ้งทั้งหมด */
    fun flush(): String {
        val r = if (inThink) "" else buf.toString()
        buf.clear()
        return r
    }

    private fun partialSuffix(tag: String): Int {
        for (k in minOf(tag.length - 1, buf.length) downTo 1) {
            if (buf.endsWith(tag.substring(0, k))) return k
        }
        return 0
    }

    private companion object {
        const val OPEN = "<think>"
        const val CLOSE = "</think>"
    }
}
