package com.livingworld.poc

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun GameScreen(vm: ChatViewModel) {
    val s by vm.state.collectAsStateWithLifecycle()
    val world = vm.world
    var tick by remember { mutableLongStateOf(0L) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    val measurer = rememberTextMeasurer()
    val labelStyle = remember { TextStyle(color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold) }

    // เกมวนเฉพาะตอนมี frame (แอปอยู่ background = ไม่มี frame = หยุดเอง)
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L && canvasSize.width > 0) {
                    val dt = ((now - last) / 1e9f).coerceAtMost(0.05f)
                    val id = world.update(dt, canvasSize.width.toFloat(), canvasSize.height.toFloat())
                    if (id != null) vm.openDialog(id)
                }
                last = now
                tick = now
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        Canvas(
            Modifier
                .fillMaxSize()
                .onSizeChanged { canvasSize = it }
                .pointerInput(Unit) {
                    detectTapGestures { off ->
                        world.onTap(off.x, off.y, canvasSize.width.toFloat(), canvasSize.height.toFloat())
                    }
                },
        ) {
            if (tick < 0L) return@Canvas
            val w = size.width
            val h = size.height
            drawRect(Color(0xFF3E7C3A))
            drawCircle(Color(0xFFC9B98A), radius = 0.18f * w, center = Offset(0.5f * w, 0.45f * h))
            BUILDINGS.forEach { b ->
                drawRect(b.color, Offset(b.l * w, b.t * h), Size((b.r - b.l) * w, (b.b - b.t) * h))
                val l = measurer.measure(b.label, labelStyle)
                drawText(l, topLeft = Offset(b.l * w + 8f, b.t * h + 8f))
            }
            world.npcs.forEach { n ->
                val c = Offset(n.m.x * w, n.m.y * h)
                drawCircle(Color.Black.copy(alpha = 0.25f), 24f, c + Offset(3f, 5f))
                drawCircle(n.def.color, 22f, c)
                if (world.talkingTo == n.def.id) drawCircle(Color.White, 31f, c, style = Stroke(3f))
                val l = measurer.measure(n.def.name, labelStyle)
                drawText(l, topLeft = Offset(c.x - l.size.width / 2f, c.y - 52f))
            }
            val pc = Offset(world.player.x * w, world.player.y * h)
            drawCircle(Color.Black.copy(alpha = 0.25f), 20f, pc + Offset(3f, 5f))
            drawCircle(Color.White, 18f, pc)
            drawCircle(Color(0xFF1E88E5), 12f, pc)
        }

        Text(
            "แตะ NPC เพื่อเดินไปคุย · แตะพื้นเพื่อเดิน",
            fontSize = 12.sp,
            color = Color.White,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(8.dp)
                .background(Color(0x99000000))
                .padding(horizontal = 8.dp, vertical = 4.dp),
        )

        val npcId = s.dialogNpcId
        if (npcId != null) {
            val npc = NPCS.first { it.id == npcId }
            var input by remember(npcId) { mutableStateOf("") }
            val scroll = rememberScrollState()
            LaunchedEffect(s.dialogLines) { scroll.scrollTo(scroll.maxValue) }

            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .imePadding()
                    .background(Color(0xEE15171C))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(npc.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    TextButton(onClick = vm::closeDialog) { Text("ปิด") }
                }
                Column(Modifier.heightIn(max = 220.dp).verticalScroll(scroll), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (s.dialogLines.isEmpty()) Text("ยังไม่เคยคุยกัน ลองทักดู", fontSize = 12.sp)
                    s.dialogLines.forEach {
                        Text((if (it.fromPlayer) "คุณ: " else "${npc.name}: ") + it.text)
                    }
                }
                val ready = s.phase == ChatViewModel.Phase.Ready
                val busy = s.phase == ChatViewModel.Phase.Generating
                if (!ready && !busy) Text("ยังไม่ได้โหลดโมเดล ไปแท็บ Setup ก่อน", fontSize = 12.sp, color = Color(0xFFFFB74D))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        label = { Text("พูดกับ ${npc.name}") }, modifier = Modifier.weight(1f), maxLines = 3,
                    )
                    if (busy) {
                        Button(onClick = vm::cancel) { Text("Cancel") }
                    } else {
                        Button(
                            onClick = { vm.say(input); input = "" },
                            enabled = ready && input.isNotBlank(),
                        ) { Text("Send") }
                    }
                }
            }
        }
    }
}
