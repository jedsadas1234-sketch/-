package com.livingworld.poc

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color

data class DialogLine(val fromPlayer: Boolean, val text: String)

data class NpcDef(
    val id: String,
    val name: String,
    val personality: String,
    val color: Color,
    val homeX: Float,
    val homeY: Float,
)

/** ตัวอย่างข้อมูล NPC (ยังไม่ใช่ format สุดท้าย) */
val NPCS = listOf(
    NpcDef("alex", "Alex", "Friendly and curious young man who loves chatting and asking questions.", Color(0xFFFF9800), 0.50f, 0.45f),
    NpcDef("mina", "Mina", "Introverted, shy young woman. Speaks softly in short sentences and is slow to trust strangers.", Color(0xFF26A69A), 0.23f, 0.27f),
    NpcDef("boon", "Boon", "Grumpy old shopkeeper with a dry sense of humor, but secretly kind-hearted.", Color(0xFFAB47BC), 0.77f, 0.28f),
)

data class Building(val l: Float, val t: Float, val r: Float, val b: Float, val color: Color, val label: String)

val BUILDINGS = listOf(
    Building(0.08f, 0.08f, 0.38f, 0.22f, Color(0xFF8D6E63), "House"),
    Building(0.62f, 0.08f, 0.92f, 0.24f, Color(0xFF5C6BC0), "Shop"),
    Building(0.08f, 0.62f, 0.34f, 0.76f, Color(0xFFD84315), "Cafe"),
)

/** จุดเดินของ NPC (อยู่นอกอาคาร) */
val WAYPOINTS = listOf(
    Offset(0.50f, 0.45f), Offset(0.50f, 0.30f), Offset(0.30f, 0.42f), Offset(0.70f, 0.42f),
    Offset(0.77f, 0.29f), Offset(0.23f, 0.26f), Offset(0.21f, 0.80f), Offset(0.70f, 0.70f),
    Offset(0.50f, 0.62f),
)

object Prompt {
    /** บริบทเฉพาะ NPC: บุคลิก + ความสัมพันธ์ + บทสนทนาล่าสุด (ไม่ส่งประวัติทั้งหมด) */
    fun system(npc: NpcDef, history: List<MemoryStore.Turn>, rel: MemoryStore.Relation): String {
        val sb = StringBuilder()
        sb.append("You are ${npc.name}, a character living in a small town. ${npc.personality}\n")
        sb.append("Stay in character at all times and never mention being an AI. ")
        sb.append("Reply in Thai, at most 2 short sentences, plain text only.\n")
        if (rel.familiarity == 0) {
            sb.append("You have never talked with the player before.\n")
        } else {
            sb.append("You have talked with the player ${rel.familiarity} time(s) before.\n")
        }
        if (history.isNotEmpty()) {
            sb.append("Recent conversation with the player (oldest first):\n")
            history.forEach {
                sb.append(if (it.role == "player") "Player: " else "${npc.name}: ")
                sb.append(it.content.take(200)).append('\n')
            }
        }
        return sb.toString()
    }
}
