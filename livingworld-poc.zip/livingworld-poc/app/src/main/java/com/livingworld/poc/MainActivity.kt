package com.livingworld.poc

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

private const val DEFAULT_SYSTEM =
    "You are Alex, a friendly and curious young man living in a small town. " +
        "Stay in character. Reply in Thai, at most 2 short sentences."

class MainActivity : ComponentActivity() {
    private val vm: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { Screen(vm) }
            }
        }
    }

    // สเปค: ออกจากแอปแล้วหยุด inference ทันที
    override fun onStop() {
        super.onStop()
        vm.cancel()
    }
}

@Composable
private fun Screen(vm: ChatViewModel) {
    val s by vm.state.collectAsStateWithLifecycle()
    var system by rememberSaveable { mutableStateOf(DEFAULT_SYSTEM) }
    var input by rememberSaveable { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importModel(uri)
    }
    val idleish = s.phase == ChatViewModel.Phase.Idle || s.phase == ChatViewModel.Phase.Error

    Column(
        Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text("LIVING WORLD · PoC", style = MaterialTheme.typography.titleMedium)
        Text("[${s.phase}] ${s.status}", style = MaterialTheme.typography.bodyMedium)
        if (s.phase == ChatViewModel.Phase.Copying) {
            LinearProgressIndicator(progress = { s.copyPct / 100f }, modifier = Modifier.fillMaxWidth())
        }
        if (s.info.isNotEmpty()) Text(s.info, fontSize = 10.sp, lineHeight = 12.sp)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { picker.launch(arrayOf("*/*")) }, enabled = idleish) { Text("เลือก .gguf") }
            Button(onClick = vm::loadModel, enabled = idleish && s.hasModel) { Text("Load") }
            OutlinedButton(onClick = vm::unload, enabled = s.phase == ChatViewModel.Phase.Ready) { Text("Unload") }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("threads", fontSize = 12.sp)
            listOf(3, 4, 5, 6).forEach { n ->
                FilterChip(selected = s.threads == n, onClick = { vm.setThreads(n) }, label = { Text("$n") })
            }
        }

        OutlinedTextField(
            value = system, onValueChange = { system = it },
            label = { Text("NPC persona (system prompt)") },
            minLines = 2, maxLines = 4, modifier = Modifier.fillMaxWidth(),
        )

        Box(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
            Text(s.output, style = MaterialTheme.typography.bodyLarge)
        }
        if (s.stats.isNotEmpty()) Text(s.stats, fontSize = 12.sp)

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                label = { Text("พูดกับ NPC") }, modifier = Modifier.weight(1f), maxLines = 3,
            )
            if (s.phase == ChatViewModel.Phase.Generating) {
                Button(onClick = vm::cancel) { Text("Cancel") }
            } else {
                Button(
                    onClick = { vm.send(system, input) },
                    enabled = s.phase == ChatViewModel.Phase.Ready && input.isNotBlank(),
                ) { Text("Send") }
            }
        }
    }
}
