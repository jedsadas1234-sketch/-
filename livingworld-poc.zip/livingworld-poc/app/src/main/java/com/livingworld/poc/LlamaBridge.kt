package com.livingworld.poc

/** JNI bridge. ทุกฟังก์ชันยกเว้น cancel() ต้องเรียกจาก thread เดียวกัน (single-thread dispatcher) */
object LlamaBridge {
    init { System.loadLibrary("lwllama") }

    fun interface TokenListener { fun onToken(bytes: ByteArray) }

    external fun loadModel(path: String, nCtx: Int, nThreads: Int)
    external fun modelInfo(): String
    external fun systemInfo(): String
    /** return [promptTokens, promptTokPerSec, genTokens, genTokPerSec] */
    external fun generate(system: ByteArray, user: ByteArray, maxTokens: Int, listener: TokenListener): DoubleArray
    external fun cancel()
    external fun unload()
}
