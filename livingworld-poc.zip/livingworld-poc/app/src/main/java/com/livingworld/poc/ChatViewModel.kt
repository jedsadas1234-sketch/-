package com.livingworld.poc

import android.app.Application
import android.net.Uri
import android.os.Debug
import android.os.SystemClock
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.Executors

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    enum class Phase { Idle, Copying, Loading, Ready, Generating, Error }

    data class UiState(
        val phase: Phase = Phase.Idle,
        val hasModel: Boolean = false,
        val status: String = "",
        val info: String = "",
        val output: String = "",
        val stats: String = "",
        val copyPct: Int = 0,
        val threads: Int = 4,
        val dialogNpcId: String? = null,
        val dialogLines: List<DialogLine> = emptyList(),
    )

    private val _state = MutableStateFlow(UiState())
    val state = _state.asStateFlow()

    // inference ทั้งหมดอยู่ thread เดียว ไม่แตะ main thread
    private val llm = Executors.newSingleThreadExecutor { Thread(it, "llm") }.asCoroutineDispatcher()
    private val modelFile = File(app.filesDir, "models/model.gguf")
    private val nCtx = 2048

    val world = World()
    private val store = MemoryStore(app)

    @Volatile
    private var sessionCounted = false

    init {
        val has = modelFile.exists()
        _state.update {
            it.copy(hasModel = has, status = if (has) "มีโมเดลแล้ว กด Load" else "ยังไม่มีโมเดล เลือกไฟล์ .gguf")
        }
    }

    private fun pssMb() = Debug.MemoryInfo().also { Debug.getMemoryInfo(it) }.totalPss / 1024

    fun setThreads(n: Int) {
        if (_state.value.phase in setOf(Phase.Idle, Phase.Error)) _state.update { it.copy(threads = n) }
    }

    fun importModel(uri: Uri) {
        if (_state.value.phase !in setOf(Phase.Idle, Phase.Error)) return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _state.update { it.copy(phase = Phase.Copying, copyPct = 0, status = "กำลังคัดลอกโมเดล...") }
                val cr = getApplication<Application>().contentResolver
                val total = cr.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)
                    ?.use { c -> if (c.moveToFirst()) c.getLong(0) else -1L } ?: -1L
                modelFile.parentFile?.mkdirs()
                val tmp = File(modelFile.parentFile, "model.tmp")
                cr.openInputStream(uri)!!.use { inp ->
                    tmp.outputStream().use { out ->
                        val buf = ByteArray(1 shl 20)
                        var done = 0L
                        var last = -1
                        while (true) {
                            val n = inp.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val pct = (done * 100 / total).toInt()
                                if (pct != last) { last = pct; _state.update { it.copy(copyPct = pct) } }
                            }
                        }
                    }
                }
                val magic = tmp.inputStream().use { s -> ByteArray(4).also { s.read(it) } }.decodeToString()
                if (magic != "GGUF") { tmp.delete(); error("ไฟล์นี้ไม่ใช่ GGUF") }
                tmp.renameTo(modelFile)
                _state.update { it.copy(phase = Phase.Idle, hasModel = true, status = "คัดลอกเสร็จ กด Load") }
            } catch (t: Throwable) {
                _state.update { it.copy(phase = Phase.Error, status = "คัดลอกพัง: ${t.message}") }
            }
        }
    }

    fun loadModel() {
        val st = _state.value
        if (!st.hasModel || st.phase !in setOf(Phase.Idle, Phase.Error)) return
        _state.update { it.copy(phase = Phase.Loading, status = "กำลังโหลดโมเดล...", output = "", stats = "", info = "") }
        viewModelScope.launch(llm) {
            try {
                val t0 = SystemClock.elapsedRealtime()
                LlamaBridge.loadModel(modelFile.absolutePath, nCtx, _state.value.threads)
                val ms = SystemClock.elapsedRealtime() - t0
                _state.update {
                    it.copy(
                        phase = Phase.Ready,
                        status = "พร้อม · โหลด $ms ms · PSS ${pssMb()} MB",
                        info = LlamaBridge.modelInfo() + "\n" + LlamaBridge.systemInfo().trim(),
                    )
                }
            } catch (t: Throwable) {
                _state.update { it.copy(phase = Phase.Error, status = "โหลดพัง: ${t.message}") }
            }
        }
    }

    fun unload() {
        if (_state.value.phase != Phase.Ready) return
        viewModelScope.launch(llm) {
            LlamaBridge.unload()
            _state.update { it.copy(phase = Phase.Idle, status = "ปล่อยโมเดลแล้ว · PSS ${pssMb()} MB", info = "") }
        }
    }

    fun send(system: String, user: String) {
        if (_state.value.phase != Phase.Ready || user.isBlank()) return
        _state.update { it.copy(phase = Phase.Generating, output = "", stats = "") }
        viewModelScope.launch(llm) {
            val sb = StringBuilder()
            val filter = ThinkFilter()
            try {
                val r = LlamaBridge.generate(system.toByteArray(), user.toByteArray(), 256) { bytes ->
                    val c = filter.feed(String(bytes, Charsets.UTF_8))
                    if (c.isNotEmpty()) {
                        sb.append(c)
                        _state.update { it.copy(output = sb.toString().trimStart()) }
                    }
                }
                _state.update {
                    it.copy(
                        phase = Phase.Ready,
                        stats = "prompt ${r[0].toInt()} tok @ ${"%.1f".format(r[1])} t/s · " +
                            "gen ${r[2].toInt()} tok @ ${"%.1f".format(r[3])} t/s · PSS ${pssMb()} MB",
                    )
                }
            } catch (t: Throwable) {
                _state.update { it.copy(phase = Phase.Ready, stats = "gen พัง: ${t.message}") }
            }
        }
    }

    // ---------- เกม: คุยกับ NPC ----------

    fun openDialog(npcId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val lines = store.recentTurns(npcId, 6).map { DialogLine(it.role == "player", it.content) }
            sessionCounted = false
            world.talkingTo = npcId
            _state.update { it.copy(dialogNpcId = npcId, dialogLines = lines) }
        }
    }

    fun closeDialog() {
        LlamaBridge.cancel()
        world.talkingTo = null
        _state.update { it.copy(dialogNpcId = null, dialogLines = emptyList()) }
    }

    private fun setLastNpcLine(npcId: String, text: String) {
        _state.update { st ->
            if (st.dialogNpcId != npcId || st.dialogLines.isEmpty()) st
            else st.copy(dialogLines = st.dialogLines.dropLast(1) + DialogLine(false, text))
        }
    }

    fun say(text: String) {
        val st0 = _state.value
        val id = st0.dialogNpcId ?: return
        val npc = NPCS.firstOrNull { it.id == id } ?: return
        if (st0.phase != Phase.Ready || text.isBlank()) return
        val noThink = st0.info.contains("qwen3", ignoreCase = true)
        _state.update {
            it.copy(
                phase = Phase.Generating,
                dialogLines = it.dialogLines + DialogLine(true, text) + DialogLine(false, "…"),
            )
        }
        viewModelScope.launch(llm) {
            val filter = ThinkFilter()
            val sb = StringBuilder()
            try {
                val hist = store.recentTurns(id, 8)
                val rel = store.relation(id)
                store.addTurn(id, "player", text)
                if (!sessionCounted) {
                    store.bumpFamiliarity(id)
                    sessionCounted = true
                }
                val system = Prompt.system(npc, hist, rel)
                val user = if (noThink) "$text /no_think" else text
                LlamaBridge.generate(system.toByteArray(), user.toByteArray(), 200) { bytes ->
                    val c = filter.feed(String(bytes, Charsets.UTF_8))
                    if (c.isNotEmpty()) {
                        sb.append(c)
                        setLastNpcLine(id, sb.toString().trimStart())
                    }
                }
                sb.append(filter.flush())
                val reply = sb.toString().trim()
                if (reply.isBlank()) {
                    setLastNpcLine(id, "(เงียบ)")
                } else {
                    setLastNpcLine(id, reply)
                    store.addTurn(id, "npc", reply)
                }
                _state.update { it.copy(phase = Phase.Ready) }
            } catch (t: Throwable) {
                setLastNpcLine(id, "(พัง: ${t.message})")
                _state.update { it.copy(phase = Phase.Ready) }
            }
        }
    }

    fun clearMemory() {
        viewModelScope.launch(Dispatchers.IO) {
            store.clearAll()
            _state.update { it.copy(dialogLines = emptyList(), stats = "ล้างความจำ NPC ทั้งหมดแล้ว") }
        }
    }

    fun cancel() = LlamaBridge.cancel()
}
