package com.livingworld.poc

import android.app.Application
import android.net.Uri
import android.os.Debug
import android.os.SystemClock
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.Executors

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    enum class Phase { Idle, Copying, Loading, Ready, Generating, Error }

    data class UiState(
        val phase: Phase = Phase.Idle,
        val hasModel: Boolean = false,
        val status: String = "",
        val info: String = "",
        val output: String = "",
        val stats: String = "",
        val copyPct: Int = 0,
        val threads: Int = 4,
    )

    private val _state = MutableStateFlow(UiState())
    val state = _state.asStateFlow()

    // inference ทั้งหมดอยู่ thread เดียว ไม่แตะ main thread
    private val llm = Executors.newSingleThreadExecutor { Thread(it, "llm") }.asCoroutineDispatcher()
    private val modelFile = File(app.filesDir, "models/model.gguf")
    private val nCtx = 2048

    init {
        val has = modelFile.exists()
        _state.update {
            it.copy(hasModel = has, status = if (has) "มีโมเดลแล้ว กด Load" else "ยังไม่มีโมเดล เลือกไฟล์ .gguf")
        }
    }

    private fun pssMb() = Debug.MemoryInfo().also { Debug.getMemoryInfo(it) }.totalPss / 1024

    fun setThreads(n: Int) {
        if (_state.value.phase in setOf(Phase.Idle, Phase.Error)) _state.update { it.copy(threads = n) }
    }

    fun importModel(uri: Uri) {
        if (_state.value.phase !in setOf(Phase.Idle, Phase.Error)) return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _state.update { it.copy(phase = Phase.Copying, copyPct = 0, status = "กำลังคัดลอกโมเดล...") }
                val cr = getApplication<Application>().contentResolver
                val total = cr.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)
                    ?.use { c -> if (c.moveToFirst()) c.getLong(0) else -1L } ?: -1L
                modelFile.parentFile?.mkdirs()
                val tmp = File(modelFile.parentFile, "model.tmp")
                cr.openInputStream(uri)!!.use { inp ->
                    tmp.outputStream().use { out ->
                        val buf = ByteArray(1 shl 20)
                        var done = 0L
                        var last = -1
                        while (true) {
                            val n = inp.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val pct = (done * 100 / total).toInt()
                                if (pct != last) { last = pct; _state.update { it.copy(copyPct = pct) } }
                            }
                        }
                    }
                }
                val magic = tmp.inputStream().use { s -> ByteArray(4).also { s.read(it) } }.decodeToString()
                if (magic != "GGUF") { tmp.delete(); error("ไฟล์นี้ไม่ใช่ GGUF") }
                tmp.renameTo(modelFile)
                _state.update { it.copy(phase = Phase.Idle, hasModel = true, status = "คัดลอกเสร็จ กด Load") }
            } catch (t: Throwable) {
                _state.update { it.copy(phase = Phase.Error, status = "คัดลอกพัง: ${t.message}") }
            }
        }
    }

    fun loadModel() {
        val st = _state.value
        if (!st.hasModel || st.phase !in setOf(Phase.Idle, Phase.Error)) return
        _state.update { it.copy(phase = Phase.Loading, status = "กำลังโหลดโมเดล...", output = "", stats = "", info = "") }
        viewModelScope.launch(llm) {
            try {
                val t0 = SystemClock.elapsedRealtime()
                LlamaBridge.loadModel(modelFile.absolutePath, nCtx, _state.value.threads)
                val ms = SystemClock.elapsedRealtime() - t0
                _state.update {
                    it.copy(
                        phase = Phase.Ready,
                        status = "พร้อม · โหลด $ms ms · PSS ${pssMb()} MB",
                        info = LlamaBridge.modelInfo() + "\n" + LlamaBridge.systemInfo().trim(),
                    )
                }
            } catch (t: Throwable) {
                _state.update { it.copy(phase = Phase.Error, status = "โหลดพัง: ${t.message}") }
            }
        }
    }

    fun unload() {
        if (_state.value.phase != Phase.Ready) return
        viewModelScope.launch(llm) {
            LlamaBridge.unload()
            _state.update { it.copy(phase = Phase.Idle, status = "ปล่อยโมเดลแล้ว · PSS ${pssMb()} MB", info = "") }
        }
    }

    fun send(system: String, user: String) {
        if (_state.value.phase != Phase.Ready || user.isBlank()) return
        _state.update { it.copy(phase = Phase.Generating, output = "", stats = "") }
        viewModelScope.launch(llm) {
            val sb = StringBuilder()
            try {
                val r = LlamaBridge.generate(system.toByteArray(), user.toByteArray(), 256) { bytes ->
                    sb.append(String(bytes, Charsets.UTF_8))
                    _state.update { it.copy(output = sb.toString()) }
                }
                _state.update {
                    it.copy(
                        phase = Phase.Ready,
                        stats = "prompt ${r[0].toInt()} tok @ ${"%.1f".format(r[1])} t/s · " +
                            "gen ${r[2].toInt()} tok @ ${"%.1f".format(r[3])} t/s · PSS ${pssMb()} MB",
                    )
                }
            } catch (t: Throwable) {
                _state.update { it.copy(phase = Phase.Ready, stats = "gen พัง: ${t.message}") }
            }
        }
    }

    fun cancel() = LlamaBridge.cancel()
}
