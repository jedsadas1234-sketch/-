#include <jni.h>
#include <android/log.h>
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <memory>
#include <string>
#include <vector>
#include "llama.h"

#define TAG "LivingWorld"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

namespace {
llama_model* g_model = nullptr;
llama_context* g_ctx = nullptr;
const llama_vocab* g_vocab = nullptr;
std::atomic<bool> g_cancel{false};
int g_n_ctx = 0;
constexpr int N_BATCH = 512;

void throw_rt(JNIEnv* env, const std::string& msg) {
    jclass c = env->FindClass("java/lang/RuntimeException");
    env->ThrowNew(c, msg.c_str());
}

void log_cb(ggml_log_level level, const char* text, void*) {
    __android_log_print(level == GGML_LOG_LEVEL_ERROR ? ANDROID_LOG_ERROR : ANDROID_LOG_INFO, TAG, "%s", text);
}

void release() {
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
    g_vocab = nullptr;
}

std::string to_str(JNIEnv* env, jbyteArray a) {
    jsize n = env->GetArrayLength(a);
    std::string s(n, '\0');
    env->GetByteArrayRegion(a, 0, n, reinterpret_cast<jbyte*>(&s[0]));
    return s;
}

// ตัดเฉพาะส่วนที่เป็น UTF-8 ครบตัวอักษร (ภาษาไทย 3 byte อาจถูกแบ่งข้าม token)
size_t utf8_complete_prefix(const std::string& s) {
    size_t n = s.size();
    for (size_t back = 1; back <= 4 && back <= n; ++back) {
        unsigned char c = (unsigned char)s[n - back];
        if ((c & 0xC0) == 0x80) continue;
        size_t need = (c >= 0xF0) ? 4 : (c >= 0xE0) ? 3 : (c >= 0xC0) ? 2 : 1;
        return need > back ? n - back : n;
    }
    return n;
}
}  // namespace

extern "C" {

JNIEXPORT void JNICALL
Java_com_livingworld_poc_LlamaBridge_loadModel(JNIEnv* env, jobject, jstring jpath, jint nCtx, jint nThreads) {
    release();
    const char* cpath = env->GetStringUTFChars(jpath, nullptr);
    std::string path(cpath);
    env->ReleaseStringUTFChars(jpath, cpath);

    llama_log_set(log_cb, nullptr);
    llama_backend_init();

    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;  // CPU ล้วนก่อน
    mp.use_mmap = true;
    g_model = llama_model_load_from_file(path.c_str(), mp);
    if (!g_model) { throw_rt(env, "llama_model_load_from_file failed (bad GGUF / not enough RAM)"); return; }

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = nCtx;
    cp.n_batch = N_BATCH;
    cp.n_ubatch = N_BATCH;
    cp.n_threads = nThreads;
    cp.n_threads_batch = nThreads;
    g_ctx = llama_init_from_model(g_model, cp);
    if (!g_ctx) { release(); throw_rt(env, "llama_init_from_model failed (context too big?)"); return; }

    g_vocab = llama_model_get_vocab(g_model);
    g_n_ctx = nCtx;
}

JNIEXPORT jstring JNICALL
Java_com_livingworld_poc_LlamaBridge_modelInfo(JNIEnv* env, jobject) {
    if (!g_model) return env->NewStringUTF("no model");
    char desc[256];
    llama_model_desc(g_model, desc, sizeof(desc));
    char out[400];
    snprintf(out, sizeof(out), "%s | %.2f GB | n_ctx %d", desc, llama_model_size(g_model) / 1e9, g_n_ctx);
    return env->NewStringUTF(out);
}

JNIEXPORT jstring JNICALL
Java_com_livingworld_poc_LlamaBridge_systemInfo(JNIEnv* env, jobject) {
    return env->NewStringUTF(llama_print_system_info());
}

JNIEXPORT void JNICALL
Java_com_livingworld_poc_LlamaBridge_cancel(JNIEnv*, jobject) { g_cancel = true; }

JNIEXPORT void JNICALL
Java_com_livingworld_poc_LlamaBridge_unload(JNIEnv*, jobject) { release(); }

// return: [promptTokens, promptTokPerSec, genTokens, genTokPerSec]
JNIEXPORT jdoubleArray JNICALL
Java_com_livingworld_poc_LlamaBridge_generate(JNIEnv* env, jobject, jbyteArray jsys, jbyteArray jusr,
                                              jint maxTokens, jobject listener) {
    if (!g_ctx) { throw_rt(env, "model not loaded"); return nullptr; }
    g_cancel = false;

    std::string sys = to_str(env, jsys), usr = to_str(env, jusr);
    jclass lc = env->GetObjectClass(listener);
    jmethodID mid = env->GetMethodID(lc, "onToken", "([B)V");

    // --- chat template ---
    std::vector<llama_chat_message> msgs;
    if (!sys.empty()) msgs.push_back({"system", sys.c_str()});
    msgs.push_back({"user", usr.c_str()});
    const char* tmpl = llama_model_chat_template(g_model, nullptr);
    std::vector<char> buf(sys.size() + usr.size() + 2048);
    int len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(), (int32_t)buf.size());
    if (len > (int)buf.size()) {
        buf.resize(len);
        len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(), (int32_t)buf.size());
    }
    if (len < 0) { throw_rt(env, "chat template failed"); return nullptr; }
    std::string prompt(buf.data(), len);

    // --- tokenize ---
    int n_prompt = -llama_tokenize(g_vocab, prompt.c_str(), (int32_t)prompt.size(), nullptr, 0, true, true);
    if (n_prompt <= 0) { throw_rt(env, "tokenize failed"); return nullptr; }
    std::vector<llama_token> toks(n_prompt);
    if (llama_tokenize(g_vocab, prompt.c_str(), (int32_t)prompt.size(), toks.data(), n_prompt, true, true) < 0) {
        throw_rt(env, "tokenize failed"); return nullptr;
    }
    if (n_prompt + maxTokens > g_n_ctx) { throw_rt(env, "prompt too long for n_ctx"); return nullptr; }

    // PoC: ทุกครั้งเริ่ม KV ใหม่ (prefix caching ค่อยทำทีหลัง)
    llama_memory_clear(llama_get_memory(g_ctx), true);

    std::unique_ptr<llama_sampler, decltype(&llama_sampler_free)> smpl(
        llama_sampler_chain_init(llama_sampler_chain_default_params()), llama_sampler_free);
    llama_sampler_chain_add(smpl.get(), llama_sampler_init_penalties(64, 1.1f, 0.0f, 0.0f));
    llama_sampler_chain_add(smpl.get(), llama_sampler_init_top_k(40));
    llama_sampler_chain_add(smpl.get(), llama_sampler_init_top_p(0.95f, 1));
    llama_sampler_chain_add(smpl.get(), llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(smpl.get(), llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    using clk = std::chrono::steady_clock;
    auto t0 = clk::now();

    // --- prefill (แบ่งเป็นก้อน) ---
    for (int i = 0; i < n_prompt; i += N_BATCH) {
        if (g_cancel) break;
        int n = std::min(N_BATCH, n_prompt - i);
        llama_batch b = llama_batch_get_one(toks.data() + i, n);
        if (llama_decode(g_ctx, b) != 0) { throw_rt(env, "llama_decode failed (prefill)"); return nullptr; }
    }
    auto t1 = clk::now();

    // --- generate ---
    std::string pending;
    int n_gen = 0;
    auto emit = [&](const std::string& bytes) -> bool {
        if (bytes.empty()) return true;
        jbyteArray arr = env->NewByteArray((jsize)bytes.size());
        env->SetByteArrayRegion(arr, 0, (jsize)bytes.size(), reinterpret_cast<const jbyte*>(bytes.data()));
        env->CallVoidMethod(listener, mid, arr);
        env->DeleteLocalRef(arr);
        if (env->ExceptionCheck()) { env->ExceptionClear(); return false; }
        return true;
    };

    while (!g_cancel && n_gen < maxTokens) {
        llama_token id = llama_sampler_sample(smpl.get(), g_ctx, -1);
        if (llama_vocab_is_eog(g_vocab, id)) break;

        char piece[256];
        int pn = llama_token_to_piece(g_vocab, id, piece, sizeof(piece), 0, true);
        if (pn > 0) pending.append(piece, pn);
        size_t ok = utf8_complete_prefix(pending);
        if (ok > 0) {
            if (!emit(pending.substr(0, ok))) break;
            pending.erase(0, ok);
        }
        ++n_gen;

        llama_batch b = llama_batch_get_one(&id, 1);
        if (llama_decode(g_ctx, b) != 0) { LOGE("decode failed in gen loop"); break; }
    }
    emit(pending);
    auto t2 = clk::now();

    double ps = std::chrono::duration<double>(t1 - t0).count();
    double gs = std::chrono::duration<double>(t2 - t1).count();
    jdouble vals[4] = {(double)n_prompt, ps > 0 ? n_prompt / ps : 0, (double)n_gen, gs > 0 ? n_gen / gs : 0};
    jdoubleArray r = env->NewDoubleArray(4);
    env->SetDoubleArrayRegion(r, 0, 4, vals);
    return r;
}

}  // extern "C"
