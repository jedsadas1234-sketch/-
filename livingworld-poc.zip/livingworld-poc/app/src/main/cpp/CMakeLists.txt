cmake_minimum_required(VERSION 3.22.1)
project(lwllama LANGUAGES C CXX)

# บังคับ Release เสมอ (Debug ของ ggml ช้ามาก วัดผลไม่ได้)
set(CMAKE_BUILD_TYPE Release)
set(CMAKE_C_FLAGS_RELEASE "-O3 -DNDEBUG")
set(CMAKE_CXX_FLAGS_RELEASE "-O3 -DNDEBUG")
set(CMAKE_CXX_STANDARD 17)

set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_COMMON OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TOOLS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_SERVER OFF CACHE BOOL "" FORCE)
set(LLAMA_CURL OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP OFF CACHE BOOL "" FORCE)
set(GGML_NATIVE OFF CACHE BOOL "" FORCE)
# Snapdragon 8s Gen 4 (X4/A720/A520) รองรับ dotprod + i8mm
# ถ้ารันแล้ว SIGILL ให้เปลี่ยนเป็น armv8.2-a+dotprod
set(GGML_CPU_ARM_ARCH "armv8.6-a+dotprod+i8mm" CACHE STRING "" FORCE)

include(FetchContent)
FetchContent_Declare(llama
    GIT_REPOSITORY https://github.com/ggml-org/llama.cpp.git
    GIT_TAG b6400
    GIT_SHALLOW TRUE)
FetchContent_MakeAvailable(llama)

add_library(lwllama SHARED llama_jni.cpp)
target_link_libraries(lwllama llama log android)
