cmake_minimum_required(VERSION 3.22.1)
project(lwllama LANGUAGES C CXX)

# บังคับ Release เสมอ (Debug ของ ggml ช้ามาก วัดผลไม่ได้)
set(CMAKE_BUILD_TYPE Release)
set(CMAKE_C_FLAGS_RELEASE "-O3 -DNDEBUG")
set(CMAKE_CXX_FLAGS_RELEASE "-O3 -DNDEBUG")
set(CMAKE_CXX_STANDARD 17)

set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_COMMON OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TOOLS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_SERVER OFF CACHE BOOL "" FORCE)
set(LLAMA_CURL OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP OFF CACHE BOOL "" FORCE)
set(GGML_NATIVE OFF CACHE BOOL "" FORCE)
# Snapdragon 8s Gen 4 (X4/A720/A520) รองรับ dotprod + i8mm
# ถ้ารันแล้ว SIGILL ให้เปลี่ยนเป็น armv8.2-a+dotprod
set(GGML_CPU_ARM_ARCH "armv8.6-a+dotprod+i8mm" CACHE STRING "" FORCE)

# FetchContent + GIT_SHALLOW พังกับ tag เก่า (shallow clone ไม่ดึง tag ที่ไม่ใช่ปลาย branch)
# เลยโคลนเองด้วย --branch <tag> ซึ่งรองรับ tag โดยตรง
# โค้ด JNI เขียนตาม API ก่อน b10258 (llama_sampler_init_penalties ยังมี 4 พารามิเตอร์)
# ถ้าจะอัป tag ใหม่กว่านั้นต้องแก้ llama_jni.cpp ด้วย
set(LLAMA_TAG "b7339" CACHE STRING "llama.cpp tag")
set(LLAMA_SRC "${CMAKE_BINARY_DIR}/llama-src")
if(NOT EXISTS "${LLAMA_SRC}/CMakeLists.txt")
    execute_process(
        COMMAND git clone --depth 1 --branch ${LLAMA_TAG}
                https://github.com/ggml-org/llama.cpp.git "${LLAMA_SRC}"
        RESULT_VARIABLE GIT_RES)
    if(NOT GIT_RES EQUAL 0)
        message(FATAL_ERROR "git clone llama.cpp tag ${LLAMA_TAG} failed")
    endif()
endif()
add_subdirectory("${LLAMA_SRC}" llama-build)

add_library(lwllama SHARED llama_jni.cpp)
target_link_libraries(lwllama llama log android)
