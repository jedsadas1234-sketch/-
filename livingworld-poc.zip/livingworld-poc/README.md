# LIVING WORLD — PoC 0.1 (โหลด LLM ในแอป + แชท)

ยังไม่ได้ build/ทดสอบจริงเลย ห้ามเชื่อว่ามันรันได้จนกว่าจะเห็นกับตา

## Build (ไม่ต้องมี PC)
1. สร้าง repo บน GitHub แล้ว push โฟลเดอร์นี้ทั้งก้อน (รวม `.github/`) — ใช้ Termux + git ง่ายกว่าอัปโหลดผ่านเว็บ
2. แท็บ Actions → build-apk → รอ ~10-20 นาที (ครั้งแรกช้า เพราะ compile llama.cpp)
3. โหลด artifact `livingworld-poc-debug` มาติดตั้ง
4. build พัง → copy error ท้ายสุดมาให้กู

## โมเดลที่ต้องลอง (GGUF, Q4_K_M, ~2 GB)
- Llama-3.2-3B-Instruct-Q4_K_M (เช่นของ bartowski บน Hugging Face)
- Qwen2.5-3B-Instruct-Q4_K_M  ← น่าจะไทยดีกว่า
- (ถ้ามีแรง) Gemma-3-4B-it-Q4_K_M

## วิธีวัด (ข้อ F ในสเปค)
- โหลดเวลา / PSS / tok/s: แอปโชว์ให้เอง
- RAM จริง: `adb shell dumpsys meminfo com.livingworld.poc` (ถ้าไม่มี adb ใช้ตัวเลข PSS ในแอป)
- อุณหภูมิ: ให้มัน gen ซ้ำ 10 นาที แล้วดู tok/s ว่าตกไหม (ตกคือ throttle)
- แบต: % ที่หายใน 30 นาทีของการ gen ต่อเนื่อง
- ลอง threads 3/4/5/6 เทียบกัน
