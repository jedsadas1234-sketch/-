package com.pocketai.app.team

import com.pocketai.app.ai.GenSettings
import com.pocketai.app.data.AppSettings
import com.pocketai.app.data.ChatMessage
import com.pocketai.app.data.Role
import com.pocketai.app.data.StepStatus
import com.pocketai.app.llm.ModelManager
import com.pocketai.app.llm.ResourcePolicy
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext

class MeetingCallbacks(
    val status: (String) -> Unit,
    val turn: (MeetingTurn) -> Unit,
    val notice: (String) -> Unit,
)

/**
 * "Model introduction": each enabled model introduces itself, then reacts to a teammate, then the
 * Main model summarizes and suggests roles. What a model says about itself is shown as an
 * unverified self-description next to facts read from its file. Nothing is applied automatically.
 */
class MeetingEngine(private val exec: ExecutionManager, private val models: ModelManager) {

    private val system = "You are a helpful local language model on a phone. Be concise and honest. Reply in English."

    suspend fun run(team: TeamConfig, settings: AppSettings, baseGen: GenSettings, ui: MeetingCallbacks): TeamProfile {
        val members = team.enabled
        if (members.size < 2) throw RunFailedException("A meeting needs at least two enabled models.")
        val main = members.first()
        val keep = setOf(main.file)
        val discussionRounds = settings.meetingRounds.coerceIn(1, 2)
        val totalRounds = 1 + discussionRounds + 1
        val gen = baseGen.copy(maxTokens = minOf(baseGen.maxTokens, 256))
        val threads = ResourcePolicy.defaultThreads(Runtime.getRuntime().availableProcessors())
        val profiles = ArrayList<ModelProfile>()
        val turns = ArrayList<MeetingTurn>()

        try {
            // ---- round 1: introductions ----
            members.forEachIndexed { i, s ->
                val name = displayName(s.file)
                ui.status("Round 1 of $totalRounds: $name introduces itself (${i + 1}/${members.size})")
                val verified = withContext(Dispatchers.IO) {
                    models.fileByName(s.file)?.let { models.verifiedInfo(it) } ?: VerifiedInfo(0L, null, null, null, null)
                }
                val (text, err) = ask(s.file, Prompts.meetingIntro(name, team), keep, gen, threads, ui)
                profiles.add(
                    ModelProfile(
                        file = s.file,
                        verified = verified,
                        raw = text,
                        strengths = field(text, "STRENGTHS"),
                        limitations = field(text, "LIMITATIONS"),
                        suggestedRole = field(text, "SUGGESTED ROLE"),
                        workingStyle = field(text, "WORKING STYLE"),
                        ok = err == null && text.isNotBlank(),
                        error = err,
                    )
                )
                ui.turn(MeetingTurn(1, name, null, text, err == null && text.isNotBlank(), err))
                if (err != null) ui.notice("$name could not introduce itself: $err")
            }

            // ---- discussion rounds ----
            val okProfiles = profiles.filter { it.ok }
            val intros = okProfiles.map { displayName(it.file) to it.raw }
            if (okProfiles.size < 2) {
                ui.notice("Fewer than two models introduced themselves, so the discussion was skipped.")
            } else {
                for (r in 1..discussionRounds) {
                    okProfiles.forEachIndexed { i, p ->
                        val speaker = displayName(p.file)
                        val target = displayName(okProfiles[(i - 1 + okProfiles.size) % okProfiles.size].file)
                        ui.status("Round ${1 + r} of $totalRounds: $speaker responds to $target")
                        val context = intros + turns.filter { it.round > 1 && it.ok }.map { "${it.speaker} to ${it.respondingTo ?: "all"}" to it.text }
                        val (text, err) = ask(p.file, Prompts.meetingResponse(speaker, target, context), keep, gen, threads, ui)
                        val turn = MeetingTurn(1 + r, speaker, target, text, err == null && text.isNotBlank(), err)
                        turns.add(turn)
                        ui.turn(turn)
                        if (err != null) ui.notice("$speaker could not respond: $err")
                    }
                }
            }

            // ---- summary by Main ----
            val mainName = displayName(main.file)
            ui.status("Round $totalRounds of $totalRounds: $mainName writes the summary")
            val (sumText, sumErr) = ask(main.file, Prompts.meetingSummary(team, intros, turns.filter { it.ok }), keep, gen.copy(maxTokens = 384), threads, ui)
            if (sumErr != null) ui.notice("The summary could not be written: $sumErr")
            val suggestions = parseAssignments(sumText, team)
            val summary = sumText.lines().filterNot { it.trimStart().startsWith("ASSIGN:", ignoreCase = true) }.joinToString("\n").trim()
            return TeamProfile(
                createdAt = System.currentTimeMillis(),
                fingerprint = team.fingerprint(),
                profiles = profiles,
                turns = turns,
                summary = summary,
                suggestions = suggestions,
                complete = sumErr == null && summary.isNotBlank(),
            )
        } finally {
            withContext(NonCancellable) { exec.finish(if (settings.keepMainLoaded) main.file else null) }
        }
    }

    /** Runs one meeting step. Returns reply text and an error message (null on success). */
    private suspend fun ask(
        file: String,
        prompt: String,
        keep: Set<String>,
        gen: GenSettings,
        threads: Int,
        ui: MeetingCallbacks,
    ): Pair<String, String?> =
        try {
            val out = exec.runStep(
                file, listOf(ChatMessage(-1L, Role.USER, prompt)), system, gen, keep, threads,
                ExecutionManager.Callbacks(onNotice = ui.notice), StepStatus.THINKING,
            )
            out to null
        } catch (e: CancellationException) {
            throw e
        } catch (e: ThermalSuspendedException) {
            throw e
        } catch (e: StepTimeoutException) {
            e.partial to (e.message ?: "Timed out.")
        } catch (e: Exception) {
            "" to (e.message ?: e.javaClass.simpleName)
        }

    private fun field(text: String, label: String): String =
        Regex("(?im)^\\s*\\**\\s*" + Regex.escape(label) + "\\s*\\**\\s*:\\s*(.*)$").find(text)?.groupValues?.get(1)
            ?.trim()?.trim('*')?.trim() ?: ""

    private fun parseAssignments(text: String, team: TeamConfig): List<RoleSuggestion> {
        val out = ArrayList<RoleSuggestion>()
        val members = team.enabled
        Regex("(?im)^\\s*ASSIGN:\\s*(.+?)\\s*=\\s*([A-Za-z]+)\\s*$").findAll(text).forEach { m ->
            val name = m.groupValues[1].trim().trim('*', '`', '"', '\'')
            val role = ModelRole.values().firstOrNull { it.label.equals(m.groupValues[2], ignoreCase = true) } ?: return@forEach
            val idx = members.indexOfFirst { displayName(it.file).equals(name, ignoreCase = true) || it.file.equals(name, ignoreCase = true) }
            // Main stays Main; nobody else can be made Main by a model's suggestion
            if (idx > 0 && role != ModelRole.MAIN && out.none { it.file == members[idx].file }) {
                out.add(RoleSuggestion(members[idx].file, role))
            }
        }
        return out
    }
}
