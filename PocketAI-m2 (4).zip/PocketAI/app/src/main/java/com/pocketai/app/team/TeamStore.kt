package com.pocketai.app.team

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Team setup and the last meeting result, as JSON in app-private storage. */
class TeamStore(context: Context) {
    private val cfgFile = File(context.filesDir, "team.json")
    private val profFile = File(context.filesDir, "team_profile.json")

    @Synchronized
    fun loadConfig(): TeamConfig {
        if (!cfgFile.exists()) return TeamConfig()
        return try {
            val o = JSONObject(cfgFile.readText())
            val arr = o.getJSONArray("slots")
            TeamConfig(
                slots = (0 until arr.length()).map {
                    val s = arr.getJSONObject(it)
                    ModelSlot(
                        file = s.getString("file"),
                        role = roleOr(s.optString("role")),
                        enabled = s.optBoolean("enabled", true),
                    )
                },
                synthesizerFile = if (o.isNull("synth")) null else o.optString("synth").ifBlank { null },
            )
        } catch (_: Exception) {
            TeamConfig()
        }
    }

    @Synchronized
    fun saveConfig(c: TeamConfig) {
        try {
            val arr = JSONArray()
            c.slots.forEach { arr.put(JSONObject().put("file", it.file).put("role", it.role.name).put("enabled", it.enabled)) }
            cfgFile.writeText(JSONObject().put("slots", arr).put("synth", c.synthesizerFile ?: JSONObject.NULL).toString())
        } catch (_: Exception) {
        }
    }

    @Synchronized
    fun loadProfile(): TeamProfile? {
        if (!profFile.exists()) return null
        return try {
            val o = JSONObject(profFile.readText())
            val ps = o.getJSONArray("profiles")
            val ts = o.getJSONArray("turns")
            val ss = o.getJSONArray("suggestions")
            TeamProfile(
                createdAt = o.getLong("createdAt"),
                fingerprint = o.getString("fingerprint"),
                profiles = (0 until ps.length()).map {
                    val p = ps.getJSONObject(it)
                    val v = p.getJSONObject("verified")
                    ModelProfile(
                        file = p.getString("file"),
                        verified = VerifiedInfo(
                            sizeBytes = v.getLong("size"),
                            architecture = v.optString("arch").ifBlank { null },
                            ggufName = v.optString("name").ifBlank { null },
                            quantization = v.optString("quant").ifBlank { null },
                            trainedContext = if (v.isNull("ctx")) null else v.getLong("ctx"),
                        ),
                        raw = p.optString("raw"),
                        strengths = p.optString("strengths"),
                        limitations = p.optString("limitations"),
                        suggestedRole = p.optString("suggestedRole"),
                        workingStyle = p.optString("workingStyle"),
                        ok = p.optBoolean("ok", false),
                        error = if (p.isNull("error")) null else p.getString("error"),
                    )
                },
                turns = (0 until ts.length()).map {
                    val t = ts.getJSONObject(it)
                    MeetingTurn(
                        round = t.getInt("round"),
                        speaker = t.getString("speaker"),
                        respondingTo = if (t.isNull("to")) null else t.getString("to"),
                        text = t.optString("text"),
                        ok = t.optBoolean("ok", false),
                        error = if (t.isNull("error")) null else t.getString("error"),
                    )
                },
                summary = o.optString("summary"),
                suggestions = (0 until ss.length()).map {
                    val s = ss.getJSONObject(it)
                    RoleSuggestion(s.getString("file"), roleOr(s.optString("role")))
                },
                complete = o.optBoolean("complete", false),
            )
        } catch (_: Exception) {
            null
        }
    }

    @Synchronized
    fun saveProfile(p: TeamProfile) {
        try {
            val o = JSONObject()
                .put("createdAt", p.createdAt)
                .put("fingerprint", p.fingerprint)
                .put("summary", p.summary)
                .put("complete", p.complete)
            o.put(
                "profiles",
                JSONArray().also { a ->
                    p.profiles.forEach {
                        a.put(
                            JSONObject()
                                .put("file", it.file)
                                .put(
                                    "verified",
                                    JSONObject()
                                        .put("size", it.verified.sizeBytes)
                                        .put("arch", it.verified.architecture ?: "")
                                        .put("name", it.verified.ggufName ?: "")
                                        .put("quant", it.verified.quantization ?: "")
                                        .put("ctx", it.verified.trainedContext ?: JSONObject.NULL),
                                )
                                .put("raw", it.raw).put("strengths", it.strengths).put("limitations", it.limitations)
                                .put("suggestedRole", it.suggestedRole).put("workingStyle", it.workingStyle)
                                .put("ok", it.ok).put("error", it.error ?: JSONObject.NULL)
                        )
                    }
                },
            )
            o.put(
                "turns",
                JSONArray().also { a ->
                    p.turns.forEach {
                        a.put(
                            JSONObject().put("round", it.round).put("speaker", it.speaker)
                                .put("to", it.respondingTo ?: JSONObject.NULL).put("text", it.text)
                                .put("ok", it.ok).put("error", it.error ?: JSONObject.NULL)
                        )
                    }
                },
            )
            o.put(
                "suggestions",
                JSONArray().also { a -> p.suggestions.forEach { a.put(JSONObject().put("file", it.file).put("role", it.role.name)) } },
            )
            profFile.writeText(o.toString())
        } catch (_: Exception) {
        }
    }

    private fun roleOr(name: String): ModelRole = try {
        ModelRole.valueOf(name)
    } catch (_: Exception) {
        ModelRole.REVIEWER
    }
}
