package com.pocketai.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.pocketai.app.llm.MemoryEstimate
import com.pocketai.app.llm.ModelManager
import com.pocketai.app.llm.NativeLlama
import com.pocketai.app.llm.formatBytes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModelsScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val m = vm.models
    val s = vm.settings
    val status = m.status
    var confirmDelete by remember { mutableStateOf<ModelManager.ModelFile?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) m.import(uri)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Models") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .consumeWindowInsets(pad)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            // ---- status ----
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    when (status) {
                        is ModelManager.Status.Importing -> {
                            Text("Importing ${status.name}", style = MaterialTheme.typography.titleSmall)
                            if (status.total > 0) {
                                LinearProgressIndicator(
                                    progress = { (status.copied.toFloat() / status.total).coerceIn(0f, 1f) },
                                    modifier = Modifier.fillMaxWidth(),
                                )
                                Text(
                                    "${formatBytes(status.copied)} / ${formatBytes(status.total)}",
                                    style = MaterialTheme.typography.bodySmall,
                                )
                            } else {
                                LinearProgressIndicator(Modifier.fillMaxWidth())
                                Text(formatBytes(status.copied), style = MaterialTheme.typography.bodySmall)
                            }
                            TextButton(onClick = m::cancelImport) { Text("Cancel") }
                        }
                        is ModelManager.Status.Loading -> {
                            Text("Loading ${status.name}…", style = MaterialTheme.typography.titleSmall)
                            LinearProgressIndicator(Modifier.fillMaxWidth())
                        }
                        is ModelManager.Status.Idle -> {
                            if (m.loaded.isEmpty()) {
                                Text("No model loaded", style = MaterialTheme.typography.titleSmall)
                                Text("Models load automatically when you send a message.", style = MaterialTheme.typography.bodySmall)
                            } else {
                                Text("In memory: ${m.loaded.keys.joinToString { it.removeSuffix(".gguf") }}", style = MaterialTheme.typography.titleSmall)
                                m.loaded.values.forEach { e ->
                                    Text("${e.file.name}: context ${e.nCtx}", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        is ModelManager.Status.Failed -> {
                            Text("Error", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.error)
                            Text(status.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        }
                    }
                    if (!NativeLlama.available) {
                        Text(
                            "Native engine unavailable: ${NativeLlama.loadError}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                        )
                    }
                }
            }

            // ---- import ----
            FilledTonalButton(
                onClick = { picker.launch(arrayOf("*/*")) },
                enabled = !m.busy,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Import GGUF file") }
            Text(
                "The file is copied into app storage and never uploaded. Not every model or quantization will run. " +
                    "Small instruct models (1B–3B, Q4) fit most phones. Device RAM: ${formatBytes(m.totalRamBytes)}.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            // ---- imported list ----
            Text("Imported models", style = MaterialTheme.typography.titleMedium)
            if (m.files.isEmpty()) {
                Text("None yet.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            m.files.forEach { f ->
                val isLoaded = m.isLoaded(f.name)
                val effCtx = if (s.contextLength > 0) s.contextLength else m.defaultContext()
                val est by produceState<MemoryEstimate?>(null, f.name, effCtx) {
                    value = withContext(Dispatchers.IO) { m.estimateMemory(f, effCtx) }
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(f.name, style = MaterialTheme.typography.bodyLarge)
                        Text(formatBytes(f.sizeBytes), style = MaterialTheme.typography.bodySmall)
                        est?.let { e ->
                            val kv = e.kvBytes
                            Text(
                                if (kv != null) {
                                    "RAM ≈ ${formatBytes(e.totalBytes)} (context $effCtx: ${formatBytes(kv)}), estimate"
                                } else {
                                    "RAM ≥ ${formatBytes(e.totalBytes)}, context size unknown (header unreadable), estimate"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            if (e.totalBytes > m.availRamBytes) {
                                Text(
                                    "May not fit: ${formatBytes(m.availRamBytes)} RAM free now. Try a smaller context or model.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.error,
                                )
                            }
                        }
                    }
                    if (isLoaded) {
                        TextButton(onClick = { vm.unloadModel(f.name) }, enabled = !m.busy) { Text("Unload") }
                    } else {
                        Button(onClick = { vm.loadModel(f) }, enabled = !m.busy) { Text("Load") }
                    }
                    IconButton(onClick = { confirmDelete = f }, enabled = status !is ModelManager.Status.Importing && status !is ModelManager.Status.Loading) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete ${f.name}")
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            // ---- generation settings ----
            Text("Generation", style = MaterialTheme.typography.titleMedium)
            Text("Context length (applies on next load)")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                listOf(0, 1024, 2048, 4096, 8192).forEach { n ->
                    FilterChip(
                        selected = s.contextLength == n,
                        onClick = { vm.setContextLength(n) },
                        label = { Text(if (n == 0) "Auto (${m.defaultContext()})" else n.toString()) },
                    )
                }
            }
            Text("Max new tokens: ${s.maxTokens}")
            Slider(
                value = s.maxTokens.toFloat(),
                onValueChange = { vm.setMaxTokens(((it / 32f).roundToInt() * 32).coerceIn(64, 2048)) },
                valueRange = 64f..2048f,
            )
            Text("Temperature: ${"%.2f".format(s.temperature)}" + if (s.temperature <= 0.01f) " (greedy)" else "")
            Slider(
                value = s.temperature,
                onValueChange = { vm.setTemperature((it * 20f).roundToInt() / 20f) },
                valueRange = 0f..1.5f,
            )
            Text("Top-p: ${"%.2f".format(s.topP)}")
            Slider(
                value = s.topP,
                onValueChange = { vm.setTopP((it * 20f).roundToInt() / 20f) },
                valueRange = 0.1f..1f,
            )
            Text("Top-k: ${if (s.topK <= 0) "off" else s.topK.toString()}")
            Slider(
                value = s.topK.toFloat(),
                onValueChange = { vm.setTopK(it.roundToInt().coerceIn(0, 100)) },
                valueRange = 0f..100f,
            )
            Text("Top-p and top-k are ignored when temperature is 0 (greedy).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                "Larger context uses more RAM. If loading crashes or fails, pick a smaller context or model.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }

    confirmDelete?.let { f ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Delete model?") },
            text = { Text("${f.name} (${formatBytes(f.sizeBytes)}) will be removed from app storage.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteModel(f)
                    confirmDelete = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancel") } },
        )
    }
}
