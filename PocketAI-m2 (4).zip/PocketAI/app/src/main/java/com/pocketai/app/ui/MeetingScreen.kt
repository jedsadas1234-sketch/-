package com.pocketai.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.pocketai.app.llm.formatBytes
import com.pocketai.app.team.MeetingTurn
import com.pocketai.app.team.ModelProfile

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MeetingScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val profile = vm.teamProfile
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Model introduction") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") } },
            )
        },
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                "Each active model introduces itself, reacts to a teammate, and the Main model summarizes. " +
                    "What a model says about itself is its own claim and may be wrong. Verified facts come from the model file.",
                style = MaterialTheme.typography.bodySmall, color = muted,
            )
            if (vm.meetingRunning) {
                androidx.compose.foundation.layout.Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.padding(end = 12.dp), strokeWidth = 2.dp)
                    Text(vm.meetingStatus, style = MaterialTheme.typography.bodyMedium)
                }
                OutlinedButton(onClick = vm::cancelMeeting) { Text("Cancel meeting") }
            } else {
                Button(onClick = vm::startMeeting, enabled = vm.team.enabled.size >= 2 && !vm.generating, modifier = Modifier.fillMaxWidth()) {
                    Text(if (profile == null) "Start meeting" else "Run the meeting again")
                }
                if (vm.meetingStatus.isNotBlank()) Text(vm.meetingStatus, style = MaterialTheme.typography.bodySmall, color = muted)
            }
            vm.meetingError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            vm.meetingNotices.forEach { Text("Note: $it", style = MaterialTheme.typography.bodySmall, color = muted) }

            // live transcript while running
            if (vm.meetingRunning && vm.meetingTurns.isNotEmpty()) {
                SectionCard("Transcript so far") { vm.meetingTurns.forEach { TurnView(it) } }
            }

            if (profile != null && !vm.meetingRunning) {
                if (profile.fingerprint != vm.team.fingerprint()) {
                    Text("This profile is outdated: the team changed after the meeting.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                if (profile.summary.isNotBlank()) SectionCard("Summary by the Main model") { Text(profile.summary) }
                if (profile.suggestions.isNotEmpty()) {
                    SectionCard("Suggested roles") {
                        profile.suggestions.forEach { Text("${it.file.removeSuffix(".gguf")}: ${it.role.label}") }
                        Text("Suggestions only. Nothing changes until you apply them.", style = MaterialTheme.typography.bodySmall, color = muted)
                        Button(onClick = vm::applySuggestedRoles) { Text("Apply suggested roles") }
                    }
                }
                profile.profiles.forEach { ProfileCard(it) }
                if (profile.turns.isNotEmpty()) SectionCard("Discussion") { profile.turns.forEach { TurnView(it) } }
                if (!profile.complete) Text("The meeting did not finish cleanly; some parts are missing.", style = MaterialTheme.typography.bodySmall, color = muted)
            }
        }
    }
}

@Composable
private fun TurnView(t: MeetingTurn) {
    Column(Modifier.fillMaxWidth()) {
        Text(
            "Round ${t.round}: ${t.speaker}" + (t.respondingTo?.let { " → $it" } ?: ""),
            style = MaterialTheme.typography.labelMedium,
        )
        if (t.ok) Text(t.text, style = MaterialTheme.typography.bodySmall)
        else Text(t.error ?: "No reply.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
    }
}

@Composable
private fun ProfileCard(p: ModelProfile) {
    SectionCard(p.file.removeSuffix(".gguf")) {
        Text("Verified from the file", style = MaterialTheme.typography.labelMedium)
        val v = p.verified
        Text(
            listOfNotNull(
                "size ${formatBytes(v.sizeBytes)}",
                v.architecture?.let { "architecture $it" },
                v.quantization?.let { "quantization $it" },
                v.trainedContext?.let { "trained context $it" },
            ).joinToString(" • "),
            style = MaterialTheme.typography.bodySmall,
        )
        Text("Self-description (not verified)", style = MaterialTheme.typography.labelMedium)
        if (!p.ok) {
            Text(p.error ?: "No introduction.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        } else if (p.strengths.isBlank() && p.limitations.isBlank()) {
            Text(p.raw, style = MaterialTheme.typography.bodySmall)
        } else {
            Text("Strengths: ${p.strengths}", style = MaterialTheme.typography.bodySmall)
            Text("Limitations: ${p.limitations}", style = MaterialTheme.typography.bodySmall)
            Text("Suggested role: ${p.suggestedRole}", style = MaterialTheme.typography.bodySmall)
            Text("Working style: ${p.workingStyle}", style = MaterialTheme.typography.bodySmall)
        }
    }
}
