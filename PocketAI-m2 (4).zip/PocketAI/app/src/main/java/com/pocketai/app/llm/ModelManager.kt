package com.pocketai.app.llm

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/** Thrown when a model cannot be loaded safely. The message is shown to the user. */
class ModelLoadException(message: String) : Exception(message)

/**
 * Imports GGUF files into app storage and keeps loaded engines. Several models can be resident at
 * once when they fit the memory budget. Nothing is uploaded anywhere.
 */
class ModelManager(private val app: Application, private val scope: CoroutineScope) {

    data class ModelFile(val name: String, val sizeBytes: Long)

    /** A model resident in memory. [handle] is the native engine. */
    class LoadedEngine(val file: ModelFile, val handle: Long, val nCtx: Int, val info: String)

    sealed interface Status {
        data object Idle : Status
        data class Importing(val name: String, val copied: Long, val total: Long) : Status
        data class Loading(val name: String) : Status
        data class Failed(val message: String) : Status
    }

    private val dir = File(app.filesDir, "models").apply { mkdirs() }

    var status by mutableStateOf<Status>(Status.Idle)
        private set
    var files by mutableStateOf(scan())
        private set

    /** Models currently in memory, oldest first. */
    var loaded by mutableStateOf<Map<String, LoadedEngine>>(emptyMap())
        private set

    private val engineMutex = Mutex()
    private var importJob: Job? = null

    val busy: Boolean get() = status is Status.Importing || status is Status.Loading

    fun fileByName(name: String): ModelFile? = files.firstOrNull { it.name == name }

    fun isLoaded(name: String): Boolean = loaded.containsKey(name)

    val totalRamBytes: Long
        get() {
            val am = app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            return mi.totalMem
        }

    val availRamBytes: Long
        get() {
            val am = app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            return mi.availMem
        }

    private val metaCache = HashMap<String, GgufMeta?>()

    private fun metaOf(file: ModelFile): GgufMeta? {
        val key = "${file.name}:${file.sizeBytes}"
        return synchronized(metaCache) {
            if (metaCache.containsKey(key)) metaCache[key]
            else GgufReader.read(File(dir, file.name)).also { metaCache[key] = it }
        }
    }

    /**
     * Approximate RAM need: weights (file size, mmapped) + KV cache computed from the GGUF header
     * + a fixed compute-buffer allowance. Blocking file read: call off the main thread.
     */
    fun estimateMemory(file: ModelFile, nCtx: Int): MemoryEstimate {
        val meta = metaOf(file)
        return MemoryEstimate(file.sizeBytes, meta?.let { estimateKvBytes(it, nCtx) }, COMPUTE_OVERHEAD_BYTES)
    }

    /** Facts read from the file itself (not what a model claims about itself). Blocking read. */
    fun verifiedInfo(file: ModelFile): com.pocketai.app.team.VerifiedInfo {
        val m = metaOf(file)
        val quant = quantLabel(m?.fileType) ?: Regex("(?i)(IQ\\d_[A-Z]+|Q\\d_K_[SML]|Q\\d_K|Q\\d_\\d|BF16|F16|F32)")
            .find(file.name)?.value?.uppercase()
        return com.pocketai.app.team.VerifiedInfo(file.sizeBytes, m?.architecture, m?.name, quant, m?.contextLength)
    }

    /** Context length actually used: the setting, or a safe default for this device's RAM. */
    fun effectiveContext(requested: Int): Int = if (requested > 0) requested else defaultContext()

    /** Safe default context length for this device's RAM. */
    fun defaultContext(): Int {
        val gb = totalRamBytes / 1e9
        return when {
            gb < 3.5 -> 1024
            gb < 6.5 -> 2048
            else -> 4096
        }
    }

    private fun scan(): List<ModelFile> =
        dir.listFiles { f -> f.isFile && f.name.endsWith(".gguf", ignoreCase = true) }
            ?.map { ModelFile(it.name, it.length()) }
            ?.sortedBy { it.name.lowercase() }
            ?: emptyList()

    fun import(uri: Uri) {
        if (busy) return
        importJob = scope.launch(Dispatchers.IO) {
            var part: File? = null
            try {
                var display = "model.gguf"
                var size = -1L
                app.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (ni >= 0) display = c.getString(ni) ?: display
                        val si = c.getColumnIndex(OpenableColumns.SIZE)
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                    }
                }
                val name = display.replace(Regex("[^A-Za-z0-9._-]"), "_")
                if (!name.endsWith(".gguf", ignoreCase = true)) {
                    status = Status.Failed("Not a .gguf file: $display")
                    return@launch
                }
                if (loaded.containsKey(name)) {
                    status = Status.Failed("$name is loaded. Unload it before importing a file with the same name.")
                    return@launch
                }
                if (size > 0 && dir.usableSpace < size + 200L * 1024 * 1024) {
                    status = Status.Failed("Not enough free storage for ${formatBytes(size)}.")
                    return@launch
                }
                status = Status.Importing(name, 0, size)

                val input = app.contentResolver.openInputStream(uri)
                if (input == null) {
                    status = Status.Failed("Cannot open the selected file.")
                    return@launch
                }
                input.use { ins ->
                    val head = ByteArray(4)
                    var got = 0
                    while (got < 4) {
                        val r = ins.read(head, got, 4 - got)
                        if (r < 0) break
                        got += r
                    }
                    if (got < 4 || String(head, Charsets.ISO_8859_1) != "GGUF") {
                        status = Status.Failed("Not a valid GGUF file (missing GGUF header).")
                        return@launch
                    }
                    val partFile = File(dir, "$name.part")
                    part = partFile
                    FileOutputStream(partFile).use { out ->
                        out.write(head)
                        var copied = 4L
                        var lastReport = 0L
                        val buf = ByteArray(1 shl 20)
                        while (true) {
                            ensureActive()
                            val r = ins.read(buf)
                            if (r < 0) break
                            out.write(buf, 0, r)
                            copied += r
                            if (copied - lastReport > (8L shl 20)) {
                                status = Status.Importing(name, copied, size)
                                lastReport = copied
                            }
                        }
                    }
                }
                val target = File(dir, name)
                if (target.exists()) target.delete()
                if (!part!!.renameTo(target)) throw java.io.IOException("Could not move imported file into place.")
                part = null
                synchronized(metaCache) { metaCache.clear() }
                files = scan()
                status = Status.Idle
            } catch (e: CancellationException) {
                part?.delete()
                status = Status.Idle
                throw e
            } catch (e: Exception) {
                part?.delete()
                status = Status.Failed(e.message ?: e.javaClass.simpleName)
            }
        }
    }

    fun cancelImport() {
        importJob?.cancel()
    }

    // ---- engines ----

    /**
     * Returns the resident engine for [file], loading it first if needed. Models in [keep] are never
     * evicted; others are unloaded (oldest first) when several models would not fit the memory
     * budget together. Throws [ModelLoadException] with a readable reason.
     */
    suspend fun ensureLoaded(
        file: ModelFile,
        requestedCtx: Int,
        keep: Set<String>,
        threads: Int = ResourcePolicy.defaultThreads(Runtime.getRuntime().availableProcessors()),
    ): LoadedEngine = engineMutex.withLock {
        loaded[file.name]?.let { return@withLock it }
        if (!NativeLlama.available) {
            throw ModelLoadException("Native engine failed to load: ${NativeLlama.loadError}")
        }
        val total = totalRamBytes
        if (file.sizeBytes > total * ResourcePolicy.SINGLE_MODEL_MAX_FRACTION) {
            throw ModelLoadException(
                "${file.name} (${formatBytes(file.sizeBytes)}) is too large for this device " +
                    "(${formatBytes(total)} RAM). Use a smaller or more quantized model."
            )
        }
        val nCtx = effectiveContext(requestedCtx)
        status = Status.Loading(file.name)
        try {
            val need = withContext(Dispatchers.IO) { estimateMemory(file, nCtx).totalBytes }
            val budget = ResourcePolicy.safeBudgetBytes(total)
            // evict models that are not needed, oldest first, until the new one fits next to the rest
            for (e in loaded.values.toList()) {
                val resident = withContext(Dispatchers.IO) {
                    loaded.values.sumOf { estimateMemory(it.file, it.nCtx).totalBytes }
                }
                if (loaded.isEmpty() || resident + need <= budget) break
                if (e.file.name !in keep) unloadLocked(e.file.name)
            }
            if (loaded.isNotEmpty()) {
                val resident = withContext(Dispatchers.IO) {
                    loaded.values.sumOf { estimateMemory(it.file, it.nCtx).totalBytes }
                }
                if (resident + need > budget) {
                    throw ModelLoadException(
                        "Not enough memory to keep ${loaded.keys.joinToString()} and ${file.name} loaded together " +
                            "(estimated ${formatBytes(resident + need)}, safe budget ${formatBytes(budget)}). " +
                            "Use Sequential mode, a smaller model, or a smaller context."
                    )
                }
            }
            val engine = withContext(Dispatchers.Default) {
                val h = NativeLlama.load(File(dir, file.name).absolutePath, nCtx, threads)
                LoadedEngine(file, h, nCtx, NativeLlama.describe(h))
            }
            loaded = LinkedHashMap(loaded).also { it[file.name] = engine }
            status = Status.Idle
            engine
        } catch (e: CancellationException) {
            status = Status.Idle
            throw e
        } catch (e: ModelLoadException) {
            status = Status.Failed(e.message ?: "Load refused")
            throw e
        } catch (t: Throwable) {
            val msg = t.message ?: t.javaClass.simpleName
            status = Status.Failed(msg)
            throw ModelLoadException(msg)
        }
    }

    private suspend fun unloadLocked(name: String) {
        val e = loaded[name] ?: return
        loaded = LinkedHashMap(loaded).also { it.remove(name) }
        // waits for a running generation on this engine to finish (native lock)
        withContext(Dispatchers.Default) { NativeLlama.unload(e.handle) }
    }

    suspend fun unloadModel(name: String) {
        engineMutex.withLock { unloadLocked(name) }
    }

    suspend fun unloadExcept(keep: Set<String>) {
        engineMutex.withLock {
            for (n in loaded.keys.toList()) if (n !in keep) unloadLocked(n)
        }
    }

    /** UI action: load a model and keep it (other loaded models stay if they fit). */
    fun load(file: ModelFile, requestedCtx: Int) {
        if (busy) return
        scope.launch {
            try {
                ensureLoaded(file, requestedCtx, keep = loaded.keys + file.name)
            } catch (_: ModelLoadException) {
                // status already shows the reason
            }
        }
    }

    fun unload(name: String) {
        if (busy) return
        scope.launch { unloadModel(name) }
    }

    fun delete(file: ModelFile) {
        if (status is Status.Importing || status is Status.Loading) return
        scope.launch(Dispatchers.IO) {
            unloadModel(file.name)
            File(dir, file.name).delete()
            synchronized(metaCache) { metaCache.clear() }
            files = scan()
        }
    }
}

fun formatBytes(b: Long): String = when {
    b >= 1L shl 30 -> "%.2f GB".format(b / (1024.0 * 1024.0 * 1024.0))
    b >= 1L shl 20 -> "%.1f MB".format(b / (1024.0 * 1024.0))
    else -> "$b B"
}
