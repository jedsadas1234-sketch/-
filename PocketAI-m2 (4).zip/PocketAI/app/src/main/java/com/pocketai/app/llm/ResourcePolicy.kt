package com.pocketai.app.llm

/** Deterministic memory/thread rules shared by loading, planning and the compatibility check. */
object ResourcePolicy {
    /** A single model file larger than this share of total RAM is refused outright. */
    const val SINGLE_MODEL_MAX_FRACTION = 0.75

    /** Estimated RAM above this share of total RAM is treated as high risk. */
    const val HIGH_RISK_FRACTION = 0.85

    private const val RESERVED_BYTES = 700L * 1024 * 1024

    /** How much estimated model memory may be resident together (several models at once). */
    fun safeBudgetBytes(totalRam: Long): Long = ((totalRam * 0.65).toLong() - RESERVED_BYTES).coerceAtLeast(256L * 1024 * 1024)

    fun defaultThreads(cores: Int): Int = maxOf(2, cores / 2)

    /** Threads per model when [parallel] models run at the same time. */
    fun parallelThreads(cores: Int, parallel: Int): Int = maxOf(2, (cores / 2) / maxOf(1, parallel))
}
