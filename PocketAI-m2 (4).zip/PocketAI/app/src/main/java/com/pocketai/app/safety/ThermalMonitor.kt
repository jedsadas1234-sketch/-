package com.pocketai.app.safety

import android.content.Context
import android.os.Build
import android.os.PowerManager
import androidx.annotation.RequiresApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first

/**
 * App-level thermal state derived from Android's thermal status (API 29+).
 * UNKNOWN means the device or Android version does not report a thermal status.
 */
enum class ThermalLevel { UNKNOWN, NORMAL, ELEVATED, CRITICAL, EMERGENCY }

/**
 * Watches the platform thermal status. Policy (enforced by ExecutionManager, not optional):
 * ELEVATED shows a warning, CRITICAL pauses new model loads and new work, EMERGENCY stops inference.
 * There is no fixed temperature threshold: the thresholds are the device maker's own.
 */
class ThermalMonitor(private val context: Context) {
    private val _level = MutableStateFlow(ThermalLevel.UNKNOWN)
    val level: StateFlow<ThermalLevel> = _level.asStateFlow()

    private val _raw = MutableStateFlow(-1)
    val rawStatus: StateFlow<Int> = _raw.asStateFlow()

    val supported: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q

    private var listener: Any? = null

    init {
        if (supported) register()
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun register() {
        try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            apply(pm.currentThermalStatus)
            val l = PowerManager.OnThermalStatusChangedListener { status -> apply(status) }
            pm.addThermalStatusListener(context.mainExecutor, l)
            listener = l
        } catch (_: Exception) {
            // device does not expose thermal status: stays UNKNOWN
        }
    }

    private fun apply(status: Int) {
        _raw.value = status
        _level.value = map(status)
    }

    fun close() {
        if (supported) unregister()
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun unregister() {
        try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            (listener as? PowerManager.OnThermalStatusChangedListener)?.let { pm.removeThermalStatusListener(it) }
        } catch (_: Exception) {
        }
    }

    /** Waits until the device has cooled to ELEVATED or better and stayed there for a short hold. */
    suspend fun awaitRecovered() {
        level.first { it <= ThermalLevel.ELEVATED }
        delay(RECOVERY_HOLD_MS)
        level.first { it <= ThermalLevel.ELEVATED }
    }

    fun describe(): String {
        if (!supported) return "not reported (needs Android 10 or newer)"
        val raw = _raw.value
        return if (raw < 0) "not reported by this device" else rawName(raw)
    }

    companion object {
        private const val RECOVERY_HOLD_MS = 8_000L

        fun map(status: Int): ThermalLevel = when {
            status < 0 -> ThermalLevel.UNKNOWN
            status <= 1 -> ThermalLevel.NORMAL // NONE, LIGHT: ordinary warmth, no warning
            status == 2 -> ThermalLevel.ELEVATED // MODERATE
            status == 3 -> ThermalLevel.CRITICAL // SEVERE
            else -> ThermalLevel.EMERGENCY // CRITICAL, EMERGENCY, SHUTDOWN
        }

        fun rawName(status: Int): String = when (status) {
            0 -> "NONE"
            1 -> "LIGHT"
            2 -> "MODERATE"
            3 -> "SEVERE"
            4 -> "CRITICAL"
            5 -> "EMERGENCY"
            6 -> "SHUTDOWN"
            else -> "status $status"
        }
    }
}
