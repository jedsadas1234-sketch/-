package com.pocketai.app.team

import com.pocketai.app.data.CollabMode

/** Prompt texts for team steps. English instructions; models are told to answer in the user's language. */
object Prompts {
    private const val LANG = "Reply in the same language as the user's request."

    fun modeText(mode: CollabMode): String = when (mode) {
        CollabMode.SINGLE -> "single model"
        CollabMode.SEQUENTIAL -> "models improve the answer one after another, then Main writes the final answer"
        CollabMode.INTELLIGENT -> "Main drafts, teammates review in a limited number of rounds, Main finalizes"
        CollabMode.SUPREME -> "several models answer independently, then one synthesizer combines them"
    }

    fun roleInstruction(role: ModelRole): String = when (role) {
        ModelRole.MAIN -> "You are the Main model: you coordinate the team and own the answer the user finally sees."
        ModelRole.REVIEWER -> "You are the Reviewer: look for errors, gaps, unsupported claims and risks."
        ModelRole.RESEARCHER -> "You are the Researcher: focus on facts, context and what needs checking. You cannot browse unless search results are provided."
        ModelRole.PROGRAMMER -> "You are the Programmer: focus on correct, practical code and technical detail."
        ModelRole.ANALYST -> "You are the Analyst: break the problem into parts and check the logic and any numbers."
        ModelRole.SYNTHESIZER -> "You are the Synthesizer: combine several answers into one and weigh the evidence instead of counting votes."
    }

    /** System text that tells a model who is on the team, who is primary and what its job is. */
    fun teamBriefing(team: TeamConfig, mode: CollabMode, profile: TeamProfile?, role: ModelRole): String {
        val sb = StringBuilder()
        sb.append("You are one of several local language models cooperating inside the Pocket AI app on one phone. ")
        sb.append("Collaboration mode: ${modeText(mode)}.\n")
        team.main?.let { sb.append("Primary (Main) model: ${displayName(it.file)}.\n") }
        sb.append("Team:\n")
        team.enabled.forEach { s ->
            sb.append("- ${displayName(s.file)} (${s.role.label})")
            val p = profile?.profiles?.firstOrNull { it.file == s.file && it.ok }
            if (p != null && p.strengths.isNotBlank()) sb.append(": ${p.strengths.take(100)}")
            sb.append('\n')
        }
        sb.append(roleInstruction(role)).append(' ')
        sb.append("Roles are responsibilities, not guarantees of ability. Be honest about uncertainty and never invent facts or sources. ")
        sb.append(LANG)
        return sb.toString()
    }

    fun request(question: String, searchBlock: String?): String =
        if (searchBlock == null) question else "$searchBlock\nUser request:\n$question"

    fun sequentialSupport(question: String, prevName: String, prev: String, role: ModelRole): String =
        "Original request:\n$question\n\nPrevious response (from $prevName):\n$prev\n\n" +
            "Your task as ${role.label}: review the previous response. Fix errors, fill gaps, verify what you can check " +
            "from the request or the provided search results, and add anything important that is missing. " +
            "Write the improved answer itself, not a critique addressed to its author. " +
            "If the previous response is already correct, keep it and say briefly what you verified."

    fun sequentialFinal(question: String, initial: String, contributions: List<Pair<String, String>>): String =
        buildString {
            append("Original request:\n$question\n\nYour initial response:\n$initial\n\nContributions from teammates:\n")
            contributions.forEach { (who, text) -> append("[$who]\n$text\n\n") }
            append("Write the final answer for the user. Keep what is correct, fix errors your teammates found, ")
            append("and state remaining uncertainty briefly. Do not describe the internal process unless it matters to the user.")
        }

    fun review(question: String, draft: String, earlier: List<Pair<String, String>>): String =
        buildString {
            append("Original request:\n$question\n\nCurrent draft:\n$draft\n\n")
            if (earlier.isNotEmpty()) {
                append("Reviews already given this round:\n")
                earlier.forEach { (who, text) -> append("[$who]\n$text\n\n") }
            }
            append("Review the draft critically: factual errors, missing steps, unsupported claims, risky advice. ")
            append("If you find no major issues, begin your reply with exactly: NO MAJOR ISSUES\n")
            append("Otherwise list concrete issues and fixes. For each point where you disagree with the draft on substance, ")
            append("add a separate line starting with \"DISAGREE:\" and a one-sentence summary. Keep it under 200 words.")
        }

    fun revise(question: String, draft: String, reviews: List<Pair<String, String>>): String =
        buildString {
            append("Original request:\n$question\n\nYour current draft:\n$draft\n\nReviews:\n")
            reviews.forEach { (who, text) -> append("[$who]\n$text\n\n") }
            append("Write the improved full draft. Accept review points that are right, reject ones that are wrong, ")
            append("and keep anything the reviewers did not challenge.")
        }

    fun intelligentFinal(
        question: String,
        draft: String,
        pending: List<Pair<String, String>>,
        disagreements: List<String>,
    ): String = buildString {
        append("Original request:\n$question\n\nDraft:\n$draft\n\n")
        if (pending.isNotEmpty()) {
            append("Latest reviews (not yet applied):\n")
            pending.forEach { (who, text) -> append("[$who]\n$text\n\n") }
        }
        append("Write the final answer for the user.")
        if (disagreements.isNotEmpty()) {
            append(" Reviewers disagreed on these points, so do not pretend there was consensus; say so briefly where it matters:\n")
            disagreements.forEach { append("- $it\n") }
        }
    }

    fun synthesis(question: String, responses: List<Pair<String, String>>): String =
        buildString {
            append("Original request:\n$question\n\nIndependent responses:\n")
            responses.forEachIndexed { i, (who, text) -> append("[Response ${i + 1}: $who]\n$text\n\n") }
            append("Evaluate the evidence and reasoning in each response; do not just count votes. ")
            append("Identify agreement and meaningful disagreement, resolve what you can by careful reasoning, ")
            append("and write one final answer. If disagreements remain unresolved, state them briefly.")
        }

    // ---- model meeting ----

    fun meetingIntro(selfName: String, team: TeamConfig): String =
        buildString {
            append("You are '$selfName', a local language model running on a phone inside the Pocket AI app. ")
            append("You are meeting your teammates:\n")
            team.enabled.forEach { append("- ${displayName(it.file)} (${it.role.label})\n") }
            append("\nIntroduce yourself to them in under 120 words. Be honest about uncertainty and do not claim abilities you cannot show. ")
            append("Reply with exactly these four lines and nothing else:\n")
            append("STRENGTHS: ...\nLIMITATIONS: ...\nSUGGESTED ROLE: (one of Main, Reviewer, Researcher, Programmer, Analyst, Synthesizer)\nWORKING STYLE: ...\n")
            append(LANG)
        }

    fun meetingResponse(selfName: String, target: String, intros: List<Pair<String, String>>): String =
        buildString {
            append("You are '$selfName'. Your teammates introduced themselves:\n\n")
            intros.forEach { (who, text) -> append("[$who]\n$text\n\n") }
            append("Respond to $target's introduction in under 80 words: say which kind of task you would hand to $target ")
            append("and name one concern or one thing you would like to know. Address $target by name.")
        }

    fun meetingSummary(team: TeamConfig, intros: List<Pair<String, String>>, turns: List<MeetingTurn>): String =
        buildString {
            append("You are the Main model leading a team meeting. Introductions:\n\n")
            intros.forEach { (who, text) -> append("[$who]\n$text\n\n") }
            if (turns.isNotEmpty()) {
                append("Discussion:\n")
                turns.forEach { append("[${it.speaker} to ${it.respondingTo ?: "all"}] ${it.text}\n") }
                append('\n')
            }
            append("Write a team summary in under 150 words: how the team will work together and what each model is best used for. ")
            append("Then, for every model on the team, add exactly one line in this form (use the exact model names):\n")
            team.enabled.forEach { append("ASSIGN: ${displayName(it.file)} = ROLE\n") }
            append("where ROLE is one of Main, Reviewer, Researcher, Programmer, Analyst, Synthesizer. ")
            append("These are suggestions; the user decides.")
        }
}
