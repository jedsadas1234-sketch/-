package com.pocketai.app.llm

import com.pocketai.app.ai.AIProvider
import com.pocketai.app.ai.GenSettings
import com.pocketai.app.data.ChatMessage
import kotlinx.coroutines.flow.Flow
import java.util.concurrent.atomic.AtomicBoolean

/** llama.cpp provider bound to one resident engine. */
class LocalAIProvider(private val engine: ModelManager.LoadedEngine) : AIProvider {
    override val name: String = engine.file.name

    private val stopRequested = AtomicBoolean(false)

    override fun stopGeneration() {
        stopRequested.set(true)
    }

    override fun generate(messages: List<ChatMessage>, systemPrompt: String, gen: GenSettings): Flow<String> {
        stopRequested.set(false)
        return LocalGenerator.generate(engine, messages, systemPrompt, gen, stopRequested)
    }
}
