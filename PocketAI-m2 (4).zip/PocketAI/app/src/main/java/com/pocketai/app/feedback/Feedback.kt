package com.pocketai.app.feedback

import android.app.Application
import android.content.Context
import android.os.Build
import com.pocketai.app.BuildConfig
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** In-memory ring of recent app errors, sanitized. Never contains chat text. */
object AppLog {
    private val ring = ArrayDeque<String>()

    @Synchronized
    fun error(tag: String, message: String) {
        ring.addLast("${System.currentTimeMillis() / 1000} $tag: ${Sanitizer.clean(message).take(300)}")
        while (ring.size > 20) ring.removeFirst()
    }

    @Synchronized
    fun recent(): List<String> = ring.toList()
}

/** Removes secrets and personal paths from text before it is shown or sent. */
object Sanitizer {
    private val secret = Regex("(?i)(api[_-]?key|token|secret|password|authorization|bearer)\\s*[=:]\\s*\\S+")
    private val longToken = Regex("[A-Za-z0-9_\\-]{32,}")
    private val url = Regex("https?://[^\\s)\\]>\"']+")
    private val appPath = Regex("/data/(user/\\d+|data)/[^\\s:)]+")

    fun clean(s: String): String =
        s.replace(secret, "$1=<hidden>")
            .replace(url) { m -> hostOnly(m.value) }
            .replace(appPath, "<app-dir>")
            .replace(longToken, "<hidden>")

    private fun hostOnly(u: String): String = try {
        "<url:" + (java.net.URI(u).host ?: "link") + ">"
    } catch (_: Exception) {
        "<url>"
    }
}

/** Saves the last crash stack trace (sanitized) so the user can choose to attach it to a report. */
object CrashReporter {
    fun install(app: Application) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                val trace = android.util.Log.getStackTraceString(error)
                File(app.filesDir, "last_crash.txt").writeText(Sanitizer.clean(trace).take(6000))
            } catch (_: Exception) {
            }
            previous?.uncaughtException(thread, error)
        }
    }

    fun lastCrash(context: Context): String? {
        val f = File(context.filesDir, "last_crash.txt")
        return if (f.exists()) f.readText().takeIf { it.isNotBlank() } else null
    }

    fun clear(context: Context) {
        File(context.filesDir, "last_crash.txt").delete()
    }
}

enum class FeedbackCategory(val label: String) {
    BUG("Bug"),
    CRASH("Crash"),
    MODEL("Model problem"),
    PERFORMANCE("Performance or heat"),
    FEATURE("Feature request"),
    OTHER("Other"),
}

sealed interface SendResult {
    data object Success : SendResult
    data class Failure(val message: String) : SendResult
    data class RateLimited(val seconds: Int) : SendResult
}

/**
 * Sends a report to a Discord webhook. The report is what the user previewed and agreed to;
 * chat text and model files are never added. The webhook address is compiled into the app
 * (see README), so it can be read out of the APK by anyone who has it.
 */
object FeedbackSender {
    private const val PREFIX_A = "https://discord.com/api/webhooks/"
    private const val PREFIX_B = "https://discordapp.com/api/webhooks/"
    private const val COOLDOWN_MS = 60_000L

    fun configured(): Boolean = BuildConfig.DISCORD_WEBHOOK.startsWith(PREFIX_A) || BuildConfig.DISCORD_WEBHOOK.startsWith(PREFIX_B)

    fun cooldownLeftSeconds(context: Context): Int {
        val last = context.getSharedPreferences("pocketai_feedback", Context.MODE_PRIVATE).getLong("last_sent", 0L)
        val left = COOLDOWN_MS - (System.currentTimeMillis() - last)
        return if (left > 0) ((left + 999) / 1000).toInt() else 0
    }

    /** Blocking. Call on an IO dispatcher. */
    fun send(context: Context, category: FeedbackCategory, message: String, diagnostics: String?, crash: String?): SendResult {
        if (!configured()) return SendResult.Failure("Reporting is not set up in this build.")
        val wait = cooldownLeftSeconds(context)
        if (wait > 0) return SendResult.RateLimited(wait)

        val fields = JSONArray()
        if (!diagnostics.isNullOrBlank()) fields.put(field("Diagnostics", "```\n${diagnostics.take(950)}\n```"))
        if (!crash.isNullOrBlank()) fields.put(field("Last crash (sanitized)", "```\n${crash.take(950)}\n```"))
        val embed = JSONObject()
            .put("title", "[${category.label}] Pocket AI ${BuildConfig.VERSION_NAME}")
            .put("description", message.take(1500).ifBlank { "(no description)" })
            .put("color", 0x6C5CE7)
            .put("fields", fields)
        val payload = JSONObject()
            .put("username", "Pocket AI feedback")
            .put("allowed_mentions", JSONObject().put("parse", JSONArray()))
            .put("embeds", JSONArray().put(embed))
            .toString()

        return try {
            val conn = URL(BuildConfig.DISCORD_WEBHOOK).openConnection() as HttpURLConnection
            try {
                conn.connectTimeout = 15_000
                conn.readTimeout = 15_000
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                when (val code = conn.responseCode) {
                    in 200..299 -> {
                        context.getSharedPreferences("pocketai_feedback", Context.MODE_PRIVATE)
                            .edit().putLong("last_sent", System.currentTimeMillis()).apply()
                        SendResult.Success
                    }
                    429 -> {
                        val body = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                        val retry = try {
                            Math.ceil(JSONObject(body).optDouble("retry_after", 30.0)).toInt()
                        } catch (_: Exception) {
                            30
                        }
                        SendResult.RateLimited(retry.coerceAtLeast(1))
                    }
                    404 -> SendResult.Failure("The report channel no longer exists (HTTP 404).")
                    else -> SendResult.Failure("The report server answered HTTP $code.")
                }
            } finally {
                conn.disconnect()
            }
        } catch (e: java.io.IOException) {
            SendResult.Failure("Could not reach the report server: ${e.message ?: "network error"}")
        }
    }

    private fun field(name: String, value: String) = JSONObject().put("name", name).put("value", value).put("inline", false)

    fun appVersion(): String = BuildConfig.VERSION_NAME + " (" + BuildConfig.VERSION_CODE + ")"

    fun deviceLine(): String = "${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
}
