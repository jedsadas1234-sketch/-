package com.pocketai.app.team

/** Responsibilities a model can be given. A role is a job description, not a guarantee of ability. */
enum class ModelRole(val label: String) {
    MAIN("Main"),
    REVIEWER("Reviewer"),
    RESEARCHER("Researcher"),
    PROGRAMMER("Programmer"),
    ANALYST("Analyst"),
    SYNTHESIZER("Synthesizer"),
}

/** One model in the team. The first slot is always the Main model. */
data class ModelSlot(val file: String, val role: ModelRole, val enabled: Boolean = true)

data class TeamConfig(
    val slots: List<ModelSlot> = emptyList(),
    /** Model file used by Supreme mode to combine answers. Null means the Main model. */
    val synthesizerFile: String? = null,
) {
    val main: ModelSlot? get() = slots.firstOrNull()

    /** Slots that take part in runs. Main always counts. */
    val enabled: List<ModelSlot> get() = slots.filterIndexed { i, s -> i == 0 || s.enabled }
    val supporting: List<ModelSlot> get() = enabled.drop(1)

    /** Changes whenever models, roles, order or the synthesizer change. Used to flag an outdated profile. */
    fun fingerprint(): String =
        slots.joinToString("|") { "${it.file}:${it.role.name}:${it.enabled}" } + "#" + (synthesizerFile ?: "")
}

/** Facts read from the GGUF file itself. */
data class VerifiedInfo(
    val sizeBytes: Long,
    val architecture: String?,
    val ggufName: String?,
    val quantization: String?,
    val trainedContext: Long?,
)

/** What one model said about itself in the meeting, next to what the file verifiably says. */
data class ModelProfile(
    val file: String,
    val verified: VerifiedInfo,
    val raw: String,
    val strengths: String,
    val limitations: String,
    val suggestedRole: String,
    val workingStyle: String,
    val ok: Boolean,
    val error: String?,
)

data class MeetingTurn(
    val round: Int,
    val speaker: String,
    /** Which model this turn answers, if any. */
    val respondingTo: String?,
    val text: String,
    val ok: Boolean,
    val error: String?,
)

data class RoleSuggestion(val file: String, val role: ModelRole)

data class TeamProfile(
    val createdAt: Long,
    val fingerprint: String,
    val profiles: List<ModelProfile>,
    val turns: List<MeetingTurn>,
    val summary: String,
    val suggestions: List<RoleSuggestion>,
    val complete: Boolean,
)

fun displayName(file: String): String = file.removeSuffix(".gguf").removeSuffix(".GGUF")
