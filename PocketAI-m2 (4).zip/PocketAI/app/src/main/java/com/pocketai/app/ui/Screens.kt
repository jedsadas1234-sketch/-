package com.pocketai.app.ui

enum class Screen { CHAT, SETTINGS, MODELS, TEAM, MEETING, SAFETY, FEEDBACK }
