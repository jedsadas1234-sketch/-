package com.pocketai.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pocketai.app.data.CollabMode
import com.pocketai.app.data.MessageMeta
import com.pocketai.app.data.SearchMode
import com.pocketai.app.data.Source
import com.pocketai.app.data.StepStatus
import com.pocketai.app.data.TimelineStep
import com.pocketai.app.safety.ThermalLevel
import com.pocketai.app.search.domainOf

/** Single-choice chips in one scrollable row. */
@Composable
fun <T> ChipRow(options: List<T>, selected: T, label: (T) -> String, enabled: Boolean = true, onSelect: (T) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { o ->
            FilterChip(selected = o == selected, onClick = { onSelect(o) }, enabled = enabled, label = { Text(label(o)) })
        }
    }
}

@Composable
fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

fun SearchMode.label() = name.lowercase().replaceFirstChar { it.uppercase() }
fun CollabMode.label() = name.lowercase().replaceFirstChar { it.uppercase() }

@Composable
fun ThermalBanner(vm: ChatViewModel, onOpenSafety: () -> Unit) {
    val level by vm.thermal.level.collectAsState()
    if (level < ThermalLevel.ELEVATED) return
    val critical = level >= ThermalLevel.CRITICAL
    Box(
        Modifier
            .fillMaxWidth()
            .background(if (critical) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.tertiaryContainer)
            .clickable(onClick = onOpenSafety)
            .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Text(
            when (level) {
                ThermalLevel.ELEVATED -> "The phone is getting warm (${vm.thermal.describe()}). Long team runs may be paused. Tap for details."
                ThermalLevel.CRITICAL -> "The phone is hot (${vm.thermal.describe()}). New model work is paused until it cools down."
                else -> "The phone is very hot (${vm.thermal.describe()}). Running models are being stopped."
            },
            style = MaterialTheme.typography.bodySmall,
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModeBar(vm: ChatViewModel, onOpen: (Screen) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val s = vm.settings
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        AssistChip(onClick = { open = true }, label = { Text("Search: ${s.searchMode.label()}") })
        AssistChip(onClick = { open = true }, label = { Text("Team: ${s.collabMode.label()}") })
    }
    if (open) {
        ModalBottomSheet(onDismissRequest = { open = false }) {
            Column(
                Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text("Web search", style = MaterialTheme.typography.titleMedium)
                ChipRow(SearchMode.values().toList(), s.searchMode, { it.label() }, enabled = !vm.generating) { vm.setSearchMode(it) }
                Text(
                    when (s.searchMode) {
                        SearchMode.OFFLINE -> "Local model only. Nothing leaves the phone."
                        SearchMode.SEARCH -> "Searches the web for every message and gives the results to the model. Your question is sent to the search provider chosen in Settings. If the search fails, the run stops instead of guessing."
                        SearchMode.AUTO -> "Searches only when the question looks time-sensitive (news, prices, today, latest...). Each reply says what Auto decided."
                    },
                    style = MaterialTheme.typography.bodySmall,
                )
                Text("Collaboration", style = MaterialTheme.typography.titleMedium)
                ChipRow(CollabMode.values().toList(), s.collabMode, { it.label() }, enabled = !vm.generating) { vm.setCollabMode(it) }
                Text(
                    when (s.collabMode) {
                        CollabMode.SINGLE -> "Only the Main model answers."
                        CollabMode.SEQUENTIAL -> "Main answers, each teammate improves it in turn, Main writes the final answer."
                        CollabMode.INTELLIGENT -> "Main drafts, teammates review in limited rounds, disagreements are reported, Main finalizes."
                        CollabMode.SUPREME -> "Up to four models answer independently, then one synthesizer combines them. Runs at the same time only if memory allows."
                    },
                    style = MaterialTheme.typography.bodySmall,
                )
                if (s.collabMode != CollabMode.SINGLE && vm.team.enabled.size < 2) {
                    Text("This mode needs at least two models in Team.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { open = false; onOpen(Screen.TEAM) }) { Text("Open Team") }
                    TextButton(onClick = { open = false; vm.refreshCompat(); onOpen(Screen.SAFETY) }) { Text("Check device") }
                }
            }
        }
    }
}

private fun stepIcon(s: StepStatus) = when (s) {
    StepStatus.COMPLETED -> "✓"
    StepStatus.FAILED -> "✗"
    StepStatus.CANCELLED -> "■"
    StepStatus.SKIPPED -> "-"
    else -> "…"
}

private fun stepText(s: StepStatus) = when (s) {
    StepStatus.WAITING -> "waiting"
    StepStatus.LOADING -> "loading model"
    StepStatus.THINKING -> "thinking"
    StepStatus.REVIEWING -> "reviewing"
    StepStatus.SYNTHESIZING -> "synthesizing"
    StepStatus.COMPLETED -> "done"
    StepStatus.FAILED -> "failed"
    StepStatus.CANCELLED -> "cancelled"
    StepStatus.SKIPPED -> "skipped"
}

/** Model label, notices, sources (retrieved separately from the model) and the inspectable timeline. */
@Composable
fun MessageExtras(meta: MessageMeta, streaming: Boolean) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    Column(Modifier.widthIn(max = 320.dp).padding(top = 4.dp, start = 4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        val label = listOfNotNull(meta.modelLabel, meta.mode?.let { "$it mode" }).joinToString(" • ")
        if (label.isNotEmpty()) Text(label, style = MaterialTheme.typography.labelSmall, color = muted)
        meta.notices.forEach { Text("Note: $it", style = MaterialTheme.typography.bodySmall, color = muted) }
        if (meta.disagreements.isNotEmpty()) {
            Text("Disagreements between models", style = MaterialTheme.typography.labelMedium)
            meta.disagreements.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
        }
        if (meta.sources.isNotEmpty()) SourceList(meta.sources)
        if (meta.timeline.isNotEmpty()) Timeline(meta.timeline, streaming)
    }
}

@Composable
private fun SourceList(sources: List<Source>) {
    val uri = LocalUriHandler.current
    Text("Sources (found by web search, not written by the model)", style = MaterialTheme.typography.labelMedium)
    sources.forEachIndexed { i, s ->
        Text(
            "[${i + 1}] ${s.title} — ${domainOf(s.url)}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.clickable {
                try {
                    uri.openUri(s.url)
                } catch (_: Exception) {
                }
            },
        )
    }
}

@Composable
private fun Timeline(steps: List<TimelineStep>, streaming: Boolean) {
    var open by remember { mutableStateOf(streaming) }
    Text(
        (if (open) "Hide" else "Show") + " details (${steps.size} steps)",
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.clickable { open = !open },
    )
    if (!open) return
    steps.forEach { st ->
        var expanded by remember(st.id) { mutableStateOf(false) }
        Column(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceContainerHigh, RoundedCornerShape(12.dp))
                .clickable { expanded = !expanded }
                .padding(10.dp),
        ) {
            Text("${stepIcon(st.status)} ${st.title}", style = MaterialTheme.typography.labelLarge)
            Text("${st.model} • ${st.roleLabel} • ${stepText(st.status)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            st.error?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
            if (expanded) {
                SelectionContainer {
                    Column {
                        if (st.input.isNotBlank()) {
                            Text("Input", style = MaterialTheme.typography.labelSmall)
                            Text(st.input.take(1500), fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                        }
                        if (st.output.isNotBlank()) {
                            Text("Output", style = MaterialTheme.typography.labelSmall)
                            Text(st.output, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                        }
                    }
                }
            } else if (st.output.isNotBlank() || st.input.isNotBlank()) {
                Text("Tap to inspect input and output", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun NoticeBody() {
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Pocket AI runs language models on your phone. This uses a lot of CPU, RAM and battery and can make the phone warm. The app watches Android's thermal status and pauses or stops work when the phone gets too hot. This protection cannot be turned off.")
        Text("Chats, models and settings stay on this device. The internet is used only for web search (if you turn it on; your question is then sent to the search provider you chose) and for feedback reports that you choose to send.")
        Text("Model answers can be wrong. Do not rely on them for medical, legal, financial or safety decisions.")
        Text("Support: how the developer will help with problems on your device is still being decided. Nothing in this app is a promise of repair or compensation, and nothing here limits your legal rights.")
    }
}

@Composable
fun NoticeDialog(onAccept: () -> Unit) {
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Before you start") },
        text = { NoticeBody() },
        confirmButton = { TextButton(onClick = onAccept) { Text("I understand") } },
    )
}
