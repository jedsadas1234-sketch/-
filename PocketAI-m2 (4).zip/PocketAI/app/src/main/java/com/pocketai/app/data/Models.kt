package com.pocketai.app.data

enum class Role { USER, ASSISTANT }

enum class MsgState { DONE, STREAMING, STOPPED, ERROR }

enum class SearchMode { OFFLINE, SEARCH, AUTO }

enum class CollabMode { SINGLE, SEQUENTIAL, INTELLIGENT, SUPREME }

enum class SearchProviderType { WIKIPEDIA, BRAVE, SEARXNG }

data class Source(val title: String, val url: String, val snippet: String)

enum class StepStatus { WAITING, LOADING, THINKING, REVIEWING, SYNTHESIZING, COMPLETED, FAILED, CANCELLED, SKIPPED }

/** One visible step of a run: a model call or a web search. */
data class TimelineStep(
    val id: Int,
    val model: String,
    val roleLabel: String,
    val title: String,
    val status: StepStatus,
    /** What this step was given (clipped). */
    val input: String = "",
    val output: String = "",
    val error: String? = null,
)

/** Extra, inspectable information attached to an assistant reply. */
data class MessageMeta(
    val modelLabel: String? = null,
    val mode: String? = null,
    val sources: List<Source> = emptyList(),
    val notices: List<String> = emptyList(),
    val timeline: List<TimelineStep> = emptyList(),
    val disagreements: List<String> = emptyList(),
    /** Live status line, not persisted. */
    val phase: String? = null,
)

data class ChatMessage(
    val id: Long,
    val role: Role,
    val text: String,
    val state: MsgState = MsgState.DONE,
    val error: String? = null,
    val meta: MessageMeta? = null,
)

data class Conversation(
    val id: Long,
    val title: String,
    val messages: List<ChatMessage>,
)

enum class ThemeMode { SYSTEM, LIGHT, DARK }

const val DEFAULT_SYSTEM_PROMPT =
    "You are Pocket AI, a friendly and concise companion. Answer clearly and honestly."

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val systemPrompt: String = DEFAULT_SYSTEM_PROMPT,
    val reduceMotion: Boolean = false,
    /** 0 = automatic, chosen from device RAM at load time. */
    val contextLength: Int = 0,
    val maxTokens: Int = 512,
    val temperature: Float = 0.7f,
    val topP: Float = 0.9f,
    /** 0 = disabled. */
    val topK: Int = 40,
    val searchMode: SearchMode = SearchMode.OFFLINE,
    val collabMode: CollabMode = CollabMode.SINGLE,
    val searchProvider: SearchProviderType = SearchProviderType.WIKIPEDIA,
    /** Stored only in app-private storage on this device. */
    val braveKey: String = "",
    val searxUrl: String = "",
    val reviewRounds: Int = 2,
    val meetingRounds: Int = 1,
    val stepTimeoutSec: Int = 300,
    val allowSequentialFallback: Boolean = true,
    val keepMainLoaded: Boolean = true,
    val noticeAccepted: Boolean = false,
)
