package com.pocketai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pocketai.app.ui.ChatScreen
import com.pocketai.app.ui.ChatViewModel
import com.pocketai.app.ui.ModelsScreen
import com.pocketai.app.ui.SettingsScreen
import com.pocketai.app.ui.theme.PocketTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val vm: ChatViewModel = viewModel()
            PocketTheme(vm.settings.themeMode) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    var screen by rememberSaveable { mutableStateOf(Screen.CHAT) }
                    if (!vm.settings.noticeAccepted) NoticeDialog(onAccept = vm::acceptNotice)
                    BackHandler(enabled = screen != Screen.CHAT) { screen = Screen.CHAT }
                    val reduce = vm.settings.reduceMotion
                    AnimatedContent(
                        targetState = screen,
                        transitionSpec = {
                            if (reduce) {
                                EnterTransition.None togetherWith ExitTransition.None
                            } else if (targetState != Screen.CHAT) {
                                slideInHorizontally(tween(300)) { it } togetherWith
                                    slideOutHorizontally(tween(300)) { -it / 3 }
                            } else {
                                slideInHorizontally(tween(300)) { -it / 3 } togetherWith
                                    slideOutHorizontally(tween(300)) { it }
                            }
                        },
                        label = "screen",
                    ) { current ->
                        when (current) {
                            Screen.CHAT -> ChatScreen(vm, onOpen = { screen = it })
                            Screen.SETTINGS -> SettingsScreen(vm, onBack = { screen = Screen.CHAT }, onOpen = { screen = it })
                            Screen.MODELS -> ModelsScreen(vm, onBack = { screen = Screen.CHAT })
                            Screen.TEAM -> TeamScreen(vm, onBack = { screen = Screen.CHAT }, onOpen = { screen = it })
                            Screen.MEETING -> MeetingScreen(vm, onBack = { screen = Screen.TEAM })
                            Screen.SAFETY -> SafetyScreen(vm, onBack = { screen = Screen.CHAT })
                            Screen.FEEDBACK -> FeedbackScreen(vm, onBack = { screen = Screen.SETTINGS })
                        }
                    }
                }
            }
        }
    }
}
