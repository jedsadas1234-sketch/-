package com.pocketai.app.ai

import com.pocketai.app.data.ChatMessage
import kotlinx.coroutines.flow.Flow

data class GenSettings(
    val maxTokens: Int,
    val temperature: Float,
    val topP: Float = 0.9f,
    /** 0 = top-k disabled. */
    val topK: Int = 40,
)

/**
 * Engine boundary: LocalAIProvider (llama.cpp) implements it today; another engine can implement
 * it later. Cancel the collecting coroutine, or call stopGeneration(), to stop a reply.
 */
interface AIProvider {
    val name: String

    /** Ask a running generate() to finish early. Safe to call when idle. */
    fun stopGeneration()
    fun generate(messages: List<ChatMessage>, systemPrompt: String, gen: GenSettings): Flow<String>
}
