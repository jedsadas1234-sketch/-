package com.pocketai.app.llm

import com.pocketai.app.ai.GenSettings
import com.pocketai.app.data.ChatMessage
import com.pocketai.app.data.Role
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.job
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.coroutineContext

/** Runs one reply on a specific resident engine. Several engines can run at the same time. */
object LocalGenerator {

    fun generate(
        engine: ModelManager.LoadedEngine,
        messages: List<ChatMessage>,
        systemPrompt: String,
        gen: GenSettings,
        stop: AtomicBoolean,
    ): Flow<String> = channelFlow {
        // Rough history trimming (about 3 chars per token). The native side checks exactly.
        // Non-ASCII characters (Thai, CJK, emoji) count as one token each, see estimateTokens().
        val budgetTokens = (engine.nCtx - gen.maxTokens - TEMPLATE_RESERVE_TOKENS).coerceAtLeast(256)
        val sys = systemPrompt.trim()
        var used = if (sys.isEmpty()) 0 else estimateTokens(sys) + PER_MESSAGE_TOKENS
        val kept = ArrayDeque<ChatMessage>()
        for (m in messages.filter { it.text.isNotBlank() }.asReversed()) {
            val cost = estimateTokens(m.text) + PER_MESSAGE_TOKENS
            if (kept.isNotEmpty() && used + cost > budgetTokens) break
            kept.addFirst(m)
            used += cost
        }

        val roles = ArrayList<String>()
        val contents = ArrayList<ByteArray>()
        if (sys.isNotEmpty()) {
            roles.add("system")
            contents.add(sys.toByteArray(Charsets.UTF_8))
        }
        for (m in kept) {
            roles.add(if (m.role == Role.USER) "user" else "assistant")
            contents.add(m.text.toByteArray(Charsets.UTF_8))
        }

        withContext(Dispatchers.IO) {
            val job = coroutineContext.job
            NativeLlama.generate(
                engine.handle,
                roles.toTypedArray(),
                contents.toTypedArray(),
                gen.maxTokens,
                gen.temperature,
                gen.topP,
                gen.topK,
                object : NativeLlama.TokenSink {
                    override fun onToken(bytes: ByteArray): Boolean {
                        if (bytes.isNotEmpty()) trySend(String(bytes, Charsets.UTF_8))
                        return job.isActive && !stop.get()
                    }
                },
            )
        }
    }.buffer(Channel.UNLIMITED)
}
