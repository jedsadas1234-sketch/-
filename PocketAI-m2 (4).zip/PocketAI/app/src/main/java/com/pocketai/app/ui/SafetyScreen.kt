package com.pocketai.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.pocketai.app.llm.formatBytes
import com.pocketai.app.safety.Compatibility
import com.pocketai.app.safety.RiskLevel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SafetyScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val level by vm.thermal.level.collectAsState()
    val raw by vm.thermal.rawStatus.collectAsState()
    val device = remember(level, raw, vm.models.loaded) { Compatibility.deviceInfo(context, vm.models, vm.thermal) }
    LaunchedEffect(Unit) { if (vm.compat == null) vm.refreshCompat() }
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Device and safety") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") } },
            )
        },
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SectionCard("Temperature") {
                Text("Thermal status: ${vm.thermal.describe()}  (app level: ${level.name.lowercase()})")
                Text(
                    "Warm: a warning is shown. Hot: no new model loads or steps start until it cools. Very hot: running models are stopped. " +
                        "The limits are Android's own for this phone. This protection cannot be turned off.",
                    style = MaterialTheme.typography.bodySmall, color = muted,
                )
            }
            SectionCard("This device") {
                Text(device.model)
                Text("Android API ${device.androidSdk}, ${device.abis.joinToString()}, ${device.cores} cores", style = MaterialTheme.typography.bodySmall)
                Text("RAM ${formatBytes(device.totalRam)} total, ${formatBytes(device.availRam)} free", style = MaterialTheme.typography.bodySmall)
                Text("Storage free: ${formatBytes(device.freeStorage)}", style = MaterialTheme.typography.bodySmall)
                Text(
                    "CPU features: " + if (device.cpuFeatures.isEmpty()) "not reported" else device.cpuFeatures.joinToString(),
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            SectionCard("Models in memory") {
                if (vm.models.loaded.isEmpty()) Text("None.", style = MaterialTheme.typography.bodySmall)
                vm.models.loaded.values.forEach { e ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${e.file.name} (context ${e.nCtx})", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = { vm.unloadModel(e.file.name) }) { Text("Unload") }
                    }
                }
            }
            SectionCard("Compatibility for ${vm.settings.collabMode.label()} mode") {
                Button(onClick = vm::refreshCompat, enabled = !vm.compatBusy, modifier = Modifier.fillMaxWidth()) {
                    Text(if (vm.compatBusy) "Checking..." else "Run the check")
                }
                val r = vm.compat
                if (r != null) {
                    Text(
                        when (r.level) {
                            RiskLevel.LOW -> "Risk: low"
                            RiskLevel.MEDIUM -> "Risk: medium (runs, with limits)"
                            RiskLevel.HIGH -> "Risk: high (blocked)"
                        },
                        style = MaterialTheme.typography.titleSmall,
                        color = if (r.level == RiskLevel.HIGH) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                    )
                    r.reasons.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                    if (r.recommendations.isNotEmpty()) {
                        Text("Suggested changes", style = MaterialTheme.typography.labelMedium)
                        r.recommendations.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                    }
                    r.parallelPossible?.let {
                        Text(if (it) "Supreme: models can run at the same time." else "Supreme: models will run one after another.", style = MaterialTheme.typography.bodySmall)
                    }
                    Text("Estimated peak memory: ${formatBytes(r.estimatedPeakBytes)} (safe budget ${formatBytes(r.budgetBytes)}). Estimates, not measurements.", style = MaterialTheme.typography.bodySmall, color = muted)
                    r.models.forEach { m ->
                        val e = m.estimate
                        Text(
                            "${m.file}: " + if (e == null) "missing" else "about ${formatBytes(e.totalBytes)}" + (if (e.kvBytes == null) " or more" else ""),
                            style = MaterialTheme.typography.bodySmall, color = muted,
                        )
                    }
                    Text("A high-risk result cannot be bypassed in the app.", style = MaterialTheme.typography.bodySmall, color = muted)
                }
            }
        }
    }
}
