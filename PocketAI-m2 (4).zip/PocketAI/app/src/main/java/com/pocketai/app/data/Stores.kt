package com.pocketai.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Saves conversations as JSON in app-private storage. Nothing leaves the device. */
class ConversationStore(context: Context) {
    private val file = File(context.filesDir, "conversations.json")

    @Synchronized
    fun load(): List<Conversation> {
        if (!file.exists()) return emptyList()
        return try {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Conversation(
                    id = o.getLong("id"),
                    title = o.getString("title"),
                    messages = parseMessages(o.getJSONArray("messages")),
                )
            }
        } catch (e: Exception) {
            // keep the unreadable file so history is not lost on next save
            try {
                file.copyTo(File(file.parentFile, "conversations.corrupt.json"), overwrite = true)
            } catch (_: Exception) {
            }
            emptyList()
        }
    }

    @Synchronized
    fun save(list: List<Conversation>) {
        try {
            val arr = JSONArray()
            list.forEach { c ->
                val msgs = JSONArray()
                c.messages.forEach { m ->
                    msgs.put(
                        JSONObject()
                            .put("id", m.id)
                            .put("role", m.role.name)
                            .put("text", m.text)
                            .put("state", m.state.name)
                            .put("error", m.error ?: JSONObject.NULL)
                            .put("meta", m.meta?.let { MetaJson.toJson(it) } ?: JSONObject.NULL)
                    )
                }
                arr.put(
                    JSONObject()
                        .put("id", c.id)
                        .put("title", c.title)
                        .put("messages", msgs)
                )
            }
            val tmp = File(file.parentFile, "conversations.json.tmp")
            tmp.writeText(arr.toString())
            if (!tmp.renameTo(file)) {
                file.writeText(arr.toString())
                tmp.delete()
            }
        } catch (_: Exception) {
            // persistence is best-effort; chat keeps working in memory
        }
    }

    private fun parseMessages(arr: JSONArray): List<ChatMessage> =
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val state = MsgState.valueOf(o.getString("state"))
            ChatMessage(
                id = o.getLong("id"),
                role = Role.valueOf(o.getString("role")),
                text = o.getString("text"),
                // a message still "streaming" on load means the process died mid-generation
                state = if (state == MsgState.STREAMING) MsgState.STOPPED else state,
                error = if (o.isNull("error")) null else o.getString("error"),
                meta = if (!o.has("meta") || o.isNull("meta")) null else try {
                    MetaJson.fromJson(o.getJSONObject("meta"))
                } catch (_: Exception) {
                    null
                },
            )
        }
}

/** JSON mapping for [MessageMeta] (sources, notices, timeline). */
object MetaJson {
    fun toJson(m: MessageMeta): JSONObject = JSONObject()
        .put("modelLabel", m.modelLabel ?: JSONObject.NULL)
        .put("mode", m.mode ?: JSONObject.NULL)
        .put("notices", JSONArray(m.notices))
        .put("disagreements", JSONArray(m.disagreements))
        .put(
            "sources",
            JSONArray().also { a ->
                m.sources.forEach { a.put(JSONObject().put("t", it.title).put("u", it.url).put("s", it.snippet)) }
            },
        )
        .put(
            "timeline",
            JSONArray().also { a ->
                m.timeline.forEach {
                    a.put(
                        JSONObject()
                            .put("id", it.id).put("model", it.model).put("role", it.roleLabel).put("title", it.title)
                            .put("status", it.status.name).put("in", it.input).put("out", it.output)
                            .put("err", it.error ?: JSONObject.NULL)
                    )
                }
            },
        )

    fun fromJson(o: JSONObject): MessageMeta {
        fun strings(a: JSONArray?): List<String> = if (a == null) emptyList() else (0 until a.length()).map { a.getString(it) }
        val src = o.optJSONArray("sources")
        val tl = o.optJSONArray("timeline")
        return MessageMeta(
            modelLabel = if (o.isNull("modelLabel")) null else o.getString("modelLabel"),
            mode = if (o.isNull("mode")) null else o.getString("mode"),
            notices = strings(o.optJSONArray("notices")),
            disagreements = strings(o.optJSONArray("disagreements")),
            sources = if (src == null) emptyList() else (0 until src.length()).map {
                val s = src.getJSONObject(it)
                Source(s.getString("t"), s.getString("u"), s.optString("s"))
            },
            timeline = if (tl == null) emptyList() else (0 until tl.length()).map {
                val s = tl.getJSONObject(it)
                val st = try {
                    StepStatus.valueOf(s.getString("status"))
                } catch (_: Exception) {
                    StepStatus.FAILED
                }
                TimelineStep(
                    id = s.getInt("id"), model = s.getString("model"), roleLabel = s.optString("role"),
                    title = s.getString("title"),
                    // a step still running when the app died is shown as cancelled
                    status = if (st == StepStatus.COMPLETED || st == StepStatus.FAILED || st == StepStatus.SKIPPED) st else StepStatus.CANCELLED,
                    input = s.optString("in"), output = s.optString("out"),
                    error = if (s.isNull("err")) null else s.getString("err"),
                )
            },
        )
    }
}

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("pocketai_settings", Context.MODE_PRIVATE)

    fun load(): AppSettings = AppSettings(
        themeMode = try {
            ThemeMode.valueOf(prefs.getString("theme", ThemeMode.SYSTEM.name) ?: ThemeMode.SYSTEM.name)
        } catch (_: Exception) {
            ThemeMode.SYSTEM
        },
        systemPrompt = prefs.getString("system_prompt", DEFAULT_SYSTEM_PROMPT) ?: DEFAULT_SYSTEM_PROMPT,
        reduceMotion = prefs.getBoolean("reduce_motion", false),
        contextLength = prefs.getInt("context_length", 0),
        maxTokens = prefs.getInt("max_tokens", 512),
        temperature = prefs.getFloat("temperature", 0.7f),
        topP = prefs.getFloat("top_p", 0.9f),
        topK = prefs.getInt("top_k", 40),
        searchMode = enumOr(prefs.getString("search_mode", null), SearchMode.OFFLINE),
        collabMode = enumOr(prefs.getString("collab_mode", null), CollabMode.SINGLE),
        searchProvider = enumOr(prefs.getString("search_provider", null), SearchProviderType.WIKIPEDIA),
        braveKey = prefs.getString("brave_key", "") ?: "",
        searxUrl = prefs.getString("searx_url", "") ?: "",
        reviewRounds = prefs.getInt("review_rounds", 2),
        meetingRounds = prefs.getInt("meeting_rounds", 1),
        stepTimeoutSec = prefs.getInt("step_timeout", 300),
        allowSequentialFallback = prefs.getBoolean("allow_sequential", true),
        keepMainLoaded = prefs.getBoolean("keep_main", true),
        noticeAccepted = prefs.getBoolean("notice_ok", false),
    )

    private inline fun <reified E : Enum<E>> enumOr(name: String?, default: E): E =
        try {
            if (name == null) default else enumValueOf<E>(name)
        } catch (_: Exception) {
            default
        }

    fun save(s: AppSettings) {
        prefs.edit()
            .putString("theme", s.themeMode.name)
            .putString("system_prompt", s.systemPrompt)
            .putBoolean("reduce_motion", s.reduceMotion)
            .putInt("context_length", s.contextLength)
            .putInt("max_tokens", s.maxTokens)
            .putFloat("temperature", s.temperature)
            .putFloat("top_p", s.topP)
            .putInt("top_k", s.topK)
            .putString("search_mode", s.searchMode.name)
            .putString("collab_mode", s.collabMode.name)
            .putString("search_provider", s.searchProvider.name)
            .putString("brave_key", s.braveKey)
            .putString("searx_url", s.searxUrl)
            .putInt("review_rounds", s.reviewRounds)
            .putInt("meeting_rounds", s.meetingRounds)
            .putInt("step_timeout", s.stepTimeoutSec)
            .putBoolean("allow_sequential", s.allowSequentialFallback)
            .putBoolean("keep_main", s.keepMainLoaded)
            .putBoolean("notice_ok", s.noticeAccepted)
            .apply()
    }
}
