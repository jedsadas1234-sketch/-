package com.pocketai.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.pocketai.app.data.CollabMode
import com.pocketai.app.llm.formatBytes
import com.pocketai.app.team.ModelRole
import com.pocketai.app.team.displayName

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeamScreen(vm: ChatViewModel, onBack: () -> Unit, onOpen: (Screen) -> Unit) {
    LaunchedEffect(vm.models.files) { vm.syncTeam() }
    val team = vm.team
    val s = vm.settings
    val files = vm.models.files
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Team") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") } },
            )
        },
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                "The first model is Main: it coordinates and writes the final answer. Other models help according to the collaboration mode. " +
                    "A role is a job description, not proof that the model is good at it.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            SectionCard("Collaboration mode") {
                ChipRow(CollabMode.values().toList(), s.collabMode, { it.label() }, enabled = !vm.generating) { vm.setCollabMode(it) }
                Text("Supreme mode uses at most four analysis models plus a synthesizer.", style = MaterialTheme.typography.bodySmall)
            }
            SectionCard("Members (${team.enabled.size} active)") {
                if (team.slots.isEmpty()) Text("No models yet. Import a .gguf model first.")
                team.slots.forEachIndexed { i, slot ->
                    val size = files.firstOrNull { it.name == slot.file }?.sizeBytes
                    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(displayName(slot.file) + if (i == 0) "  (Main)" else "", style = MaterialTheme.typography.titleSmall)
                        Text(size?.let { formatBytes(it) } ?: "file missing", style = MaterialTheme.typography.bodySmall)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (i == 0) {
                                Text("Role: Main", Modifier.weight(1f))
                            } else {
                                RoleMenu(slot.role) { vm.setSlotRole(slot.file, it) }
                                Switch(checked = slot.enabled, onCheckedChange = { vm.setSlotEnabled(slot.file, it) })
                                Text(if (slot.enabled) " On" else " Off", Modifier.weight(1f))
                            }
                            IconButton(onClick = { vm.moveSlot(slot.file, -1) }, enabled = i > 0) { Icon(Icons.Filled.ArrowUpward, "Move up") }
                            IconButton(onClick = { vm.moveSlot(slot.file, 1) }, enabled = i < team.slots.size - 1) { Icon(Icons.Filled.ArrowDownward, "Move down") }
                            IconButton(onClick = { vm.removeFromTeam(slot.file) }) { Icon(Icons.Filled.Close, "Remove from team") }
                        }
                        if (i > 0) TextButton(onClick = { vm.makeMain(slot.file) }) { Text("Make Main") }
                    }
                }
            }
            val candidates = files.filter { f -> team.slots.none { it.file == f.name } }
            SectionCard("Add models") {
                if (candidates.isEmpty()) Text("Every imported model is already in the team.", style = MaterialTheme.typography.bodySmall)
                candidates.forEach { f ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(displayName(f.name))
                            Text(formatBytes(f.sizeBytes), style = MaterialTheme.typography.bodySmall)
                        }
                        OutlinedButton(onClick = { vm.addToTeam(f.name) }) { Text("Add") }
                    }
                }
                TextButton(onClick = { onOpen(Screen.MODELS) }) { Text("Import or manage model files") }
            }
            SectionCard("Synthesizer (Supreme mode)") {
                var open by remember { mutableStateOf(false) }
                Text("The model that combines the independent answers.", style = MaterialTheme.typography.bodySmall)
                Column {
                    OutlinedButton(onClick = { open = true }) { Text(team.synthesizerFile?.let { displayName(it) } ?: "Main model") }
                    DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                        DropdownMenuItem(text = { Text("Main model") }, onClick = { vm.setSynthesizer(null); open = false })
                        files.forEach { f -> DropdownMenuItem(text = { Text(displayName(f.name)) }, onClick = { vm.setSynthesizer(f.name); open = false }) }
                    }
                }
            }
            SectionCard("Check and introduce") {
                val profile = vm.teamProfile
                Text(
                    when {
                        profile == null -> "The models have not met yet."
                        profile.fingerprint != team.fingerprint() -> "The team changed since the last meeting. Run it again to refresh."
                        else -> "Last meeting: " + java.text.DateFormat.getDateTimeInstance().format(java.util.Date(profile.createdAt))
                    },
                    style = MaterialTheme.typography.bodySmall,
                )
                Button(onClick = { vm.refreshCompat(); onOpen(Screen.SAFETY) }, modifier = Modifier.fillMaxWidth()) { Text("Check device and plan") }
                Button(onClick = { onOpen(Screen.MEETING) }, enabled = team.enabled.size >= 2, modifier = Modifier.fillMaxWidth()) { Text("Model introduction (meeting)") }
                if (team.enabled.size < 2) Text("A meeting needs at least two active models.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun RoleMenu(role: ModelRole, onPick: (ModelRole) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Column {
        OutlinedButton(onClick = { open = true }) { Text(role.label) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            ModelRole.values().filter { it != ModelRole.MAIN }.forEach { r ->
                DropdownMenuItem(text = { Text(r.label) }, onClick = { onPick(r); open = false })
            }
        }
    }
}
