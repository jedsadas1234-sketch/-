package com.pocketai.app.safety

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import com.pocketai.app.data.AppSettings
import com.pocketai.app.data.CollabMode
import com.pocketai.app.llm.MemoryEstimate
import com.pocketai.app.llm.ModelManager
import com.pocketai.app.llm.NativeLlama
import com.pocketai.app.llm.ResourcePolicy
import com.pocketai.app.llm.formatBytes
import com.pocketai.app.team.TeamConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

enum class RiskLevel { LOW, MEDIUM, HIGH }

data class DeviceInfo(
    val model: String,
    val androidSdk: Int,
    val totalRam: Long,
    val availRam: Long,
    val freeStorage: Long,
    val abis: List<String>,
    val cores: Int,
    val cpuFeatures: List<String>,
    val thermal: ThermalLevel,
    val thermalText: String,
)

data class ModelCheck(val file: String, val sizeBytes: Long, val estimate: MemoryEstimate?, val present: Boolean)

data class CompatibilityReport(
    val mode: CollabMode,
    val level: RiskLevel,
    val reasons: List<String>,
    val recommendations: List<String>,
    val device: DeviceInfo,
    val models: List<ModelCheck>,
    /** Only for Supreme: whether the analysis models fit in memory together. Null otherwise. */
    val parallelPossible: Boolean?,
    val estimatedPeakBytes: Long,
    val budgetBytes: Long,
)

/**
 * Deterministic pre-run check. Rules are fixed in code (see [ResourcePolicy]); a model is never
 * asked to judge safety. HIGH blocks the run and cannot be overridden in the app.
 */
object Compatibility {

    fun deviceInfo(context: Context, models: ModelManager, thermal: ThermalMonitor): DeviceInfo {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return DeviceInfo(
            model = "${Build.MANUFACTURER} ${Build.MODEL}",
            androidSdk = Build.VERSION.SDK_INT,
            totalRam = mi.totalMem,
            availRam = mi.availMem,
            freeStorage = context.filesDir.usableSpace,
            abis = Build.SUPPORTED_ABIS.toList(),
            cores = Runtime.getRuntime().availableProcessors(),
            cpuFeatures = cpuFeatures(),
            thermal = thermal.level.value,
            thermalText = thermal.describe(),
        )
    }

    private fun cpuFeatures(): List<String> = try {
        val line = File("/proc/cpuinfo").useLines { seq -> seq.firstOrNull { it.startsWith("Features") } }
        val tokens = line?.substringAfter(":")?.trim()?.split(Regex("\\s+"))?.toSet() ?: emptySet()
        buildList {
            if ("asimdhp" in tokens || "fphp" in tokens) add("fp16")
            if ("asimddp" in tokens) add("dotprod")
            if ("i8mm" in tokens) add("i8mm")
            if ("bf16" in tokens) add("bf16")
            if ("sve" in tokens) add("sve")
        }
    } catch (_: Exception) {
        emptyList()
    }

    suspend fun assess(
        context: Context,
        models: ModelManager,
        thermal: ThermalMonitor,
        team: TeamConfig,
        mode: CollabMode,
        settings: AppSettings,
    ): CompatibilityReport = withContext(Dispatchers.IO) {
        val device = deviceInfo(context, models, thermal)
        val reasons = ArrayList<String>()
        val recs = ArrayList<String>()
        var level = RiskLevel.LOW
        fun raise(l: RiskLevel, why: String, rec: String? = null) {
            if (l > level) level = l
            reasons.add(why)
            if (rec != null) recs.add(rec)
        }

        val main = team.main?.file
        val enabled = team.enabled.map { it.file }
        val analysis = if (mode == CollabMode.SUPREME) enabled.take(4) else emptyList()
        val files: List<String> = when (mode) {
            CollabMode.SINGLE -> listOfNotNull(main)
            CollabMode.SEQUENTIAL, CollabMode.INTELLIGENT -> enabled
            CollabMode.SUPREME -> (analysis + listOfNotNull(team.synthesizerFile ?: main)).distinct()
        }

        if (main == null) raise(RiskLevel.HIGH, "No main model is selected.", "Open Team and add a model as Main.")
        if (mode != CollabMode.SINGLE && enabled.size < 2) {
            raise(
                RiskLevel.HIGH,
                "${mode.name.lowercase().replaceFirstChar { it.uppercase() }} mode needs at least one supporting model besides Main.",
                "Add a supporting model in Team, or switch to Single mode.",
            )
        }
        if (!NativeLlama.available) {
            raise(RiskLevel.HIGH, "The native engine did not load: ${NativeLlama.loadError}.")
        }

        val ctx = models.effectiveContext(settings.contextLength)
        val checks = files.map { f ->
            val mf = models.fileByName(f)
            if (mf == null) {
                raise(RiskLevel.HIGH, "Model file $f is missing from app storage.", "Re-import $f or remove it from Team.")
                ModelCheck(f, 0L, null, false)
            } else {
                ModelCheck(f, mf.sizeBytes, models.estimateMemory(mf, ctx), true)
            }
        }

        val total = device.totalRam
        for (c in checks) {
            val est = c.estimate ?: continue
            if (c.sizeBytes > total * ResourcePolicy.SINGLE_MODEL_MAX_FRACTION) {
                raise(
                    RiskLevel.HIGH,
                    "${c.file} (${formatBytes(c.sizeBytes)}) is larger than 75% of this device's RAM (${formatBytes(total)}).",
                    "Use a smaller or more quantized model (for example Q4) in place of ${c.file}.",
                )
            } else if (est.totalBytes > total * ResourcePolicy.HIGH_RISK_FRACTION) {
                raise(
                    RiskLevel.HIGH,
                    "${c.file} needs about ${formatBytes(est.totalBytes)} with a context of $ctx, above 85% of device RAM.",
                    "Lower the context length in Models, or use a smaller model.",
                )
            }
            if (est.kvBytes == null) {
                raise(RiskLevel.MEDIUM, "${c.file}: context memory could not be read from the file header, so the estimate is a minimum.")
            }
        }

        val peakSingle = checks.mapNotNull { it.estimate?.totalBytes }.maxOrNull() ?: 0L
        val budget = ResourcePolicy.safeBudgetBytes(total)
        var peak = peakSingle
        var parallel: Boolean? = null

        if (mode == CollabMode.SUPREME) {
            val sum = analysis.mapNotNull { f -> checks.firstOrNull { it.file == f }?.estimate?.totalBytes }.sum()
            val fits = analysis.size > 1 && sum <= budget && device.thermal <= ThermalLevel.ELEVATED
            parallel = fits
            if (fits) {
                peak = sum
            } else if (analysis.size > 1) {
                val why = if (sum > budget) {
                    "The analysis models need about ${formatBytes(sum)} together, above the safe budget of ${formatBytes(budget)}."
                } else {
                    "The device is warm, so models will not run at the same time."
                }
                if (settings.allowSequentialFallback) {
                    raise(RiskLevel.MEDIUM, "$why Supreme mode will run the models one after another (slower, same result type).")
                } else {
                    raise(
                        RiskLevel.HIGH,
                        "$why Sequential fallback is turned off.",
                        "Turn on sequential fallback in Settings, or use fewer or smaller models.",
                    )
                }
            }
        }

        if (peak > device.availRam * 0.9 && peak <= total * ResourcePolicy.HIGH_RISK_FRACTION) {
            raise(
                RiskLevel.MEDIUM,
                "About ${formatBytes(peak)} is needed but only ${formatBytes(device.availRam)} of RAM is free right now.",
                "Close other apps before running.",
            )
        }
        if (mode != CollabMode.SINGLE && files.size > 3) {
            raise(RiskLevel.MEDIUM, "${files.size} models in one run means a lot of loading and a long wait on a phone.", "Use two or three models.")
        }
        if (device.freeStorage < 500L * 1024 * 1024) {
            raise(RiskLevel.MEDIUM, "Free storage is low (${formatBytes(device.freeStorage)}).")
        }
        when {
            device.thermal >= ThermalLevel.CRITICAL -> raise(
                RiskLevel.HIGH,
                "The device is too hot (thermal status ${device.thermalText}). New model work is blocked until it cools down.",
                "Let the phone rest, remove the case, and avoid charging while running models.",
            )
            device.thermal == ThermalLevel.ELEVATED -> raise(
                RiskLevel.MEDIUM,
                "The device is warm (thermal status ${device.thermalText}). Long runs may be paused by thermal protection.",
            )
        }
        if (reasons.isEmpty()) reasons.add("No problems found for the selected models and mode.")

        CompatibilityReport(mode, level, reasons, recs.distinct(), device, checks, parallel, peak, budget)
    }
}
