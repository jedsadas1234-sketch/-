package com.pocketai.app.team

import android.os.SystemClock
import com.pocketai.app.data.MessageMeta
import com.pocketai.app.data.Source
import com.pocketai.app.data.StepStatus
import com.pocketai.app.data.TimelineStep

/**
 * Collects everything a run produces (timeline, notices, sources, final text) and publishes
 * snapshots. Safe to call from several coroutines at once; token updates are throttled.
 */
class RunTracker(private val publish: (MessageMeta, String) -> Unit) {
    private var meta = MessageMeta()
    private val finalText = StringBuilder()
    private var nextId = 1
    private var last = 0L

    @Synchronized
    fun header(modelLabel: String?, mode: String?) {
        meta = meta.copy(modelLabel = modelLabel, mode = mode)
        push(true)
    }

    @Synchronized
    fun addStep(model: String, roleLabel: String, title: String, status: StepStatus, input: String): Int {
        val id = nextId++
        meta = meta.copy(timeline = meta.timeline + TimelineStep(id, model, roleLabel, title, status, input.take(4000)))
        push(true)
        return id
    }

    @Synchronized
    fun step(id: Int, f: (TimelineStep) -> TimelineStep) {
        meta = meta.copy(timeline = meta.timeline.map { if (it.id == id) f(it) else it })
        push(true)
    }

    @Synchronized
    fun appendStepOutput(id: Int, chunk: String) {
        meta = meta.copy(timeline = meta.timeline.map { if (it.id == id) it.copy(output = it.output + chunk) else it })
        push(false)
    }

    @Synchronized
    fun notice(text: String) {
        if (text !in meta.notices) meta = meta.copy(notices = meta.notices + text)
        push(true)
    }

    @Synchronized
    fun sources(list: List<Source>) {
        meta = meta.copy(sources = list)
        push(true)
    }

    @Synchronized
    fun disagreements(list: List<String>) {
        meta = meta.copy(disagreements = list)
        push(true)
    }

    @Synchronized
    fun phase(text: String?) {
        meta = meta.copy(phase = text)
        push(true)
    }

    @Synchronized
    fun appendFinal(chunk: String) {
        finalText.append(chunk)
        push(false)
    }

    @Synchronized
    fun setFinal(text: String) {
        finalText.setLength(0)
        finalText.append(text)
        push(true)
    }

    @Synchronized
    fun finalText(): String = finalText.toString().trim()

    /** Final state to store with the message (no live phase). */
    @Synchronized
    fun snapshot(): Pair<MessageMeta, String> = meta.copy(phase = null) to finalText.toString().trim()

    private fun push(force: Boolean) {
        val now = SystemClock.uptimeMillis()
        if (force || now - last >= 60) {
            last = now
            publish(meta, finalText.toString())
        }
    }
}
