package com.pocketai.app

import android.app.Application
import com.pocketai.app.feedback.CrashReporter

class PocketApp : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashReporter.install(this)
    }
}
