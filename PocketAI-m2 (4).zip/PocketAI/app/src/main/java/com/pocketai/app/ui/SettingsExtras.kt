package com.pocketai.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.pocketai.app.data.SearchProviderType

/** Search, collaboration and support settings. */
@Composable
fun SettingsExtras(vm: ChatViewModel, onOpen: (Screen) -> Unit) {
    val s = vm.settings
    var showNotice by remember { mutableStateOf(false) }

    Text("Web search", style = MaterialTheme.typography.titleMedium)
    ChipRow(
        SearchProviderType.values().toList(), s.searchProvider,
        { when (it) { SearchProviderType.WIKIPEDIA -> "Wikipedia"; SearchProviderType.BRAVE -> "Brave"; SearchProviderType.SEARXNG -> "SearXNG" } },
    ) { vm.setSearchProvider(it) }
    Text(
        when (s.searchProvider) {
            SearchProviderType.WIKIPEDIA -> "No key needed. Finds encyclopedia articles only, not general web pages."
            SearchProviderType.BRAVE -> "General web search. Needs your own Brave Search API key. The key is stored only on this phone."
            SearchProviderType.SEARXNG -> "General web search through a SearXNG server you choose. It must allow the JSON format and use https."
        },
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    if (s.searchProvider == SearchProviderType.BRAVE) {
        var key by remember(s.braveKey) { mutableStateOf(s.braveKey) }
        OutlinedTextField(
            value = key, onValueChange = { key = it; vm.setBraveKey(it) }, label = { Text("Brave API key") },
            singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(),
        )
    }
    if (s.searchProvider == SearchProviderType.SEARXNG) {
        var url by remember(s.searxUrl) { mutableStateOf(s.searxUrl) }
        OutlinedTextField(
            value = url, onValueChange = { url = it; vm.setSearxUrl(it) }, label = { Text("SearXNG address (https://...)") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
    }

    Text("Collaboration", style = MaterialTheme.typography.titleMedium)
    Text("Review rounds (Intelligent mode): ${s.reviewRounds}")
    ChipRow(listOf(1, 2, 3), s.reviewRounds, { it.toString() }) { vm.setReviewRounds(it) }
    Text("Meeting discussion rounds: ${s.meetingRounds}")
    ChipRow(listOf(1, 2), s.meetingRounds, { it.toString() }) { vm.setMeetingRounds(it) }
    Text("Time limit per model step")
    ChipRow(listOf(120, 300, 600, 900), s.stepTimeoutSec, { "${it / 60} min" }) { vm.setStepTimeout(it) }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.weight(1f)) {
            Text("Sequential fallback for Supreme")
            Text("If the models do not fit in memory together, run them one after another.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = s.allowSequentialFallback, onCheckedChange = vm::setAllowFallback)
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.weight(1f)) {
            Text("Keep Main model loaded")
            Text("Faster next reply, uses RAM while idle. Other models are unloaded after a run.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = s.keepMainLoaded, onCheckedChange = vm::setKeepMain)
    }

    Text("Support", style = MaterialTheme.typography.titleMedium)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        TextButton(onClick = { onOpen(Screen.FEEDBACK) }) { Text("Send feedback") }
        TextButton(onClick = { onOpen(Screen.SAFETY) }) { Text("Device and safety") }
        TextButton(onClick = { showNotice = true }) { Text("Safety notice") }
    }
    if (showNotice) {
        AlertDialog(
            onDismissRequest = { showNotice = false },
            title = { Text("Safety and support") },
            text = { NoticeBody() },
            confirmButton = { TextButton(onClick = { showNotice = false }) { Text("Close") } },
        )
    }
}
