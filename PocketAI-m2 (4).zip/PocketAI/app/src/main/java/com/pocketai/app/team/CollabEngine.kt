package com.pocketai.app.team

import com.pocketai.app.ai.GenSettings
import com.pocketai.app.data.AppSettings
import com.pocketai.app.data.ChatMessage
import com.pocketai.app.data.CollabMode
import com.pocketai.app.data.Role
import com.pocketai.app.data.SearchMode
import com.pocketai.app.data.StepStatus
import com.pocketai.app.llm.ModelManager
import com.pocketai.app.llm.ResourcePolicy
import com.pocketai.app.llm.clipToTokens
import com.pocketai.app.search.SearchOutcome
import com.pocketai.app.search.SearchService
import com.pocketai.app.search.domainOf
import com.pocketai.app.search.formatSearchContext
import com.pocketai.app.search.needsFreshInfo
import com.pocketai.app.search.toSource
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext

/** The run cannot continue; the message is shown to the user as the error. */
class RunFailedException(message: String) : Exception(message)

class CollabContext(
    val history: List<ChatMessage>,
    val systemPrompt: String,
    val mode: CollabMode,
    val searchMode: SearchMode,
    val team: TeamConfig,
    val profile: TeamProfile?,
    val gen: GenSettings,
    val settings: AppSettings,
)

sealed interface StepResult {
    data class Ok(val text: String) : StepResult
    data class Failed(val message: String, val partial: String) : StepResult
}

/**
 * Runs a chat turn in one of the collaboration modes. Every step is recorded in the [RunTracker]
 * (model, role, status, input, output) so the user can inspect it. A failed supporting model is
 * reported and skipped; a failed Main model ends the run.
 */
class CollabEngine(
    private val exec: ExecutionManager,
    private val search: SearchService,
    private val models: ModelManager,
) {
    private class Spec(
        val file: String,
        val roleLabel: String,
        val title: String,
        val phase: StepStatus,
        val system: String,
        val messages: List<ChatMessage>,
        val toFinal: Boolean = false,
        val visible: Boolean = true,
    )

    private class Handle(val id: Int, val spec: Spec, val cb: ExecutionManager.Callbacks)

    private val cores get() = Runtime.getRuntime().availableProcessors()

    suspend fun run(c: CollabContext, t: RunTracker) {
        val main = c.team.main ?: throw RunFailedException("No main model is selected. Open Team and choose a Main model.")
        t.header(
            if (c.mode == CollabMode.SINGLE) displayName(main.file) else "Team of ${c.team.enabled.size} models",
            c.mode.name.lowercase().replaceFirstChar { it.uppercase() },
        )
        try {
            val sb = doSearch(c, t)
            when (c.mode) {
                CollabMode.SINGLE -> single(c, t, main.file, sb)
                CollabMode.SEQUENTIAL -> sequential(c, t, sb)
                CollabMode.INTELLIGENT -> intelligent(c, t, sb)
                CollabMode.SUPREME -> supreme(c, t, sb)
            }
        } finally {
            // free memory that is no longer needed; keep Main resident if the user wants that
            withContext(NonCancellable) { exec.finish(if (c.settings.keepMainLoaded) main.file else null) }
        }
    }

    // ---------------------------------------------------------------- search

    private suspend fun doSearch(c: CollabContext, t: RunTracker): String? {
        val q = lastUser(c.history)
        val want = when (c.searchMode) {
            SearchMode.OFFLINE -> false
            SearchMode.SEARCH -> true
            SearchMode.AUTO -> needsFreshInfo(q)
        }
        if (!want) {
            if (c.searchMode == SearchMode.AUTO) t.notice("Auto: no web search was needed for this question.")
            return null
        }
        val provider = search.providerName()
        val id = t.addStep("Web search", "Search", "Searching $provider", StepStatus.THINKING, q.take(300))
        t.phase("Searching the web ($provider)…")
        return when (val r = search.search(q)) {
            is SearchOutcome.Success -> {
                if (r.results.isEmpty()) {
                    t.step(id) { it.copy(status = StepStatus.COMPLETED, output = "No results.") }
                    t.notice("The web search returned no results, so this answer comes from the local model only.")
                    null
                } else {
                    t.sources(r.results.map { it.toSource() })
                    t.step(id) {
                        it.copy(
                            status = StepStatus.COMPLETED,
                            output = r.results.joinToString("\n") { x -> "${x.title} (${domainOf(x.url)})" },
                        )
                    }
                    formatSearchContext(r.provider, r.results)
                }
            }
            is SearchOutcome.Failure -> {
                t.step(id) { it.copy(status = StepStatus.FAILED, error = r.reason) }
                if (c.searchMode == SearchMode.SEARCH) {
                    throw RunFailedException("Web search failed: ${r.reason} Switch Search mode to Offline to answer without it.")
                }
                t.notice(
                    "Auto wanted fresh information, but the search failed: ${r.reason} " +
                        "The answer comes from the local model only and may be out of date."
                )
                null
            }
        }
    }

    // ---------------------------------------------------------------- modes

    private suspend fun single(c: CollabContext, t: RunTracker, file: String, sb: String?) {
        val spec = Spec(file, "Main", "Answer", StepStatus.THINKING, c.systemPrompt, withSearch(c.history, sb), toFinal = true, visible = false)
        val r = runStep(c, t, spec, setOf(file))
        if (r is StepResult.Failed) throw RunFailedException(r.message)
    }

    private suspend fun sequential(c: CollabContext, t: RunTracker, sb: String?) {
        val main = c.team.main!!.file
        val keep = setOf(main)
        val q = lastUser(c.history)
        val supporting = c.team.supporting
        val part = budget(c, supporting.size + 1)

        val init = runStep(
            c, t,
            Spec(main, "Main", "Initial response", StepStatus.THINKING, mainSystem(c), withSearch(c.history, sb)),
            keep,
        )
        if (init is StepResult.Failed) throw RunFailedException("The main model failed: ${init.message}")
        val initial = (init as StepResult.Ok).text
        var current = initial
        var prevName = displayName(main)
        val contributions = ArrayList<Pair<String, String>>()

        for (s in supporting) {
            val prompt = Prompts.sequentialSupport(clipToTokens(q, part), prevName, clipToTokens(current, part), s.role)
            val r = runStep(
                c, t,
                Spec(s.file, s.role.label, "${s.role.label} pass", StepStatus.REVIEWING, supportSystem(c, s.role), listOf(user(prompt))),
                keep,
            )
            if (r is StepResult.Ok && r.text.isNotBlank()) {
                contributions.add("${displayName(s.file)} (${s.role.label})" to r.text)
                current = r.text
                prevName = displayName(s.file)
            } else {
                t.notice("${displayName(s.file)} did not contribute: ${(r as? StepResult.Failed)?.message ?: "empty reply"}.")
            }
        }
        if (contributions.isEmpty()) {
            t.setFinal(initial)
            t.notice("No teammate contributed, so this is the Main model's own answer.")
            return
        }
        val fin = runStep(
            c, t,
            Spec(
                main, "Main", "Final answer", StepStatus.SYNTHESIZING, mainSystem(c),
                listOf(user(Prompts.sequentialFinal(clipToTokens(q, part), clipToTokens(initial, part), contributions.map { it.first to clipToTokens(it.second, part) }))),
                toFinal = true,
            ),
            keep,
        )
        if (fin is StepResult.Failed) {
            t.setFinal(current)
            t.notice("The final step failed (${fin.message}); showing the latest improved draft instead.")
        }
    }

    private suspend fun intelligent(c: CollabContext, t: RunTracker, sb: String?) {
        val main = c.team.main!!.file
        val keep = setOf(main)
        val q = lastUser(c.history)
        val reviewers = c.team.supporting
        val rounds = c.settings.reviewRounds.coerceIn(1, 3)
        val part = budget(c, reviewers.size + 1)

        val init = runStep(
            c, t,
            Spec(main, "Main", "Initial analysis", StepStatus.THINKING, mainSystem(c), withSearch(c.history, sb)),
            keep,
        )
        if (init is StepResult.Failed) throw RunFailedException("The main model failed: ${init.message}")
        var draft = (init as StepResult.Ok).text
        val disagreements = LinkedHashSet<String>()
        var pending: List<Pair<String, String>> = emptyList()

        for (round in 1..rounds) {
            val reviews = ArrayList<Pair<String, String>>()
            var issues = false
            for (rv in reviewers) {
                val prompt = Prompts.review(
                    clipToTokens(q, part), clipToTokens(draft, part),
                    reviews.map { it.first to clipToTokens(it.second, part / 2) },
                )
                val r = runStep(
                    c, t,
                    Spec(rv.file, rv.role.label, "Review, round $round", StepStatus.REVIEWING, supportSystem(c, rv.role), listOf(user(prompt))),
                    keep,
                )
                if (r is StepResult.Ok && r.text.isNotBlank()) {
                    val who = "${displayName(rv.file)} (${rv.role.label})"
                    reviews.add(who to r.text)
                    if (!r.text.trimStart().startsWith("NO MAJOR ISSUES", ignoreCase = true)) issues = true
                    r.text.lines().filter { it.trimStart().startsWith("DISAGREE:", ignoreCase = true) }
                        .forEach { disagreements.add("${displayName(rv.file)}: ${it.substringAfter(':').trim()}") }
                } else {
                    t.notice("${displayName(rv.file)} gave no review in round $round: ${(r as? StepResult.Failed)?.message ?: "empty reply"}.")
                }
            }
            t.disagreements(disagreements.toList())
            if (reviews.isEmpty()) {
                t.notice("No reviewer responded in round $round, so the draft was not reviewed.")
                break
            }
            if (!issues) {
                t.notice("Round $round: no reviewer found major issues; stopped early.")
                pending = emptyList()
                break
            }
            if (round < rounds) {
                val rev = runStep(
                    c, t,
                    Spec(
                        main, "Main", "Revision after round $round", StepStatus.THINKING, mainSystem(c),
                        listOf(user(Prompts.revise(clipToTokens(q, part), clipToTokens(draft, part), reviews.map { it.first to clipToTokens(it.second, part) }))),
                    ),
                    keep,
                )
                if (rev is StepResult.Ok && rev.text.isNotBlank()) {
                    draft = rev.text
                    pending = emptyList()
                } else {
                    t.notice("The revision step failed; the previous draft is kept.")
                    pending = reviews
                }
            } else {
                pending = reviews
            }
        }

        val fin = runStep(
            c, t,
            Spec(
                main, "Main", "Final answer", StepStatus.SYNTHESIZING, mainSystem(c),
                listOf(user(Prompts.intelligentFinal(clipToTokens(q, part), clipToTokens(draft, part), pending.map { it.first to clipToTokens(it.second, part / 2) }, disagreements.toList()))),
                toFinal = true,
            ),
            keep,
        )
        if (fin is StepResult.Failed) {
            t.setFinal(draft)
            t.notice("The final step failed (${fin.message}); showing the latest draft instead.")
        }
    }

    private suspend fun supreme(c: CollabContext, t: RunTracker, sb: String?) {
        val main = c.team.main!!.file
        val q = lastUser(c.history)
        val group = c.team.enabled.take(4)
        if (c.team.enabled.size > 4) t.notice("Supreme mode uses at most four analysis models; ${c.team.enabled.size - 4} enabled model(s) were not used.")
        val synthFile = c.team.synthesizerFile ?: main
        val plan = exec.plan(group.map { it.file })
        if (!plan.parallel && group.size > 1 && !c.settings.allowSequentialFallback) {
            throw RunFailedException("The analysis models cannot run at the same time (${plan.reason}) and sequential fallback is turned off in Settings.")
        }
        if (group.size > 1) {
            t.notice(
                if (plan.parallel) "Analysis models run at the same time (true parallel): ${plan.reason}."
                else "Analysis models run one after another instead of in parallel: ${plan.reason}."
            )
        }
        val keep = group.map { it.file }.toSet()
        val specs = group.map { s ->
            Spec(s.file, s.role.label, "Independent analysis", StepStatus.THINKING,
                if (s.role == ModelRole.MAIN) mainSystem(c) else supportSystem(c, s.role), withSearch(c.history, sb))
        }

        val results: List<StepResult> = if (plan.parallel) {
            val threads = ResourcePolicy.parallelThreads(cores, group.size)
            val handles = specs.map { begin(t, it) }
            // load one by one (memory spikes), then generate at the same time
            val engines = handles.map { h ->
                try {
                    exec.prepare(h.spec.file, keep, threads, h.cb)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    failStep(t, h, e.message ?: e.javaClass.simpleName)
                    null
                }
            }
            coroutineScope {
                handles.indices.map { i ->
                    async {
                        val eng = engines[i]
                        val h = handles[i]
                        if (eng == null) {
                            StepResult.Failed("The model could not be loaded.", "")
                        } else {
                            finishWith(t, h) { exec.generate(eng, h.spec.messages, h.spec.system, c.gen, h.cb, StepStatus.THINKING) }
                        }
                    }
                }.awaitAll()
            }
        } else {
            specs.map { runStep(c, t, it, keep) }
        }

        val answers = ArrayList<Pair<String, String>>()
        results.forEachIndexed { i, r ->
            val s = group[i]
            if (r is StepResult.Ok && r.text.isNotBlank()) {
                answers.add("${displayName(s.file)} (${s.role.label})" to r.text)
            } else {
                t.notice("${displayName(s.file)} produced no answer: ${(r as? StepResult.Failed)?.message ?: "empty reply"}.")
            }
        }
        if (answers.isEmpty()) throw RunFailedException("None of the analysis models produced an answer.")
        if (answers.size == 1) {
            t.setFinal(answers[0].second)
            t.notice("Only one model answered, so no synthesis was needed.")
            return
        }

        val part = budget(c, answers.size)
        val synthRole = if (synthFile == main) ModelRole.MAIN else ModelRole.SYNTHESIZER
        val fin = runStep(
            c, t,
            Spec(
                synthFile, ModelRole.SYNTHESIZER.label, "Synthesis", StepStatus.SYNTHESIZING,
                if (synthRole == ModelRole.MAIN) mainSystem(c) else c.systemPrompt + "\n\n" + Prompts.teamBriefing(c.team, c.mode, c.profile, ModelRole.SYNTHESIZER),
                listOf(user(Prompts.synthesis(clipToTokens(q, part), answers.map { it.first to clipToTokens(it.second, part) }))),
                toFinal = true,
            ),
            setOf(synthFile),
        )
        if (fin is StepResult.Failed) {
            t.setFinal(answers.first().second)
            t.notice("The synthesis step failed (${fin.message}); showing the first model's answer instead.")
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun lastUser(history: List<ChatMessage>): String = history.lastOrNull { it.role == Role.USER }?.text.orEmpty()

    private fun user(text: String) = ChatMessage(-1L, Role.USER, text)

    private fun withSearch(history: List<ChatMessage>, sb: String?): List<ChatMessage> {
        if (sb == null) return history
        val idx = history.indexOfLast { it.role == Role.USER }
        if (idx < 0) return history
        return history.mapIndexed { i, m -> if (i == idx) m.copy(text = Prompts.request(m.text, sb)) else m }
    }

    private fun mainSystem(c: CollabContext): String =
        c.systemPrompt + "\n\n" + Prompts.teamBriefing(c.team, c.mode, c.profile, ModelRole.MAIN)

    private fun supportSystem(c: CollabContext, role: ModelRole): String =
        Prompts.teamBriefing(c.team, c.mode, c.profile, role)

    /** Token budget for each text embedded in a prompt, so a step never overflows the context. */
    private fun budget(c: CollabContext, parts: Int): Int {
        val ctx = models.effectiveContext(c.settings.contextLength)
        return ((ctx - c.gen.maxTokens - 500) / (parts + 2)).coerceAtLeast(120)
    }

    private fun statusText(s: StepStatus): String = when (s) {
        StepStatus.LOADING -> "loading model"
        StepStatus.THINKING -> "thinking"
        StepStatus.REVIEWING -> "reviewing"
        StepStatus.SYNTHESIZING -> "synthesizing"
        else -> s.name.lowercase()
    }

    private fun begin(t: RunTracker, spec: Spec): Handle {
        val input = spec.messages.lastOrNull()?.text.orEmpty()
        val id = if (spec.visible) {
            t.addStep(displayName(spec.file), spec.roleLabel, spec.title, StepStatus.WAITING, input)
        } else {
            -1
        }
        val cb = ExecutionManager.Callbacks(
            onPhase = { st ->
                if (id >= 0) t.step(id) { it.copy(status = st) }
                t.phase("${spec.title} (${displayName(spec.file)}): ${statusText(st)}")
            },
            onNotice = { t.notice(it) },
            onToken = { chunk ->
                if (spec.toFinal) t.appendFinal(chunk) else if (id >= 0) t.appendStepOutput(id, chunk)
            },
        )
        return Handle(id, spec, cb)
    }

    private fun failStep(t: RunTracker, h: Handle, message: String) {
        if (h.id >= 0) t.step(h.id) { it.copy(status = StepStatus.FAILED, error = message) }
    }

    private suspend fun finishWith(t: RunTracker, h: Handle, block: suspend () -> String): StepResult {
        try {
            val out = block()
            if (h.id >= 0) t.step(h.id) { it.copy(status = StepStatus.COMPLETED, output = out) }
            return StepResult.Ok(out)
        } catch (e: CancellationException) {
            if (h.id >= 0) t.step(h.id) { it.copy(status = StepStatus.CANCELLED) }
            throw e
        } catch (e: ThermalSuspendedException) {
            if (h.id >= 0) t.step(h.id) { it.copy(status = StepStatus.FAILED, error = e.message, output = e.partial) }
            throw e
        } catch (e: StepTimeoutException) {
            if (h.id >= 0) t.step(h.id) { it.copy(status = StepStatus.FAILED, error = e.message, output = e.partial) }
            return StepResult.Failed(e.message ?: "Timed out.", e.partial)
        } catch (e: Exception) {
            val msg = e.message ?: e.javaClass.simpleName
            failStep(t, h, msg)
            return StepResult.Failed(msg, "")
        }
    }

    private suspend fun runStep(c: CollabContext, t: RunTracker, spec: Spec, keep: Set<String>): StepResult {
        val h = begin(t, spec)
        val threads = ResourcePolicy.defaultThreads(cores)
        return finishWith(t, h) {
            exec.runStep(spec.file, spec.messages, spec.system, c.gen, keep, threads, h.cb, spec.phase)
        }
    }
}
