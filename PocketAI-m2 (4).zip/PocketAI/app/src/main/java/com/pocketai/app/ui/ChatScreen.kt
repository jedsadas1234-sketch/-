package com.pocketai.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import com.pocketai.app.R
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.pocketai.app.data.ChatMessage
import com.pocketai.app.data.MsgState
import com.pocketai.app.data.Role
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: ChatViewModel, onOpen: (Screen) -> Unit) {
    val onOpenSettings = { onOpen(Screen.SETTINGS) }
    val onOpenModels = { onOpen(Screen.MODELS) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val conv = vm.current

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Text(
                    "Chats",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(horizontal = 28.dp, vertical = 20.dp),
                )
                FilledTonalButton(
                    onClick = {
                        vm.newChat()
                        scope.launch { drawerState.close() }
                    },
                    modifier = Modifier
                        .padding(horizontal = 16.dp)
                        .fillMaxWidth(),
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("New chat")
                }
                Spacer(Modifier.height(8.dp))
                LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp)) {
                    items(vm.conversations, key = { it.id }) { c ->
                        NavigationDrawerItem(
                            label = { Text(c.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            selected = c.id == vm.currentId,
                            onClick = {
                                vm.select(c.id)
                                scope.launch { drawerState.close() }
                            },
                            badge = {
                                IconButton(onClick = { vm.delete(c.id) }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Delete chat")
                                }
                            },
                        )
                    }
                }
            }
        },
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(conv.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Chats")
                        }
                    },
                    actions = {
                        IconButton(onClick = vm::newChat) {
                            Icon(Icons.Filled.Add, contentDescription = "New chat")
                        }
                        IconButton(onClick = { onOpen(Screen.TEAM) }) {
                            Icon(Icons.Filled.Groups, contentDescription = "Team")
                        }
                        IconButton(onClick = onOpenModels) {
                            Icon(Icons.Filled.Memory, contentDescription = "Models")
                        }
                        IconButton(onClick = onOpenSettings) {
                            Icon(Icons.Filled.Settings, contentDescription = "Settings")
                        }
                    },
                )
            },
        ) { pad ->
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(pad)
                    .consumeWindowInsets(pad)
                    .imePadding()
            ) {
                ThermalBanner(vm, onOpenSafety = { onOpen(Screen.SAFETY) })
                MessageList(
                    messages = vm.live?.let { lv ->
                        conv.messages.map { if (it.id == lv.msgId) it.copy(text = lv.text, meta = lv.meta) else it }
                    } ?: conv.messages,
                    mainName = vm.team.main?.file,
                    hasModels = vm.models.files.isNotEmpty(),
                    onOpenModels = onOpenModels,
                    onRetry = vm::retry,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                )
                ModeBar(vm, onOpen)
                Composer(generating = vm.generating, onSend = vm::send, onStop = vm::stop)
            }
        }
    }
}

@Composable
private fun MessageList(
    messages: List<ChatMessage>,
    mainName: String?,
    hasModels: Boolean,
    onOpenModels: () -> Unit,
    onRetry: () -> Unit,
    modifier: Modifier,
) {
    if (messages.isEmpty()) {
        Box(modifier, contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
                Image(painterResource(R.drawable.ic_logo), contentDescription = null, modifier = Modifier.size(96.dp).clip(RoundedCornerShape(24.dp)))
                Spacer(Modifier.height(12.dp))
                Text("Say something", style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(8.dp))
                Text(
                    if (mainName != null) "Main model: ${mainName.removeSuffix(".gguf")}" else "No model yet",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
                if (!hasModels) {
                    Spacer(Modifier.height(12.dp))
                    FilledTonalButton(onClick = onOpenModels) { Text("Import a model") }
                }
            }
        }
        return
    }

    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) { listState.animateScrollToItem(0) }
    val lastId = messages.last().id

    // reverseLayout: newest message sits at the bottom and growth while streaming stays anchored there
    LazyColumn(
        modifier = modifier,
        state = listState,
        reverseLayout = true,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        items(messages.asReversed(), key = { it.id }) { m ->
            MessageRow(m, canRetry = m.id == lastId, onRetry = onRetry)
        }
    }
}

@Composable
private fun MessageRow(m: ChatMessage, canRetry: Boolean, onRetry: () -> Unit) {
    val isUser = m.role == Role.USER
    Column(
        Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
    ) {
        Surface(
            color = if (isUser) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceContainerHigh,
            contentColor = if (isUser) MaterialTheme.colorScheme.onPrimaryContainer
            else MaterialTheme.colorScheme.onSurface,
            shape = RoundedCornerShape(
                topStart = 22.dp,
                topEnd = 22.dp,
                bottomStart = if (isUser) 22.dp else 6.dp,
                bottomEnd = if (isUser) 6.dp else 22.dp,
            ),
            modifier = Modifier.widthIn(max = 320.dp),
        ) {
            Box(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                if (m.text.isEmpty() && m.state == MsgState.STREAMING) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        m.meta?.phase?.let { Text(it, Modifier.padding(start = 10.dp), style = MaterialTheme.typography.bodySmall) }
                    }
                } else {
                    SelectionContainer {
                        if (isUser) Text(m.text) else MarkdownText(m.text)
                    }
                }
            }
        }
        if (!isUser) m.meta?.let { MessageExtras(it, streaming = m.state == MsgState.STREAMING) }
        val label = MaterialTheme.typography.labelMedium
        val muted = MaterialTheme.colorScheme.onSurfaceVariant
        when (m.state) {
            MsgState.STREAMING -> if (m.text.isNotEmpty()) {
                Text("Generating…", style = label, color = muted, modifier = Modifier.padding(start = 8.dp, top = 4.dp))
            }
            MsgState.STOPPED -> Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Stopped", style = label, color = muted, modifier = Modifier.padding(start = 8.dp))
                if (canRetry) TextButton(onClick = onRetry) { Text("Retry") }
            }
            MsgState.ERROR -> Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Error: ${m.error ?: "unknown"}",
                    style = label,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(start = 8.dp),
                )
                if (canRetry) TextButton(onClick = onRetry) { Text("Retry") }
            }
            MsgState.DONE -> if (!isUser && m.text.isNotBlank()) CopyButton(m.text)
        }
    }
}

@Composable
private fun CopyButton(text: String) {
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            delay(1500)
            copied = false
        }
    }
    IconButton(
        onClick = {
            clipboard.setText(AnnotatedString(text))
            copied = true
        },
        modifier = Modifier.size(36.dp),
    ) {
        Icon(
            if (copied) Icons.Filled.Check else Icons.Filled.ContentCopy,
            contentDescription = "Copy reply",
            modifier = Modifier.size(18.dp),
        )
    }
}

@Composable
private fun Composer(generating: Boolean, onSend: (String) -> Unit, onStop: () -> Unit) {
    var text by rememberSaveable { mutableStateOf("") }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        TextField(
            value = text,
            onValueChange = { text = it },
            modifier = Modifier.weight(1f),
            placeholder = { Text("Message") },
            shape = RoundedCornerShape(28.dp),
            maxLines = 5,
            colors = TextFieldDefaults.colors(
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                disabledIndicatorColor = Color.Transparent,
            ),
        )
        Spacer(Modifier.width(8.dp))
        if (generating) {
            FilledIconButton(onClick = onStop, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Filled.Stop, contentDescription = "Stop generating")
            }
        } else {
            FilledIconButton(
                onClick = {
                    onSend(text)
                    text = ""
                },
                enabled = text.isNotBlank(),
                modifier = Modifier.size(52.dp),
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
            }
        }
    }
}
