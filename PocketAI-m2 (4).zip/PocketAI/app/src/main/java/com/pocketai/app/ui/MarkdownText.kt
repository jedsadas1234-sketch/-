package com.pocketai.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private sealed interface Block {
    data class Code(val text: String, val lang: String) : Block
    data class Heading(val level: Int, val text: String) : Block
    data class Bullet(val indent: Int, val text: String) : Block
    data class Numbered(val indent: Int, val number: String, val text: String) : Block
    data class Quote(val text: String) : Block
    data class Table(val text: String) : Block
    data object Rule : Block
    data class Paragraph(val text: String) : Block
}

private const val URL_TAG = "URL"

/**
 * Small markdown subset: fenced code blocks (with a copy button), **bold**, `inline code`,
 * plus headings, bullet and numbered lists, quotes, tables (shown monospace), rules,
 * *italic* and links ([text](https://...) and bare http/https URLs).
 */
@Composable
fun MarkdownText(text: String, modifier: Modifier = Modifier) {
    val blocks = remember(text) { splitBlocks(text) }
    val codeBg = MaterialTheme.colorScheme.surfaceContainerHighest
    val linkColor = MaterialTheme.colorScheme.primary
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val type = MaterialTheme.typography
    Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        blocks.forEach { b ->
            when (b) {
                is Block.Code -> CodeBlock(b.text, b.lang)
                is Block.Heading -> {
                    val base = when (b.level) {
                        1 -> type.titleLarge
                        2 -> type.titleMedium
                        else -> type.titleSmall
                    }
                    RichText(inline(b.text, codeBg, linkColor), style = base.copy(fontWeight = FontWeight.Bold))
                }
                is Block.Bullet -> MdListItem("•", b.indent, inline(b.text, codeBg, linkColor))
                is Block.Numbered -> MdListItem("${b.number}.", b.indent, inline(b.text, codeBg, linkColor))
                is Block.Quote -> RichText(
                    inline(b.text, codeBg, linkColor),
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(codeBg, RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    color = muted,
                )
                is Block.Table -> Text(
                    text = b.text,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    softWrap = false,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(codeBg, RoundedCornerShape(12.dp))
                        .horizontalScroll(rememberScrollState())
                        .padding(10.dp),
                )
                Block.Rule -> HorizontalDivider(Modifier.padding(vertical = 4.dp))
                is Block.Paragraph -> RichText(inline(b.text, codeBg, linkColor))
            }
        }
    }
}

@Composable
private fun CodeBlock(code: String, lang: String) {
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            delay(1500)
            copied = false
        }
    }
    Column(
        Modifier
            .padding(vertical = 4.dp)
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceContainerHighest, RoundedCornerShape(12.dp)),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 12.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                lang.ifBlank { "code" },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f),
            )
            IconButton(
                onClick = {
                    clipboard.setText(AnnotatedString(code))
                    copied = true
                },
                modifier = Modifier.size(32.dp),
            ) {
                Icon(
                    if (copied) Icons.Filled.Check else Icons.Filled.ContentCopy,
                    contentDescription = "Copy code",
                    modifier = Modifier.size(18.dp),
                )
            }
        }
        Text(
            text = code,
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp,
            softWrap = false,
            modifier = Modifier
                .horizontalScroll(rememberScrollState())
                .padding(start = 10.dp, end = 10.dp, bottom = 10.dp),
        )
    }
}

@Composable
private fun MdListItem(marker: String, indent: Int, content: AnnotatedString) {
    Row(Modifier.padding(start = (indent / 2 * 12).dp)) {
        Text(marker, modifier = Modifier.widthIn(min = 22.dp).padding(end = 6.dp))
        RichText(content, Modifier.weight(1f))
    }
}

/** Plain Text, or a tap-aware text when the content holds links. Only http/https are ever opened. */
@Composable
private fun RichText(
    text: AnnotatedString,
    modifier: Modifier = Modifier,
    style: TextStyle = LocalTextStyle.current,
    color: Color = LocalContentColor.current,
) {
    val uriHandler = LocalUriHandler.current
    if (text.getStringAnnotations(URL_TAG, 0, text.length).isEmpty()) {
        Text(text, modifier = modifier, color = color, style = style)
    } else {
        ClickableText(
            text = text,
            modifier = modifier,
            style = style.copy(color = color),
            onClick = { offset ->
                text.getStringAnnotations(URL_TAG, offset, offset).firstOrNull()?.let {
                    try {
                        uriHandler.openUri(it.item)
                    } catch (_: Exception) {
                        // no app can open it: ignore
                    }
                }
            },
        )
    }
}

private val HEADING = Regex("^(#{1,6})\\s+(.*)$")
private val BULLET = Regex("^(\\s*)[-*+]\\s+(.*)$")
private val NUMBERED = Regex("^(\\s*)(\\d{1,3})[.)]\\s+(.*)$")
private val RULE = Regex("^\\s*(-{3,}|\\*{3,}|_{3,})\\s*$")

private fun splitBlocks(text: String): List<Block> {
    val out = mutableListOf<Block>()
    val para = StringBuilder()
    val code = StringBuilder()
    val quote = StringBuilder()
    val table = StringBuilder()
    var inCode = false
    var lang = ""
    fun flushPara() {
        val t = para.toString().trim('\n')
        if (t.isNotEmpty()) out.add(Block.Paragraph(t))
        para.clear()
    }
    fun flushQuote() {
        val t = quote.toString().trim('\n')
        if (t.isNotEmpty()) out.add(Block.Quote(t))
        quote.clear()
    }
    fun flushTable() {
        val t = table.toString().trim('\n')
        if (t.isNotEmpty()) out.add(Block.Table(t))
        table.clear()
    }
    fun flushText() {
        flushPara()
        flushQuote()
        flushTable()
    }
    text.split("\n").forEach { raw ->
        val line = raw.trimEnd('\r')
        if (line.trimStart().startsWith("```")) {
            if (inCode) {
                val t = code.toString().trimEnd('\n')
                if (t.isNotEmpty()) out.add(Block.Code(t, lang))
                code.clear()
                inCode = false
            } else {
                flushText()
                inCode = true
                lang = line.trimStart().removePrefix("```").trim()
            }
            return@forEach
        }
        if (inCode) {
            code.append(line).append('\n')
            return@forEach
        }
        val trimmed = line.trim()
        val h = HEADING.matchEntire(trimmed)
        val b = BULLET.matchEntire(line)
        val n = NUMBERED.matchEntire(line)
        when {
            trimmed.isEmpty() -> flushText()
            RULE.matches(line) -> {
                flushText()
                out.add(Block.Rule)
            }
            h != null -> {
                flushText()
                out.add(Block.Heading(h.groupValues[1].length, h.groupValues[2].trim()))
            }
            trimmed.startsWith(">") -> {
                flushPara()
                flushTable()
                quote.append(trimmed.removePrefix(">").trimStart()).append('\n')
            }
            trimmed.startsWith("|") -> {
                flushPara()
                flushQuote()
                table.append(trimmed).append('\n')
            }
            b != null -> {
                flushText()
                out.add(Block.Bullet(b.groupValues[1].length, b.groupValues[2]))
            }
            n != null -> {
                flushText()
                out.add(Block.Numbered(n.groupValues[1].length, n.groupValues[2], n.groupValues[3]))
            }
            else -> {
                flushQuote()
                flushTable()
                para.append(line).append('\n')
            }
        }
    }
    if (inCode) {
        val t = code.toString().trimEnd('\n')
        if (t.isNotEmpty()) out.add(Block.Code(t, lang))
    }
    flushText() // an unclosed fence (still streaming) renders as code
    return out
}

private fun inline(s: String, codeBg: Color, linkColor: Color): AnnotatedString =
    buildAnnotatedString { appendInline(s, codeBg, linkColor) }

private fun isWebUrl(u: String) = u.startsWith("http://") || u.startsWith("https://")

private fun AnnotatedString.Builder.appendLink(label: String, url: String, color: Color) {
    pushStringAnnotation(URL_TAG, url)
    withStyle(SpanStyle(color = color, textDecoration = TextDecoration.Underline)) { append(label) }
    pop()
}

/** Index of the closing [ch] after [from] that passes [ok], or -1. */
private fun findClosing(s: String, ch: Char, from: Int, ok: (Int) -> Boolean): Int {
    var j = from
    while (j < s.length) {
        val idx = s.indexOf(ch, j)
        if (idx < 0) return -1
        if (ok(idx)) return idx
        j = idx + 1
    }
    return -1
}

private fun AnnotatedString.Builder.appendInline(s: String, codeBg: Color, linkColor: Color) {
    var i = 0
    while (i < s.length) {
        val c = s[i]
        if (c == '\\' && i + 1 < s.length && s[i + 1] in "\\`*_[]()#>-+.!|") {
            append(s[i + 1])
            i += 2
            continue
        }
        if (s.startsWith("**", i)) {
            val end = s.indexOf("**", i + 2)
            if (end > i + 2) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                    appendInline(s.substring(i + 2, end), codeBg, linkColor)
                }
                i = end + 2
                continue
            }
        }
        if (c == '`') {
            val end = s.indexOf('`', i + 1)
            if (end > i + 1) {
                withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg)) {
                    append(s.substring(i + 1, end))
                }
                i = end + 1
                continue
            }
        }
        if (c == '[') {
            val mid = s.indexOf("](", i + 1)
            val close = if (mid > 0) s.indexOf(')', mid + 2) else -1
            if (close > 0) {
                val url = s.substring(mid + 2, close).trim()
                if (isWebUrl(url)) {
                    appendLink(s.substring(i + 1, mid), url, linkColor)
                    i = close + 1
                    continue
                }
            }
        }
        if ((s.startsWith("http://", i) || s.startsWith("https://", i)) && (i == 0 || !s[i - 1].isLetterOrDigit())) {
            var end = i
            while (end < s.length && !s[end].isWhitespace() && s[end] !in "<>\"'") end++
            while (end > i && s[end - 1] in ".,;:!?)]}") end--
            if (end > i + 8) {
                val url = s.substring(i, end)
                appendLink(url, url, linkColor)
                i = end
                continue
            }
        }
        if (c == '*' && i + 1 < s.length && s[i + 1] != '*' && !s[i + 1].isWhitespace()) {
            val end = findClosing(s, '*', i + 1) { idx ->
                idx > i + 1 && !s[idx - 1].isWhitespace() && (idx + 1 >= s.length || s[idx + 1] != '*')
            }
            if (end > 0) {
                withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                    appendInline(s.substring(i + 1, end), codeBg, linkColor)
                }
                i = end + 1
                continue
            }
        }
        if (c == '_' && (i == 0 || !s[i - 1].isLetterOrDigit()) &&
            i + 1 < s.length && s[i + 1] != '_' && !s[i + 1].isWhitespace()
        ) {
            val end = findClosing(s, '_', i + 1) { idx ->
                idx > i + 1 && !s[idx - 1].isWhitespace() && (idx + 1 >= s.length || !s[idx + 1].isLetterOrDigit())
            }
            if (end > 0) {
                withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                    appendInline(s.substring(i + 1, end), codeBg, linkColor)
                }
                i = end + 1
                continue
            }
        }
        append(c)
        i++
    }
}
