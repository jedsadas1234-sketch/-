package com.pocketai.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pocketai.app.feedback.AppLog
import com.pocketai.app.feedback.CrashReporter
import com.pocketai.app.feedback.FeedbackCategory
import com.pocketai.app.feedback.FeedbackSender
import com.pocketai.app.feedback.SendResult
import com.pocketai.app.llm.formatBytes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Technical facts only. Never includes chat text, prompts, model output or the search key. */
private fun buildDiagnostics(vm: ChatViewModel): String {
    val m = vm.models
    val s = vm.settings
    val ram = "RAM total ${formatBytes(m.totalRamBytes)}, free ${formatBytes(m.availRamBytes)}"
    val models = vm.team.slots.joinToString("\n") { slot ->
        val f = m.fileByName(slot.file)
        val info = f?.let { m.verifiedInfo(it) }
        "  ${slot.file} [${slot.role.label}${if (!slot.enabled) ", off" else ""}] ${info?.quantization ?: "?"} ${f?.let { formatBytes(it.sizeBytes) } ?: "missing"}"
    }.ifBlank { "  (none)" }
    val errors = AppLog.recent().takeLast(5).joinToString("\n") { "  $it" }.ifBlank { "  (none)" }
    return buildString {
        appendLine("App: ${FeedbackSender.appVersion()}")
        appendLine("Device: ${FeedbackSender.deviceLine()}")
        appendLine(ram)
        appendLine("Thermal: ${vm.thermal.describe()}")
        appendLine("Mode: ${s.collabMode.name}, search ${s.searchMode.name} (${s.searchProvider.name})")
        appendLine("Models:\n$models")
        appendLine("In memory: ${m.loaded.keys.joinToString().ifBlank { "none" }}")
        append("Recent errors:\n$errors")
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FeedbackScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    var category by remember { mutableStateOf(FeedbackCategory.BUG) }
    var text by remember { mutableStateOf("") }
    var includeDiag by remember { mutableStateOf(false) }
    var includeCrash by remember { mutableStateOf(false) }
    var sending by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<String?>(null) }
    val crash = remember { CrashReporter.lastCrash(context) }
    val diag by produceState("", vm.team, vm.settings.collabMode) { value = withContext(Dispatchers.IO) { buildDiagnostics(vm) } }
    val configured = FeedbackSender.configured()
    val muted = MaterialTheme.colorScheme.onSurfaceVariant

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Send feedback") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") } },
            )
        },
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            ChipRow(FeedbackCategory.values().toList(), category, { it.label }) { category = it }
            OutlinedTextField(
                value = text, onValueChange = { text = it.take(1500) }, label = { Text("What happened?") },
                minLines = 4, modifier = Modifier.fillMaxWidth(),
            )
            Text("${text.length}/1500. Do not include passwords or private information.", style = MaterialTheme.typography.bodySmall, color = muted)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = includeDiag, onCheckedChange = { includeDiag = it })
                Text("Attach technical diagnostics (device, RAM, models, thermal state, recent errors)", style = MaterialTheme.typography.bodySmall)
            }
            if (crash != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = includeCrash, onCheckedChange = { includeCrash = it })
                    Text("Attach the last crash report (secrets removed)", style = MaterialTheme.typography.bodySmall)
                }
            }
            Text("This is exactly what will be sent:", style = MaterialTheme.typography.labelMedium)
            val preview = buildString {
                append("[${category.label}] ").append(text.ifBlank { "(no description)" })
                if (includeDiag) append("\n\n--- diagnostics ---\n").append(diag)
                if (includeCrash && crash != null) append("\n\n--- last crash ---\n").append(crash.take(950))
            }
            SectionCard("Preview") { Text(preview, fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
            Text(
                "Chats, prompts, model answers and model files are never included. " +
                    if (configured) "The report goes to Discord, a third-party service, in a private channel run by the developer." else "Sending is not set up in this build.",
                style = MaterialTheme.typography.bodySmall, color = muted,
            )
            if (configured) {
                Button(
                    onClick = {
                        sending = true
                        result = null
                        scope.launch {
                            val r = withContext(Dispatchers.IO) {
                                FeedbackSender.send(context, category, text, if (includeDiag) diag else null, if (includeCrash) crash else null)
                            }
                            sending = false
                            result = when (r) {
                                SendResult.Success -> { text = ""; "Sent. Thank you." }
                                is SendResult.Failure -> r.message
                                is SendResult.RateLimited -> "Please wait ${r.seconds} s before sending another report."
                            }
                        }
                    },
                    enabled = !sending && text.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(if (sending) "Sending..." else "Send report") }
            }
            OutlinedButton(onClick = { clipboard.setText(AnnotatedString(preview)); result = "Copied to the clipboard." }, modifier = Modifier.fillMaxWidth()) {
                Text("Copy report instead")
            }
            result?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
        }
    }
}
