package com.pocketai.app.team

import com.pocketai.app.ai.GenSettings
import com.pocketai.app.data.AppSettings
import com.pocketai.app.data.ChatMessage
import com.pocketai.app.data.StepStatus
import com.pocketai.app.llm.LocalGenerator
import com.pocketai.app.llm.ModelLoadException
import com.pocketai.app.llm.ModelManager
import com.pocketai.app.llm.ResourcePolicy
import com.pocketai.app.llm.formatBytes
import com.pocketai.app.safety.ThermalLevel
import com.pocketai.app.safety.ThermalMonitor
import kotlinx.coroutines.launch
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.atomic.AtomicBoolean

/** Inference was stopped because the device reached an emergency thermal state. */
class ThermalSuspendedException(val partial: String) :
    Exception("Paused by thermal protection: the device is too hot. Let it cool down, then retry.")

class StepTimeoutException(val partial: String, val seconds: Int) :
    Exception("Timed out after ${seconds}s. A longer step timeout can be set in Settings.")

data class ExecutionPlan(val parallel: Boolean, val reason: String, val estimatedBytes: Long, val budgetBytes: Long)

/**
 * Loads models and runs single steps. Enforces thermal protection (cannot be switched off):
 * at CRITICAL no new model load or step starts, at EMERGENCY a running step is stopped.
 */
class ExecutionManager(
    private val models: ModelManager,
    private val thermal: ThermalMonitor,
    private val settings: () -> AppSettings,
) {
    class Callbacks(
        val onPhase: (StepStatus) -> Unit = {},
        val onNotice: (String) -> Unit = {},
        val onToken: (String) -> Unit = {},
    )

    private suspend fun gate(cb: Callbacks) {
        if (thermal.level.value >= ThermalLevel.CRITICAL) {
            cb.onNotice("Paused: thermal status is ${thermal.describe()}. New model work continues after the device cools down.")
            thermal.awaitRecovered()
            cb.onNotice("Resumed after cooldown.")
        }
    }

    /** Waits out heat, then makes sure the model is resident. */
    suspend fun prepare(file: String, keep: Set<String>, threads: Int, cb: Callbacks): ModelManager.LoadedEngine {
        val mf = models.fileByName(file) ?: throw ModelLoadException("Model file $file is missing from app storage.")
        gate(cb)
        if (!models.isLoaded(file)) cb.onPhase(StepStatus.LOADING)
        val engine = models.ensureLoaded(mf, settings().contextLength, keep + file, threads)
        gate(cb)
        return engine
    }

    /** Runs one reply on a resident engine. Throws on timeout or thermal emergency (with partial text). */
    suspend fun generate(
        engine: ModelManager.LoadedEngine,
        messages: List<ChatMessage>,
        system: String,
        gen: GenSettings,
        cb: Callbacks,
        phase: StepStatus,
    ): String {
        val stop = AtomicBoolean(false)
        val thermalStop = AtomicBoolean(false)
        val sb = StringBuilder()
        val seconds = settings().stepTimeoutSec.coerceAtLeast(30)
        cb.onPhase(phase)
        coroutineScope {
            val watcher = launch {
                thermal.level.first { it >= ThermalLevel.EMERGENCY }
                thermalStop.set(true)
                stop.set(true)
            }
            try {
                val done = withTimeoutOrNull(seconds * 1000L) {
                    LocalGenerator.generate(engine, messages, system, gen, stop).collect { chunk ->
                        sb.append(chunk)
                        cb.onToken(chunk)
                    }
                    true
                }
                if (done == null) throw StepTimeoutException(sb.toString().trim(), seconds)
            } finally {
                watcher.cancel()
            }
        }
        if (thermalStop.get()) throw ThermalSuspendedException(sb.toString().trim())
        return sb.toString().trim()
    }

    suspend fun runStep(
        file: String,
        messages: List<ChatMessage>,
        system: String,
        gen: GenSettings,
        keep: Set<String>,
        threads: Int,
        cb: Callbacks,
        phase: StepStatus,
    ): String = generate(prepare(file, keep, threads, cb), messages, system, gen, cb, phase)

    /** Decides whether [files] can be resident together (true parallel) or must run one after another. */
    suspend fun plan(files: List<String>): ExecutionPlan {
        val total = models.totalRamBytes
        val ctx = models.effectiveContext(settings().contextLength)
        val budget = ResourcePolicy.safeBudgetBytes(total)
        val sum = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            files.sumOf { f -> models.fileByName(f)?.let { models.estimateMemory(it, ctx).totalBytes } ?: 0L }
        }
        return when {
            files.size < 2 -> ExecutionPlan(false, "only one model", sum, budget)
            thermal.level.value > ThermalLevel.ELEVATED ->
                ExecutionPlan(false, "the device is hot (${thermal.describe()})", sum, budget)
            thermal.level.value == ThermalLevel.ELEVATED ->
                ExecutionPlan(false, "the device is warm (${thermal.describe()}), so models run one at a time to limit heat", sum, budget)
            sum > budget ->
                ExecutionPlan(false, "they need about ${formatBytes(sum)} together, above the safe budget of ${formatBytes(budget)}", sum, budget)
            else -> ExecutionPlan(true, "about ${formatBytes(sum)} fits the safe budget of ${formatBytes(budget)}", sum, budget)
        }
    }

    /** After a run: unload every model except [keepMain] (null unloads all). */
    suspend fun finish(keepMain: String?) {
        models.unloadExcept(setOfNotNull(keepMain))
    }
}
