package com.pocketai.app.logic

import com.pocketai.app.feedback.Sanitizer
import com.pocketai.app.llm.quantLabel
import com.pocketai.app.safety.ThermalLevel
import com.pocketai.app.safety.ThermalMonitor
import com.pocketai.app.search.keywordQuery
import com.pocketai.app.search.needsFreshInfo
import com.pocketai.app.team.ModelRole
import com.pocketai.app.team.ModelSlot
import com.pocketai.app.team.TeamConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LogicTest {
    @Test
    fun thermalStatusMapping() {
        assertEquals(ThermalLevel.NORMAL, ThermalMonitor.map(0))
        assertEquals(ThermalLevel.NORMAL, ThermalMonitor.map(1))
        assertEquals(ThermalLevel.ELEVATED, ThermalMonitor.map(2))
        assertEquals(ThermalLevel.CRITICAL, ThermalMonitor.map(3))
        assertEquals(ThermalLevel.EMERGENCY, ThermalMonitor.map(4))
        assertEquals(ThermalLevel.EMERGENCY, ThermalMonitor.map(6))
        assertEquals(ThermalLevel.UNKNOWN, ThermalMonitor.map(-1))
    }

    @Test
    fun autoSearchRule() {
        assertTrue(needsFreshInfo("What is the weather today?"))
        assertTrue(needsFreshInfo("ราคาทองวันนี้เท่าไหร่"))
        assertFalse(needsFreshInfo("Explain how a binary search works"))
    }

    @Test
    fun keywordQueryDropsFillerWords() {
        assertEquals("Eiffel Tower height", keywordQuery("What is the Eiffel Tower height?"))
    }

    @Test
    fun teamMainAlwaysCounts() {
        val t = TeamConfig(
            listOf(
                ModelSlot("a.gguf", ModelRole.MAIN, enabled = false),
                ModelSlot("b.gguf", ModelRole.REVIEWER, enabled = false),
                ModelSlot("c.gguf", ModelRole.ANALYST, enabled = true),
            )
        )
        assertEquals(listOf("a.gguf", "c.gguf"), t.enabled.map { it.file })
        assertEquals(listOf("c.gguf"), t.supporting.map { it.file })
    }

    @Test
    fun fingerprintChangesWithRoles() {
        val a = TeamConfig(listOf(ModelSlot("a.gguf", ModelRole.MAIN), ModelSlot("b.gguf", ModelRole.REVIEWER)))
        val b = TeamConfig(listOf(ModelSlot("a.gguf", ModelRole.MAIN), ModelSlot("b.gguf", ModelRole.ANALYST)))
        assertTrue(a.fingerprint() != b.fingerprint())
    }

    @Test
    fun quantNames() {
        assertEquals("Q4_K_M", quantLabel(15))
        assertEquals("Q8_0", quantLabel(7))
    }

    @Test
    fun sanitizerHidesSecretsAndUrls() {
        val out = Sanitizer.clean("failed with api_key=abc123 at https://example.com/x?token=zzz")
        assertFalse(out.contains("abc123"))
        assertFalse(out.contains("token=zzz"))
        assertTrue(out.contains("example.com"))
    }
}
