plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

fun discordWebhook(): String {
    val env = System.getenv("DISCORD_WEBHOOK")?.trim().orEmpty()
    if (env.isNotEmpty()) return env
    val f = rootProject.file("discord_webhook.txt")
    return if (f.exists()) f.readText().trim() else ""
}

android {
    namespace = "com.pocketai.app"
    compileSdk = 34
    ndkVersion = "26.3.11579264"

    defaultConfig {
        buildConfigField("String", "DISCORD_WEBHOOK", "\"" + discordWebhook().replace("\\", "\\\\").replace("\"", "\\\"") + "\"")
        applicationId = "com.pocketai.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "0.3.0"

        ndk {
            // phones only; keeps APK and build time down
            abiFilters += listOf("arm64-v8a")
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.09.00")
    implementation(composeBom)
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.animation:animation")
    testImplementation("junit:junit:4.13.2")
}
