# Pocket AI: architecture (0.3.0)

Written without a device or local compiler. Anything marked "verify" is untested.

## Packages (single module `app`)
- `llm/` ModelManager (import, several resident engines, memory-budget eviction), LocalGenerator, GgufReader, NativeLlama (JNI, llama.cpp v1.0.0, arm64-v8a, CPU).
- `team/` TeamConfig/roles, ExecutionManager (loads models, thermal gate, timeouts, parallel plan), CollabEngine (4 modes), MeetingEngine, RunTracker, Prompts, TeamStore.
- `safety/` ThermalMonitor (Android thermal status, API 29+), Compatibility (deterministic risk rules).
- `search/` Wikipedia, Brave, SearXNG providers; Auto rule.
- `feedback/` sanitizer, crash trace, Discord sender.
- `ui/` Compose screens: Chat, Models, Team, Meeting, Safety, Feedback, Settings.

## Rules enforced in code (not by prompts)
- High-risk compatibility result blocks a run; no override in the app.
- Thermal: CRITICAL pauses new loads and steps; EMERGENCY stops inference. No setting disables it.
- Models never choose animations, tools or settings; roles and role suggestions are validated against an allowlist; suggestions apply only on user tap.
- Search results are marked untrusted in the prompt; sources are shown by the app, not written by the model.
- Chats and models are never uploaded. Internet use: web search (user-enabled) and feedback (user-sent).

## Memory and parallelism
- Safe budget = 65% of RAM minus 700 MB for models resident together; one model alone is limited to 75% of RAM. Estimates come from the GGUF header; they are not measurements.
- Supreme runs analysis models at the same time only if their estimates fit the budget and the device is not warm; otherwise it runs them one after another and says so (can be turned off in Settings).
- Real speedups from parallel runs on a phone CPU are not guaranteed (verify).

## Known limits
- Not removed from the brief but not built: VRM avatar, voice, overlay, summon shortcut (the master brief dropped them).
- Retry after a thermal pause restarts the run from the beginning.
- KV-cache reuse is per engine; collaboration steps use fresh prompts so reuse helps mostly in Single mode.
